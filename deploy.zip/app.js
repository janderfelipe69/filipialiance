// ============================================================
// app.js — Lógica do PokeAlliance Shop
// Depende de: dados.js (deve ser carregado antes)
// ============================================================

function formatKK(raw) {
  if (!raw || raw <= 0) return null;
  let label = '';
  if (raw >= 1000000000) {
    const v = raw / 1000000000;
    label = (v % 1 === 0 ? v.toFixed(0) : parseFloat(v.toFixed(2))) + 'kkk';
  } else if (raw >= 1000000) {
    const v = raw / 1000000;
    label = (v % 1 === 0 ? v.toFixed(0) : parseFloat(v.toFixed(2))) + 'kk';
  } else if (raw >= 1000) {
    const v = raw / 1000;
    label = (v % 1 === 0 ? v.toFixed(0) : parseFloat(v.toFixed(2))) + 'k';
  } else {
    label = raw.toString();
  }
  const brl = (raw / 1000000 * KK_TO_BRL).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  return { label, brl };
}

function _calcCapturaFinalPrice(poke, ball) {
  const diveMultiplier = poke.dive ? 1.30 : 1.0;
  const effectiveBase  = poke.price ? Math.round(poke.price * diveMultiplier) : 0;
  const rawFinalPrice  = effectiveBase ? Math.round(effectiveBase * ball.mult) : 0;
  return (ball.minPrice && rawFinalPrice > 0) ? Math.max(rawFinalPrice, ball.minPrice) : rawFinalPrice;
}

const items = [];
const seen = new Set();
RAW.forEach(([name, image, price, tier, evo]) => {
  const key = name + '|' + (image || '');
  if (!seen.has(key)) { seen.add(key); items.push({ name, image: image || '', price: price || 0, tier: tier || '', evo: evo || '' }); }
});
// Store original index on each item for O(1) lookup
items.forEach((item, i) => { item._idx = i; });

document.getElementById('total-count').textContent = items.length + ' itens no índice';

const cart = {};
let pkgCartCount = {};
let _searchTimer;
let _capturaSearchTimer;
let _initialRender = true;

function getTag(item) {
  const n = item.name.toLowerCase();
  if (n.includes('shiny')) return 'shiny';
  if (n.includes('orb')) return 'orb';
  if (n.includes('essence')) return 'essence';
  return 'normal';
}


const TIER_CONFIG = {
  t1:   { label: 'T1',   cls: 'tier-t1' },
  t2:   { label: 'T2',   cls: 'tier-t2' },
  t3:   { label: 'T3',   cls: 'tier-t3' },
  t4:   { label: 'T4',   cls: 'tier-t4' },
  t5:   { label: 'T5',   cls: 'tier-t5' },
  hard: { label: 'HARD', cls: 'tier-hard' },
  mark: { label: 'MARK', cls: 'tier-mark' },
};

function getTierHtml(tier) {
  if (!tier) return '';
  const t = tier.toLowerCase();
  const cfg = TIER_CONFIG[t];
  if (!cfg) return '';
  return `<span class="tier-tag ${cfg.cls}">${cfg.label}</span>`;
}

function getEvoHtml(evo) {
  if (!evo) return '';
  const map = {
    evo1: { label: 'EVO 1', cls: 'evo-1' },
    evo2: { label: 'EVO 2', cls: 'evo-2' },
    evo3: { label: 'EVO 3', cls: 'evo-3' },
  };
  const cfg = map[evo.toLowerCase()];
  if (!cfg) return '';
  return `<span class="evo-tag ${cfg.cls}">${cfg.label}</span>`;
}

// ── getBannerHtml ──────────────────────────────────────────────────────────
// Gera a tag de banner exibida ACIMA da imagem do Pokémon.
// Campos do item que ela lê:
//   item.banner        → texto da tag  (string, obrigatório para mostrar)
//   item.bannerImage   → URL da imagem de fundo (opcional)
//
// Exemplos de uso no array `items`:
//   banner: "Evento Especial"
//   banner: "Novo!", bannerImage: "https://..."
// ──────────────────────────────────────────────────────────────────────────
function getBannerHtml(item) {
  if (!item.bannerImage && !item.banner) return "";
  if (item.bannerImage) {
    return `<div class="card-banner-tag has-img"><img src="${item.bannerImage}" alt="tipo" loading="lazy" onerror="this.parentElement.style.display='none'" /></div>`;
  }
  return `<div class="card-banner-tag text-only">${item.banner}</div>`;
}


// ── Mapa URL → tipo ─────────────────────────────────────────────────────────

const TYPE_COLORS = {
  fire:     '#ff6a00',
  water:    '#00aaff',
  electric: '#ffe600',
  grass:    '#44cc00',
  ice:      '#80e8ff',
  psychic:  '#ff44bb',
  ghost:    '#9900ff',
  dragon:   '#ffaa00',
  dark:     '#6666cc',
  fairy:    '#ff66bb',
  poison:   '#aa00cc',
  ground:   '#cc8800',
  rock:     '#aa8855',
  bug:      '#99cc00',
  flying:   '#aabbff',
  steel:    '#ccddee',
  normal:   '#bbbbbb',
  fighting: '#ff4400',
};
const BANNER_TYPE_MAP = [
  { url: 'zpRe43i', type: 'water'    },
  { url: 'GleRjiM', type: 'steel'    },
  { url: 'GvD1Mtq', type: 'rock'     },
  { url: 'ASiZi1K', type: 'psychic'  },
  { url: 'xfX0ReE', type: 'poison'   },
  { url: 'w2ChsIe', type: 'normal'   },
  { url: 'ssFz0sA', type: 'ice'      },
  { url: 'JPcD2l3', type: 'ground'   },
  { url: 'O8TONGE', type: 'fire'     },
  { url: 'YjKxtoE', type: 'grass'    },
  { url: 'Yv2WEYc', type: 'electric' },
  { url: '7Luj4az', type: 'dark'     },
  { url: 'o7JWbaN', type: 'dragon'   },
  { url: 'HuybbPn', type: 'ghost'    },
  { url: 'j3HaXTh', type: 'fairy'    },
  { url: 'npGjQae', type: 'flying'   },
  { url: 'V4IXR51', type: 'bug'      },
  { url: 'OKsJXh7', type: 'fighting' },
];

function getTypeFromBanner(bannerImage) {
  if (!bannerImage) return null;
  const match = BANNER_TYPE_MAP.find(m => bannerImage.includes(m.url));
  return match ? match.type : null;
}

function buildParticlesHtml(type) {
  if (!type) return '';
  const count = 8;
  let spans = '';
  for (let i = 0; i < count; i++) {
    const x     = (10 + Math.random() * 80).toFixed(1) + '%';
    const size  = (4 + Math.random() * 5).toFixed(1) + 'px';
    const dur   = (1.8 + Math.random() * 2).toFixed(2) + 's';
    const delay = (Math.random() * 2.5).toFixed(2) + 's';
    const drift = ((Math.random() - 0.5) * 30).toFixed(1) + 'px';
    spans += `<span style="--x:${x};--size:${size};--dur:${dur};--delay:${delay};--drift:${drift}"></span>`;
  }
  return `<div class="type-particles type-${type}">${spans}</div>`;
}

function render() {
  const q = document.getElementById('search').value.toLowerCase();
  const f = document.getElementById('filter').value;
  const grid = document.getElementById('grid');

  const visible = items.filter((item) => {
    const tag = getTag(item);
    const tier = (item.tier || '').toLowerCase();
    const matchQ = !q || item.name.toLowerCase().includes(q);
    const isTierFilter = ['t1','t2','t3','t4','t5','hard','mark'].includes(f);
    const matchF = f === 'all'
      || (isTierFilter && tier === f)
      || (!isTierFilter && f === 'normal' && !item.tier && tag === 'normal')
      || (!isTierFilter && !['normal'].includes(f) && tag === f);
    return matchQ && matchF;
  });

  document.getElementById('count-label').textContent = visible.length + ' itens';

  if (!visible.length) {
    grid.innerHTML = '<div class="no-results">Nenhum item encontrado.</div>';
    return;
  }

  grid.innerHTML = visible.map((item, vi) => {
    const i = item._idx;
    const tag = getTag(item);
    const inCart = cart[i] > 0;
    const src = '';
    const priceData = formatKK(item.price);
    const pack500Data = item.price ? formatKK(item.price * 500) : null;
    const pack1000Data = item.price ? formatKK(item.price * 1000) : null;

    // Cor do tipo para os preços
    const pokeType = getTypeFromBanner(item.bannerImage);
    const typeColor = (pokeType && TYPE_COLORS[pokeType]) ? TYPE_COLORS[pokeType] : (tag === 'shiny' ? '#ffd166' : '#60aaff');
    const typeColorDim = typeColor + 'aa'; // ~67% opacity via hex

    const priceHtml = priceData
      ? `<div class="price-block">
          <div class="price-row">
            <span class="price-label">Unit.</span>
            <span class="price-kk" style="color:${typeColor};text-shadow:0 0 10px ${typeColor}55">${priceData.label}</span>
            <span class="price-brl" style="color:${typeColorDim}">${priceData.brl}</span>
          </div>
          <div class="price-sep" style="background:linear-gradient(90deg,${typeColor}33,transparent 80%)"></div>
          <div class="price-row" id="total-row-${i}">
            <span class="price-label">Total</span>
            <span class="price-total-kk" style="color:${typeColor}99" id="total-kk-${i}">${priceData.label}</span>
            <span class="price-total-brl" id="total-brl-${i}">${priceData.brl}</span>
          </div>
        </div>`
      : `<div class="item-price"><span class="price-none">sem preço</span></div>`;
    const isGif = item.image && /\.gif$/i.test(item.image);
    const imgSrc = isGif ? getShowdownStaticSprite(item.name) : item.image;
    const imgGif = isGif ? getShowdownSprite(item.name) : '';
    const imgHtml = item.image
      ? `<div class="item-img-wrap">
           <img class="card-img${isGif ? ' card-img--gif' : ''}"
                src="${imgSrc}"
                ${isGif ? `data-gif="${imgGif}"` : ''}
                alt="${item.name}"
                loading="lazy" decoding="async"
                onerror="this.parentElement.style.display='none'" />
         </div>`
      : '';
    const pack500Label = pack500Data ? `<span class="pack-btn-qty">+500</span><span class="pack-btn-price">${pack500Data.label}</span><span class="pack-btn-brl">${pack500Data.brl}</span>` : `<span class="pack-btn-qty">+500</span>`;
    const pack1000Label = pack1000Data ? `<span class="pack-btn-qty">+1000</span><span class="pack-btn-price">${pack1000Data.label}</span><span class="pack-btn-brl">${pack1000Data.brl}</span>` : `<span class="pack-btn-qty">+1000</span>`;
    const animClass = _initialRender ? ' card-anim' : '';
    const dataType = pokeType ? ` data-type="${pokeType}"` : '';
    return `<div class="card${tag === 'shiny' ? ' is-shiny' : ''}${animClass}"${dataType}>
      ${getBannerHtml(item)}
      ${imgHtml}
      <div class="item-name">${item.name}<button class="wiki-lookup-btn" onclick="openWikiLookup('${item.name.replace(/'/g,"\\'")}', event)" title="Ver drops na Wiki"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></button></div>
      ${getTierHtml(item.tier)}
      ${getEvoHtml(item.evo)}
      ${src}
      ${priceHtml}
      <div class="card-footer pack-footer">
        <button class="pack-btn pack-btn-500" id="addbtn-${i}" onclick="addPackToCart(${i}, 500)">
          ${pack500Label}
        </button>
        <button class="pack-btn pack-btn-1000" onclick="addPackToCart(${i}, 1000)">
          ${pack1000Label}
        </button>
      </div>
      <div class="card-footer manual-footer">
        <input type="number" id="qty-${i}" value="1" min="1" max="100000" oninput="const v=parseInt(this.value,10); this.value=(isNaN(v)||v<1)?1:(v>100000?100000:v); updateTotalPrice(${i}, this.value)" onkeydown="if(event.key==='-'||event.key==='e')event.preventDefault()" />
        <div class="card-footer-added" style="flex:1">
          <button class="add-btn${inCart ? ' added' : ''}" id="manualaddbtn-${i}" onclick="addToCart(${i})" style="flex:1">
            <span id="addbtn-label-${i}">${inCart ? '✓ ' + cart[i].toLocaleString() : '⬟ Adicionar'}</span>
          </button>
          ${inCart ? `<button class="inline-rem-btn" id="rembtn-${i}" onclick="removeFromCart(${i})" title="Remover do carrinho">&#x2715;</button>` : `<span id="rembtn-${i}"></span>`}
        </div>
      </div>
    </div>`;
  }).join('');
  _initialRender = false;
}

function updateTotalPrice(i, rawVal) {
  const qty = Math.max(1, parseInt(rawVal, 10) || 1);
  const item = items[i];
  if (!item || !item.price) return;
  const totalPrice = item.price * qty;
  const data = formatKK(totalPrice);
  if (!data) return;
  const kkEl = document.getElementById('total-kk-' + i);
  const brlEl = document.getElementById('total-brl-' + i);
  if (kkEl) kkEl.textContent = data.label;
  if (brlEl) brlEl.textContent = data.brl;
}


function onNickInput() {
  const wrap = document.getElementById('nick-field-wrap');
  const err  = document.getElementById('nick-error');
  if (wrap) wrap.classList.remove('error');
  if (err)  err.classList.remove('visible');
}

// ============================================================
// Supabase — configuração
// ============================================================
const SUPABASE_URL = 'https://xzmefefcfwhlkmqrkxcd.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh6bWVmZWZjZndobGttcXJreGNkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg2MTA5MTEsImV4cCI6MjA5NDE4NjkxMX0.i9ESDqCP9fDdQrK0e-TkchbEJrAlZ6qhKh8-Yu6axAg';

// ── helpers compartilhados pelas duas funções ─────────────────────────────────

function _getCartNick() {
  const el = document.getElementById('cart-nick-input');
  return el ? el.value.trim() : '';
}

function _validateNick() {
  const nick = _getCartNick();
  if (!nick) {
    const wrap = document.getElementById('nick-field-wrap');
    const err  = document.getElementById('nick-error');
    if (wrap) { wrap.classList.remove('error'); void wrap.offsetWidth; wrap.classList.add('error'); }
    if (err)  err.classList.add('visible');
    const el = document.getElementById('cart-nick-input');
    if (el) el.focus();
  }
  return nick;
}

function _calcTotais(keys) {
  const TAXA_THRESHOLD = 10000000;
  const TAXA_VALOR     = 5000000;
  const grandTotalRaw   = keys.reduce((s, k) => s + (items[k]?.price ? items[k].price * cart[k] : 0), 0);
  const hasTaxa         = grandTotalRaw > 0 && grandTotalRaw < TAXA_THRESHOLD;
  const grandTotalFinal = hasTaxa ? grandTotalRaw + TAXA_VALOR : grandTotalRaw;
  return { grandTotalRaw, grandTotalFinal, hasTaxa, TAXA_VALOR };
}

function _buildPagamentoInfo(grandTotalFinal) {
  const mode = _currentPayMode;
  let pagamento_modo = mode;
  let pagamento_kk   = null;
  let pagamento_brl  = null;

  if (mode === 'kk') {
    const kkD = formatKK(_payTotalKk || grandTotalFinal);
    pagamento_kk = kkD ? kkD.label : null;
  } else if (mode === 'brl') {
    pagamento_brl = (grandTotalFinal / 1000000 * KK_TO_BRL)
      .toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  } else if (mode === 'mix') {
    const kkVal  = parseFloat(document.getElementById('mix-kk-input')?.value)  || 0;
    const brlVal = parseFloat(document.getElementById('mix-brl-input')?.value) || 0;
    const kkD    = kkVal > 0 ? formatKK(kkVal * 1000000) : null;
    pagamento_kk  = kkD  ? kkD.label : null;
    pagamento_brl = brlVal > 0
      ? brlVal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
      : null;
  }
  return { pagamento_modo, pagamento_kk, pagamento_brl };
}

function _showToastMsg(titulo, msg) {
  const toast      = document.getElementById('no-price-toast');
  const toastMsg   = document.getElementById('no-price-toast-msg');
  const toastTitle = toast ? toast.querySelector('.toast-title') : null;
  if (!toast) return;
  if (toastTitle) toastTitle.textContent = titulo;
  if (toastMsg)   toastMsg.textContent   = msg;
  toast.classList.add('show');
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => {
    toast.classList.remove('show');
    if (toastTitle) toastTitle.textContent = 'Atenção — item sem preço!';
  }, 5000);
}

async function _salvarPedidoSupabase(payload) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/pedidos`, {
    method:  'POST',
    headers: {
      'Content-Type':  'application/json',
      'apikey':        SUPABASE_KEY,
      'Authorization': 'Bearer ' + SUPABASE_KEY,
      'Prefer':        'return=representation',
    },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => '');
    throw new Error('Supabase ' + res.status + ': ' + txt);
  }
  const data = await res.json().catch(() => []);
  return Array.isArray(data) ? data[0] : data;
}

function _limparCarrinhoAposPedido() {
  Object.keys(cart).forEach(k => delete cart[k]);
  updateCartBadge();
  closeCart();
}

// ── sendToWhatsApp — agora salva no Supabase ──────────────────────────────────

async function sendToWhatsApp() {
  const keys = Object.keys(cart).filter(k => cart[k] > 0);
  if (!keys.length) return;

  const nick = _validateNick();
  if (!nick) return;

  const { grandTotalRaw, grandTotalFinal, hasTaxa, TAXA_VALOR } = _calcTotais(keys);

  const itensPedido = keys.map(k => {
    const item    = items[k];
    const qty     = cart[k];
    const unitRaw = item.price || 0;
    const totRaw  = unitRaw * qty;
    return {
      nome:            item.name,
      tier:            item.tier || '',
      quantidade:      qty,
      preco_unit_raw:  unitRaw,
      preco_unit_kk:   unitRaw > 0 ? (formatKK(unitRaw)?.label || '—') : '—',
      preco_unit_brl:  unitRaw > 0
        ? (unitRaw / 1000000 * KK_TO_BRL).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
        : '—',
      preco_total_raw: totRaw,
      preco_total_kk:  totRaw  > 0 ? (formatKK(totRaw)?.label  || '—') : '—',
      preco_total_brl: totRaw  > 0
        ? (totRaw / 1000000 * KK_TO_BRL).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
        : '—',
    };
  });

  const { pagamento_modo, pagamento_kk, pagamento_brl } = _buildPagamentoInfo(grandTotalFinal);

  const payload = {
    nick_jogo:      nick,
    itens:          itensPedido,
    subtotal_kk:    grandTotalRaw  > 0 ? (formatKK(grandTotalRaw)?.label  || '—') : '—',
    subtotal_brl:   grandTotalRaw  > 0
      ? (grandTotalRaw  / 1000000 * KK_TO_BRL).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
      : '—',
    taxa_servico:   hasTaxa,
    total_kk:       grandTotalFinal > 0 ? (formatKK(grandTotalFinal)?.label || '—') : '—',
    total_brl:      grandTotalFinal > 0
      ? (grandTotalFinal / 1000000 * KK_TO_BRL).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
      : '—',
    pagamento_modo,
    pagamento_kk,
    pagamento_brl,
    status:         'pendente',
  };

  // Desabilita botão durante o envio
  const btn = document.querySelector('[onclick="sendToWhatsApp()"]');
  const originalLabel = btn ? btn.innerHTML : null;
  if (btn) { btn.disabled = true; btn.innerHTML = '⏳ Salvando...'; }

  try {
    const saved   = await _salvarPedidoSupabase(payload);
    const pedidoId = saved?.id ? ' #' + String(saved.id).padStart(4, '0') : '';
    _limparCarrinhoAposPedido();
    _showToastMsg(
      '✅ Pedido enviado!' + pedidoId,
      'Seu pedido foi registrado com sucesso. Aguarde o contato do vendedor para confirmar a entrega.'
    );
  } catch (err) {
    console.error('[Supabase]', err);
    _showToastMsg(
      '❌ Erro ao salvar pedido',
      'Não foi possível registrar o pedido. Verifique sua conexão e tente novamente.'
    );
  } finally {
    if (btn) { btn.disabled = false; btn.innerHTML = originalLabel; }
  }
}

// ── sendToDiscord — redireciona para o mesmo fluxo Supabase ──────────────────

async function sendToDiscord() {
  await sendToWhatsApp();
}

// ===================== TOAST SEM PREÇO =====================
let _toastTimer = null;
function showNoPriceToast(itemName) {
  const toast = document.getElementById('no-price-toast');
  const msg   = document.getElementById('no-price-toast-msg');
  if (!toast) return;
  if (msg) msg.textContent = '"' + itemName + '" ainda não tem valor definido. O total do carrinho será ajustado assim que o preço for estabelecido.';
  toast.classList.add('show');
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => toast.classList.remove('show'), 5000);
}

function addPackToCart(i, qty) {
  cart[i] = (cart[i] || 0) + qty;
  if (!items[i].price) showNoPriceToast(items[i].name);
  updateCartBadge();
  // Atualiza botão 500 como "added" e mostra quantidade total
  const btn = document.getElementById('addbtn-' + i);
  if (btn) btn.classList.add('added');
  // Mostra botão remover inline se ainda não estiver visível
  const remSlot = document.getElementById('rembtn-' + i);
  if (remSlot && remSlot.tagName === 'SPAN') {
    const remBtn = document.createElement('button');
    remBtn.className = 'inline-rem-btn';
    remBtn.id = 'rembtn-' + i;
    remBtn.title = 'Remover do carrinho';
    remBtn.innerHTML = '\u2715';
    remBtn.onclick = () => removeFromCart(i);
    remSlot.replaceWith(remBtn);
  }
  if (document.getElementById('cart-overlay').classList.contains('open')) renderCart();
}

function addToCart(i) {
  const input = document.getElementById('qty-' + i);
  let val = parseInt(input ? input.value : 1, 10);
  if (isNaN(val) || val < 1) val = 1;
  if (val > 100000) val = 100000;
  cart[i] = (cart[i] || 0) + val;
  // Avisa se o item não tem preço definido
  if (!items[i].price) {
    showNoPriceToast(items[i].name);
  }
  updateCartBadge();
  // Atualiza label do botão com a quantidade total no carrinho
  const btn = document.getElementById('addbtn-' + i);
  const lbl = document.getElementById('addbtn-label-' + i);
  if (btn) { btn.classList.add('added'); }
  if (lbl) { lbl.textContent = '\u2713 ' + cart[i].toLocaleString(); }
  // Mostra botão remover inline se ainda não estiver visível
  const remSlot = document.getElementById('rembtn-' + i);
  if (remSlot && remSlot.tagName === 'SPAN') {
    const remBtn = document.createElement('button');
    remBtn.className = 'inline-rem-btn';
    remBtn.id = 'rembtn-' + i;
    remBtn.title = 'Remover do carrinho';
    remBtn.innerHTML = '\u2715';
    remBtn.onclick = () => removeFromCart(i);
    remSlot.replaceWith(remBtn);
  }
  // Atualiza carrinho se estiver aberto
  if (document.getElementById('cart-overlay').classList.contains('open')) {
    renderCart();
  }
}

function updateCartBadge() {
  const keys = Object.keys(cart).filter(k => cart[k] > 0);
  const total = keys.reduce((s, k) => s + cart[k], 0);
  const text = total.toLocaleString();
  const badge = document.getElementById('cart-count-badge');
  if (badge) {
    badge.textContent = text;
    const headerBtn = badge.closest('button');
    if (headerBtn) {
      headerBtn.classList.remove('bump');
      void headerBtn.offsetWidth;
      headerBtn.classList.add('bump');
    }
  }
}

function openCart() {
  renderCart();
  document.getElementById('cart-overlay').classList.add('open');
}

function closeCart() {
  document.getElementById('cart-overlay').classList.remove('open');
}

function handleOverlayClick(e) {
  if (e.target === document.getElementById('cart-overlay')) closeCart();
}

function renderCart() {
  const list = document.getElementById('cart-list');
  const footer = document.getElementById('cart-footer');
  const keys = Object.keys(cart).filter(k => cart[k] > 0);

  if (!keys.length) {
    const warnBannerEmpty = document.getElementById('cart-no-price-warning');
    if (warnBannerEmpty) warnBannerEmpty.classList.remove('visible');
    list.innerHTML = `<div class="cart-empty">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="1.5">
        <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
      </svg>
      <span>Carrinho vazio</span>
    </div>`;
    footer.style.display = 'none';
    return;
  }

  const total = keys.reduce((s, k) => s + cart[k], 0);
  const grandTotalRaw = keys.reduce((s, k) => {
    const item = items[k];
    return s + (item && item.price ? item.price * cart[k] : 0);
  }, 0);
  document.getElementById('cart-total-num').textContent = total.toLocaleString();
  footer.style.display = 'block';

  const TAXA_THRESHOLD = 10000000; // 10kk
  const TAXA_VALOR = 5000000;      // 5kk

  // Update grand total in footer
  const gtKkEl = document.getElementById('cart-grand-kk');
  const gtBrlEl = document.getElementById('cart-grand-brl');
  const gtKkFinalEl = document.getElementById('cart-grand-kk-final');
  const taxaRow = document.getElementById('cart-taxa-row');
  const taxaAviso = document.getElementById('cart-taxa-aviso');
  const totalFinalRow = document.getElementById('cart-total-final-row');
  if (grandTotalRaw > 0) {
    const hasTaxa = grandTotalRaw < TAXA_THRESHOLD;
    const grandTotalFinal = hasTaxa ? grandTotalRaw + TAXA_VALOR : grandTotalRaw;
    const gtData = formatKK(grandTotalRaw);
    const gtFinalData = formatKK(grandTotalFinal);
    if (gtKkEl) gtKkEl.textContent = gtData.label;
    // BRL is always based on final total
    if (gtBrlEl) gtBrlEl.textContent = formatKK(grandTotalFinal).brl;
    if (taxaAviso) taxaAviso.style.display = hasTaxa ? 'flex' : 'none';
    if (taxaRow) taxaRow.style.display = hasTaxa ? 'flex' : 'none';
    if (totalFinalRow) totalFinalRow.style.display = hasTaxa ? 'flex' : 'none';
    if (gtKkFinalEl && hasTaxa) gtKkFinalEl.textContent = gtFinalData.label;
    document.getElementById('cart-grand-total-block').style.display = 'block';
    // Atualiza painel de pagamento
    updatePayDisplay(grandTotalRaw, grandTotalFinal, parseFloat((grandTotalFinal / 1000000 * 1.70).toFixed(2)));
  } else {
    document.getElementById('cart-grand-total-block').style.display = 'none';
    if (taxaAviso) taxaAviso.style.display = 'none';
  }

  // Verifica itens sem preço e exibe aviso
  const noPriceItems = keys.filter(k => !items[k].price);
  const warnBanner = document.getElementById('cart-no-price-warning');
  const warnList   = document.getElementById('cart-warn-items-list');
  if (warnBanner) {
    if (noPriceItems.length > 0) {
      warnBanner.classList.add('visible');
      if (warnList) warnList.textContent = 'Sem preço: ' + noPriceItems.map(k => items[k].name).join(', ');
    } else {
      warnBanner.classList.remove('visible');
      if (warnList) warnList.textContent = '';
    }
  }

  list.innerHTML = keys.map(k => {
    const item = items[k];
    const isCaptura = !!item._capturaId;
    const imgHtml = isCaptura && item.image
      ? `<img src="${item.image}" style="width:38px;height:38px;object-fit:contain;border-radius:6px;background:rgba(0,0,0,0.25);flex-shrink:0" onerror="this.style.display='none'" />`
      : '';
    const ballHtml = isCaptura && item._ballEmoji
      ? `<span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;color:var(--gold);font-family:var(--font-mono)">${item._ballEmoji.replace('width:40px;height:40px','width:18px;height:18px')}</span>`
      : '';
    const itemTotalRaw = item.price ? item.price * cart[k] : 0;
    const priceBlock = itemTotalRaw > 0
      ? (() => {
          const unitData = formatKK(item.price);
          const totalData = formatKK(itemTotalRaw);
          return `<div class="cart-price-block">
            <span class="cart-price-kk">${totalData.label}</span>
            <span class="cart-price-brl">${totalData.brl}</span>
            <span style="font-family:var(--font-mono);font-size:10px;color:var(--muted)">unit: ${unitData.label}</span>
          </div>`;
        })()
      : '';
    return `<div class="cart-row">
      <div style="display:flex;align-items:center;gap:8px;min-width:0">
        ${imgHtml}
        <div style="min-width:0">
          <div class="cart-row-name" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">${item.name} ${ballHtml}</div>
        </div>
      </div>
      <div class="cart-row-right">
        ${priceBlock}
        <span class="cart-qty">×${cart[k].toLocaleString()}</span>
        <button class="rem-btn" onclick="removeFromCart(${k})">&#x2715;</button>
      </div>
    </div>`;
  }).join('');
}

// ===================== PAYMENT MODE =====================
let _payTotalKk = 0;  // total final em KK (após taxa)
let _payTotalBrl = 0; // total final em BRL
let _currentPayMode = 'kk';

function setPayMode(mode) {
  _currentPayMode = mode;
  document.querySelectorAll('.pay-mode-btn').forEach(b => b.classList.remove('active'));
  document.querySelector('.pay-mode-btn.' + mode).classList.add('active');
  document.querySelectorAll('.pay-block').forEach(b => b.classList.remove('active'));
  document.getElementById('pay-block-' + mode).classList.add('active');
  if (mode === 'mix') syncMixInputs();
}

function updatePayDisplay(totalKkRaw, totalFinalKkRaw, totalFinalBrl) {
  _payTotalKk  = totalFinalKkRaw;
  _payTotalBrl = totalFinalBrl;

  // KK block
  const kkData = formatKK(totalFinalKkRaw);
  document.getElementById('pay-kk-total').textContent    = kkData ? kkData.label : '—';
  document.getElementById('pay-kk-brl-hint').textContent = kkData ? 'equivale a ' + kkData.brl : '';

  // BRL block
  const brlStr = (totalFinalBrl).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const kkHint = kkData ? kkData.label + ' KK' : '—';
  document.getElementById('pay-brl-total').textContent    = brlStr;
  document.getElementById('pay-brl-kk-hint').textContent  = 'equivale a ' + kkHint;

  // Mix: reset inputs quando o total muda
  if (_currentPayMode === 'mix') syncMixInputs(true);
  else {
    document.getElementById('mix-kk-input').value  = '';
    document.getElementById('mix-brl-input').value = '';
    document.getElementById('mix-balance').textContent = 'Preencha os valores acima';
    document.getElementById('mix-balance').className   = 'pay-mix-balance';
  }
}

function syncMixInputs(reset) {
  if (reset) {
    document.getElementById('mix-kk-input').value  = '';
    document.getElementById('mix-brl-input').value = '';
    document.getElementById('mix-balance').textContent = 'Preencha os valores acima';
    document.getElementById('mix-balance').className   = 'pay-mix-balance';
  }
}

function onMixKkChange(val) {
  const kkPaid  = Math.max(0, parseFloat(val) || 0);
  // kk inserido é em unidades de kk (ex: 5 = 5kk = 5_000_000)
  const kkPaidRaw = kkPaid * 1000000;
  const remaining = _payTotalBrl - (kkPaidRaw / 1000000 * 1.70);
  const brlLeft = Math.max(0, _payTotalBrl - (kkPaidRaw / 1000000 * 1.70));
  // Atualiza campo BRL
  document.getElementById('mix-brl-input').value = brlLeft > 0 ? brlLeft.toFixed(2) : '0.00';
  updateMixBalance(kkPaidRaw, brlLeft);
}

function onMixBrlChange(val) {
  const brlPaid = Math.max(0, parseFloat(val) || 0);
  const brlLeft = Math.max(0, _payTotalBrl - brlPaid);
  // converte o restante em KK
  const kkLeft  = brlLeft / 1.70; // 1kk = R$1.70
  document.getElementById('mix-kk-input').value = kkLeft > 0 ? kkLeft.toFixed(4) : '0';
  updateMixBalance(kkLeft * 1000000, brlPaid);
}

function updateMixBalance(kkPaidRaw, brlPaid) {
  const totalPaidBrl = (kkPaidRaw / 1000000 * 1.70) + brlPaid;
  const diff = totalPaidBrl - _payTotalBrl;
  const el   = document.getElementById('mix-balance');
  const kkData = formatKK(kkPaidRaw);
  const brlStr = brlPaid.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  if (Math.abs(diff) < 0.01) {
    el.textContent = '✓ Pagamento completo: ' + (kkData ? kkData.label + ' KK' : '0') + ' + ' + brlStr;
    el.className = 'pay-mix-balance ok';
  } else if (diff < 0) {
    const falta = Math.abs(diff).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    el.textContent = 'Falta ' + falta + ' para completar';
    el.className = 'pay-mix-balance';
  } else {
    const excesso = diff.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    el.textContent = 'Excedendo ' + excesso + ' do total';
    el.className = 'pay-mix-balance over';
  }
}

function removeFromCart(i) {
  delete cart[i];
  // Reseta botão adicionar
  const btn = document.getElementById('addbtn-' + i);
  const lbl = document.getElementById('addbtn-label-' + i);
  if (btn) { btn.classList.remove('added'); }
  if (lbl) { lbl.textContent = 'Adicionar'; }
  // Remove botão inline de remover, volta para span vazio
  const remBtn = document.getElementById('rembtn-' + i);
  if (remBtn && remBtn.tagName === 'BUTTON') {
    const span = document.createElement('span');
    span.id = 'rembtn-' + i;
    remBtn.replaceWith(span);
  }
  updateCartBadge();
  renderCart();
}

function clearCart() {
  Object.keys(cart).forEach(k => {
    const btn = document.getElementById('addbtn-' + k);
    const lbl = document.getElementById('addbtn-label-' + k);
    if (btn) { btn.classList.remove('added'); }
    if (lbl) { lbl.textContent = 'Adicionar'; }
    const remBtn = document.getElementById('rembtn-' + k);
    if (remBtn && remBtn.tagName === 'BUTTON') {
      const span = document.createElement('span');
      span.id = 'rembtn-' + k;
      remBtn.replaceWith(span);
    }
    delete cart[k];
  });
  // Reseta botões de pacote
  pkgCartCount = {};
  PACKAGES.forEach((_, pi) => {
    const pkgBtn = document.getElementById('pkgbtn-' + pi);
    const pkgLbl = document.getElementById('pkgbtn-label-' + pi);
    if (pkgBtn) { pkgBtn.classList.remove('added'); }
    if (pkgLbl) { pkgLbl.textContent = '+ Adicionar ao Carrinho'; }
    const pkgRemBtn = document.getElementById('pkgrem-' + pi);
    if (pkgRemBtn && pkgRemBtn.tagName === 'BUTTON') {
      const span = document.createElement('span');
      span.id = 'pkgrem-' + pi;
      pkgRemBtn.replaceWith(span);
    }
  });
  updateCartBadge();
  renderCart();
}

// ===================== TABS =====================
function switchTab(tab, btn) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
  btn.classList.add('active');
  if (tab === 'pacotes') renderPackages();
  if (tab === 'captura') renderCaptura();
  if (tab === 'wiki') renderWiki();
}

// ===================== WIKI =====================
let _wikiSearchTimer;
let _wikiRendered = false;

// Build wiki data from RAW_WIKI
function buildWikiData() {
  var seen = new Set();
  return RAW_WIKI.map(function(entry) {
    var name = entry[0];
    var sources = entry.slice(1).filter(function(s) { return s && s.trim() !== ''; });
    return { name: name, sources: sources };
  }).filter(function(item) {
    if (item.sources.length === 0) return false;
    if (seen.has(item.name)) return false;
    seen.add(item.name);
    return true;
  });
}

function renderWiki() {
  var grid = document.getElementById('wiki-grid');
  if (!grid) return;
  var q = (document.getElementById('wiki-search') ? document.getElementById('wiki-search').value : '').toLowerCase().trim();
  var wikiItems = buildWikiData();

  var filtered = wikiItems.filter(function(item) {
    if (item.sources.length === 0) return false;
    if (!q) return true;
    return item.name.toLowerCase().includes(q) ||
           item.sources.some(function(s) { return s.toLowerCase().includes(q); });
  });

  document.getElementById('wiki-count-label').textContent = filtered.length + ' itens';

  if (!filtered.length) {
    grid.innerHTML = '<div class="wiki-no-results">Nenhum item encontrado.</div>';
    return;
  }

  grid.innerHTML = filtered.map(function(item, idx) {
    var sourcesLabel = item.sources.join(', ');
    var pokeCards = item.sources.map(function(pokeName) {
      var sprite = getShowdownSprite(pokeName);
      return '<div class="wiki-poke-card">' +
        '<img class="wiki-poke-sprite" src="' + sprite + '" alt="' + pokeName + '" ' +
        'onerror="this.src=\'https://play.pokemonshowdown.com/sprites/gen5/' + toShowdownName(pokeName) + '.png\'" />' +
        '<div class="wiki-poke-name">' + pokeName + '</div>' +
        '</div>';
    }).join('');

    return '<div class="wiki-row" id="wiki-row-' + idx + '">' +
      '<div class="wiki-row-header" onclick="toggleWikiRow(' + idx + ')">' +
        '<span class="wiki-row-num">' + (idx + 1) + '</span>' +
        '<span class="wiki-row-name">' + item.name + '</span>' +
        '<svg class="wiki-row-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>' +
      '</div>' +
      '<div class="wiki-row-panel">' + pokeCards + '</div>' +
    '</div>';
  }).join('');
}

function toggleWikiRow(idx) {
  var row = document.getElementById('wiki-row-' + idx);
  if (!row) return;
  var isOpen = row.classList.contains('open');
  // fecha todos
  document.querySelectorAll('.wiki-row.open').forEach(function(r) { r.classList.remove('open'); });
  // abre o clicado se estava fechado
  if (!isOpen) row.classList.add('open');
}

// ===================== WIKI SUB-TABS =====================
var _currentWikiTab = 'itens';
var _respawnSearchTimer, _questsSearchTimer, _rocketsSearchTimer, _officersSearchTimer, _hazardSearchTimer;

function switchWikiTab(tab, btn) {
  _currentWikiTab = tab;
  // botões
  document.querySelectorAll('.wiki-subtab-btn').forEach(function(b) { b.classList.remove('active'); });
  if (btn) btn.classList.add('active');
  // painéis
  document.querySelectorAll('.wiki-subtab-content').forEach(function(el) { el.style.display = 'none'; });
  var panel = document.getElementById('wiki-tab-' + tab);
  if (panel) panel.style.display = 'block';
  // renderiza a sub-aba
  if (tab === 'itens') renderWiki();
  if (tab === 'respawn') renderRespawn();
  if (tab === 'quests') renderQuests();
  if (tab === 'brokes') renderBrokes();
  if (tab === 'hazard') renderHazard();
  if (tab === 'npcs') {
    // Abre a sub-aba de NPC's e renderiza a categoria ativa (padrão: rockets)
    var activeNpcBtn = document.querySelector('.npc-subcat-btn.active');
    var activeSubcat = activeNpcBtn ? activeNpcBtn.getAttribute('data-subcat') || 'rockets' : 'rockets';
    switchNpcSubcat(activeSubcat, activeNpcBtn);
  }
  if (tab === 'starcalc') renderStarCalc();
  if (tab === 'punchingbag') renderPunchingBag();
  if (tab === 'roupasspeed') renderRoupasSpeed();
  if (tab === 'talents') renderTalents();
  if (tab === 'tokens') renderTokens();
}

// ===================== WIKI: BROKES =====================
function renderBrokes() {
  var el = document.getElementById('wiki-brokes-content');
  if (!el) return;
  el.innerHTML = `
  <div class="brokes-page">
    <!-- Hero -->
    <div class="brokes-hero">
      <div class="brokes-hero-icon">💥</div>
      <div class="brokes-hero-title">Sistema de Brokes</div>
      <div class="brokes-hero-sub">Entenda o sistema de brokes e aumente suas chances de captura</div>
    </div>

    <!-- Tabela de Max Brokes por Tier -->
    <div class="brokes-section">
      <div class="brokes-section-title">
        <span class="brokes-section-icon">📊</span>
        Max Brokes por Tier
      </div>
      <div class="brokes-section-note">Válido apenas para Shinys — Pokémon normal não tem max.</div>
      <div class="brokes-table-wrap">
        <table class="brokes-table">
          <thead>
            <tr>
              <th>Tier</th>
              <th>Max Broke</th>
              <th>Equivale a</th>
            </tr>
          </thead>
          <tbody>
            <tr class="tier-mythical-row">
              <td><span class="ctag-mythical captura-tag">Mítico</span></td>
              <td class="broke-val-cell"><span class="broke-question">?</span><span class="broke-tbd">A ser confirmado</span></td>
              <td class="broke-equiv">—</td>
            </tr>
            <tr>
              <td><span class="ctag-legendary captura-tag">Legendary</span></td>
              <td class="broke-val-cell"><span class="broke-number">22.535</span><span class="broke-unit">UB</span></td>
              <td class="broke-equiv">Premier Ball: ~29.295 · Alliance: ~33.802</td>
            </tr>
            <tr>
              <td><span class="ctag-ultra-raro captura-tag">Ultra Raro</span></td>
              <td class="broke-val-cell"><span class="broke-number">9.100</span><span class="broke-unit">UB</span></td>
              <td class="broke-equiv">Premier Ball: ~11.830 · Alliance: ~13.650</td>
            </tr>
            <tr>
              <td><span class="ctag-super-raro captura-tag">Super Raro</span></td>
              <td class="broke-val-cell"><span class="broke-number">3.512</span><span class="broke-unit">UB</span></td>
              <td class="broke-equiv">Premier Ball: ~4.565 · Alliance: ~5.268</td>
            </tr>
            <tr>
              <td><span class="ctag-t1 captura-tag">T1</span></td>
              <td class="broke-val-cell"><span class="broke-number">1.280</span><span class="broke-unit">UB</span></td>
              <td class="broke-equiv">Premier Ball: ~1.664 · Alliance: ~1.920</td>
            </tr>
            <tr>
              <td><span class="ctag-t2 captura-tag">T2</span></td>
              <td class="broke-val-cell"><span class="broke-approx">~</span><span class="broke-number">900</span><span class="broke-unit">UB</span></td>
              <td class="broke-equiv">Premier Ball: ~1.170 · Alliance: ~1.350</td>
            </tr>
            <tr>
              <td><span class="ctag-t3 captura-tag">T3</span></td>
              <td class="broke-val-cell"><span class="broke-approx">~</span><span class="broke-number">700</span><span class="broke-unit">UB</span></td>
              <td class="broke-equiv">Premier Ball: ~910 · Alliance: ~1.050</td>
            </tr>
            <tr>
              <td><span class="ctag-t4 captura-tag">T4</span></td>
              <td class="broke-val-cell"><span class="broke-approx">~</span><span class="broke-number">600</span><span class="broke-unit">UB</span></td>
              <td class="broke-equiv">Premier Ball: ~780 · Alliance: ~900</td>
            </tr>
            <tr>
              <td><span class="ctag-t5 captura-tag">T5</span></td>
              <td class="broke-val-cell"><span class="broke-approx">~</span><span class="broke-number">400</span><span class="broke-unit">UB</span></td>
              <td class="broke-equiv">Premier Ball: ~520 · Alliance: ~600</td>
            </tr>
            <tr>
              <td><span class="ctag-t6 captura-tag">T6</span></td>
              <td class="broke-val-cell"><span class="broke-approx">~</span><span class="broke-number">200</span><span class="broke-unit">UB</span></td>
              <td class="broke-equiv">Premier Ball: ~260 · Alliance: ~300</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Rates das bolas -->
    <div class="brokes-section">
      <div class="brokes-section-title">
        <span class="brokes-section-icon">⚾</span>
        Rates das Poké Balls
      </div>
      <div class="brokes-balls-grid">
        <div class="brokes-ball-card">
          <div class="brokes-ball-emoji"><img src="https://i.imgur.com/D5T6Dgw.png" style="width:48px;height:48px;object-fit:contain" /></div>
          <div class="brokes-ball-name">Ultra Ball</div>
          <div class="brokes-ball-rate rate-ub">4x</div>
          <div class="brokes-ball-desc">Rate base para captura</div>
        </div>
        <div class="brokes-ball-card">
          <div class="brokes-ball-emoji"><img src="https://i.imgur.com/sIwvw2L.png" style="width:48px;height:48px;object-fit:contain" /></div>
          <div class="brokes-ball-name">Premier Ball</div>
          <div class="brokes-ball-rate rate-pb">4x</div>
          <div class="brokes-ball-desc">Conta como 1ª bola jogada. Contabiliza para brokes totais.</div>
        </div>
        <div class="brokes-ball-card">
          <div class="brokes-ball-emoji"><img src="https://i.imgur.com/QFXUD5f.png" style="width:48px;height:48px;object-fit:contain" /></div>
          <div class="brokes-ball-name">Alliance Ball</div>
          <div class="brokes-ball-rate rate-ab">5x</div>
          <div class="brokes-ball-desc">Conta como 1ª bola jogada. Contabiliza para brokes totais.</div>
        </div>
        <div class="brokes-ball-card brokes-ball-card--elemental">
          <div class="brokes-ball-emoji">🌀</div>
          <div class="brokes-ball-name">Elemental Ball</div>
          <div class="brokes-ball-rate rate-el">5x</div>
          <div class="brokes-ball-desc">Rate aumentado com vantagem elemental</div>
        </div>
      </div>
    </div>

    <!-- Observações importantes -->
    <div class="brokes-section">
      <div class="brokes-section-title">
        <span class="brokes-section-icon">📋</span>
        Regras & Observações
      </div>
      <div class="brokes-obs-list">
        <div class="brokes-obs-item">
          <span class="brokes-obs-num">1</span>
          <span class="brokes-obs-text">Premier Ball e Alliance Ball contam sempre como a <strong>primeira bola jogada</strong>.</span>
        </div>
        <div class="brokes-obs-item">
          <span class="brokes-obs-num">2</span>
          <span class="brokes-obs-text">Premier Ball e Alliance Ball contam para a <strong>contagem de brokes totais</strong>.</span>
        </div>
        <div class="brokes-obs-item">
          <span class="brokes-obs-num">3</span>
          <span class="brokes-obs-text">O max é um valor <strong>não oficial</strong> descoberto pela comunidade, e <strong>pode mudar a qualquer momento</strong>.</span>
        </div>
        <div class="brokes-obs-item brokes-obs-item--highlight">
          <span class="brokes-obs-num">4</span>
          <span class="brokes-obs-text"><strong>As brokes são pra shinys.</strong> Pokémon normal não tem max.</span>
        </div>
        <div class="brokes-obs-item">
          <span class="brokes-obs-num">5</span>
          <span class="brokes-obs-text">Chegar na <strong>máxima não garante o catch</strong>. A chance só fica muito mais alta.</span>
        </div>
        <div class="brokes-obs-item">
          <span class="brokes-obs-num">6</span>
          <span class="brokes-obs-text">O <strong>sistema de mérito</strong> considera o total de brokes. Os rates não têm nada a ver com ele.</span>
        </div>
      </div>
    </div>
  </div>
  `;
}

// ===================== DADOS DE RESPAWN =====================
// RAW_RESPAWN é definido em respawn_patch_modal.js
// Certifique-se de que respawn_patch_modal.js é carregado ANTES de app.js no index.html


// ── CSS para os novos cards ──────────────────────────────────────────
(function injectRespawnCSS() {
  if (document.getElementById('respawn-v2-css')) return;
  var s = document.createElement('style');
  s.id = 'respawn-v2-css';
  s.textContent = `
/* ── Layout geral ── */
#respawn-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 14px;
  padding: 4px 0 20px;
}

/* ── Card base ── */
.rsp-card-v2 {
  position: relative;
  border-radius: 18px;
  border: 1.5px solid var(--rsp-card-border, rgba(255,255,255,0.10));
  background: var(--rsp-card-bg, rgba(255,255,255,0.03));
  overflow: hidden;
  cursor: pointer;
  transition: transform .22s, border-color .22s, box-shadow .22s, background .22s;
  user-select: none;
}
.rsp-card-v2::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse at 50% -5%, var(--rsp-glow-c, rgba(100,180,255,0.08)), transparent 70%);
  pointer-events: none;
}
.rsp-card-v2:hover {
  transform: translateY(-3px);
  border-color: var(--rsp-accent, rgba(100,180,255,0.4));
  box-shadow: 0 8px 32px var(--rsp-shadow, rgba(100,180,255,0.15));
}
.rsp-card-v2.open {
  border-color: var(--rsp-accent, rgba(100,180,255,0.5));
  box-shadow: 0 0 40px var(--rsp-shadow, rgba(100,180,255,0.2)), 0 6px 30px rgba(0,0,0,0.5);
  background: var(--rsp-card-bg-open, rgba(255,255,255,0.05));
}

/* ── Sprite wrapper ── */
.rsp-sprite-wrap {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100px;
  padding: 10px 8px 4px;
  position: relative;
}
.rsp-sprite-static, .rsp-sprite-anim {
  max-width: 96px;
  max-height: 96px;
  object-fit: contain;
  image-rendering: pixelated;
  filter: drop-shadow(0 4px 10px var(--rsp-shadow, rgba(100,180,255,0.25)));
  transition: opacity .25s;
}
.rsp-sprite-anim {
  position: absolute;
  opacity: 0;
  transition: opacity .25s;
}
.rsp-card-v2.open .rsp-sprite-static { opacity: 0; }
.rsp-card-v2.open .rsp-sprite-anim   { opacity: 1; }

/* ── Info area ── */
.rsp-card-foot {
  padding: 6px 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 5px;
}
.rsp-card-name {
  font-family: var(--font-title, 'Cinzel', serif);
  font-size: 13px;
  font-weight: 700;
  color: var(--rsp-accent, #fff);
  letter-spacing: 0.3px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.rsp-type-row {
  display: flex;
  gap: 4px;
  flex-wrap: wrap;
}
.rsp-type-badge {
  font-family: var(--font-body, sans-serif);
  font-size: 10px;
  font-weight: 700;
  padding: 2px 7px;
  border-radius: 8px;
  border: 1px solid;
  letter-spacing: 0.5px;
  text-transform: uppercase;
}
.rsp-wildscape-dot {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 10px;
  color: rgba(255,255,255,0.4);
  font-family: var(--font-mono, monospace);
}
.rsp-wildscape-dot::before {
  content: '';
  width: 6px; height: 6px;
  border-radius: 50%;
  background: #ffcc44;
  box-shadow: 0 0 5px #ffcc44aa;
  flex-shrink: 0;
}

/* ── Expanded panel ── */
.rsp-expanded-panel {
  max-height: 0;
  overflow: hidden;
  transition: max-height .45s cubic-bezier(.4,0,.2,1), opacity .3s;
  opacity: 0;
}
.rsp-card-v2.open .rsp-expanded-panel {
  max-height: 520px;
  opacity: 1;
}
.rsp-panel-inner {
  padding: 0 12px 16px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.rsp-sep-line {
  height: 1px;
  background: linear-gradient(90deg, var(--rsp-accent, rgba(100,180,255,0.3)), transparent);
  margin-bottom: 2px;
}
.rsp-loc-row {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  font-size: 11px;
  color: rgba(255,255,255,0.55);
  font-family: var(--font-body, sans-serif);
  line-height: 1.4;
}
.rsp-loc-icon { flex-shrink: 0; font-size: 13px; }
.rsp-map-frame {
  border-radius: 10px;
  overflow: hidden;
  border: 1px solid var(--rsp-accent, rgba(100,180,255,0.2));
  line-height: 0;
  background: rgba(0,0,0,0.25);
}
.rsp-map-frame img {
  width: 100%;
  height: auto;
  display: block;
  max-height: 280px;
  object-fit: cover;
}
.rsp-map-link {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 11px;
  font-family: var(--font-body, sans-serif);
  color: var(--rsp-accent, #60aaff);
  text-decoration: none;
  opacity: 0.8;
  transition: opacity .15s;
  padding: 4px 0;
}
.rsp-map-link:hover { opacity: 1; }
.rsp-wildscape-link {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 11px;
  font-family: var(--font-body, sans-serif);
  color: #ffcc44;
  text-decoration: none;
  opacity: 0.8;
  transition: opacity .15s;
}
.rsp-wildscape-link:hover { opacity: 1; }
.rsp-map-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 16px;
  color: rgba(255,255,255,0.2);
  font-size: 11px;
  font-family: var(--font-body, sans-serif);
  border-radius: 10px;
  border: 1px dashed rgba(255,255,255,0.1);
  background: rgba(0,0,0,0.15);
}
.rsp-map-placeholder-icon { font-size: 20px; }

/* ── List mode override ── */
.respawn-list-mode #respawn-grid {
  grid-template-columns: 1fr;
}
.respawn-list-mode .rsp-card-v2 {
  display: flex;
  flex-direction: row;
  align-items: center;
  border-radius: 14px;
}
.respawn-list-mode .rsp-sprite-wrap {
  width: 70px;
  height: 56px;
  flex-shrink: 0;
  padding: 6px;
}
.respawn-list-mode .rsp-card-foot {
  flex-direction: row;
  align-items: center;
  flex: 1;
  gap: 10px;
  padding: 10px 14px 10px 0;
}
.respawn-list-mode .rsp-card-name { min-width: 120px; font-size: 14px; }
.respawn-list-mode .rsp-expanded-panel { display: none !important; }

/* ── View toggle ── */
.rsp-view-toggle {
  display: flex;
  gap: 6px;
  margin-left: auto;
}
.rsp-view-btn {
  width: 32px; height: 32px;
  border-radius: 8px;
  border: 1px solid rgba(255,255,255,0.12);
  background: rgba(255,255,255,0.04);
  color: rgba(255,255,255,0.4);
  cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: all .15s;
}
.rsp-view-btn.active, .rsp-view-btn:hover {
  border-color: rgba(100,180,255,0.4);
  color: #fff;
  background: rgba(100,180,255,0.08);
}
`;
  document.head.appendChild(s);
})();

// ===================== DADOS DE QUESTS =====================
// Estrutura: { name: 'Nome da Quest', icon: '⚔️', description: 'Texto descritivo', img: 'URL ou null' }
// Para adicionar uma quest, adicione um objeto aqui:
// =====================================================================
// QUESTS — estrutura detalhada
// Campos suportados:
//   name        string  — nome da quest
//   icon        string  — emoji do ícone
//   level       number  — nível mínimo requerido
//   reward      string  — HTML/texto da recompensa
//   rewardDesc  string  — descrição extra da recompensa
//   start       string  — HTML/texto de onde e como iniciar
//   drop        string  — HTML/texto do que dropar/coletar
//   puzzle      string  — HTML/texto do puzzle (opcional)
//   puzzleImg   string  — URL da imagem do puzzle (opcional)
//   steps       array   — passos extras [{icon, text}]
//   notes       string  — observações extras
// =====================================================================
var RAW_QUESTS = [
  {
    name: 'Lucky Amulet',
    icon: '🍀',
    level: 250,
    reward: 'Lucky Amulet',
    rewardDesc: 'Amuleto que permite equipar um held <strong>X-Lucky</strong>, com efeito em todos os seus Pokémons. O held terá <strong>50% da efetividade padrão</strong> e não combina com o Lucky do próprio Pokémon — vale apenas o maior bônus.',
    start: 'Vá até as <strong>docas ao sul de Olivine</strong> e fale com o NPC <span class="quest-npc">Captain Willy</span>.',
    drop: 'Willy pedirá para você resgatar o <strong>Valentine Gold Token</strong>.<br><br>Este item é dropado pelo <strong>Tentacruel</strong> apenas em <span class="quest-tag-hunt">hunt normal</span> (não funciona em wildscape).<br><br>Após dropar, entregue o item ao <strong>Captain Willy</strong>.',
    puzzle: 'Após entregar o token, vá até o <strong>DIVE à direita de Vermilion</strong>.<br><br>Lá você encontrará o puzzle. Após completar o puzzle, você receberá o <strong>Lucky Amulet</strong>.<br><br><em>⚠️ Atenção: duas peças da primeira linha do puzzle foram trocadas propositalmente no spoiler abaixo.</em>',
    puzzleImg: 'https://i.imgur.com/biG8VIv.png',
    steps: [
      { icon: '🗺️', text: 'Alcance o <strong>Level 250</strong> antes de iniciar.' },
      { icon: '🚢', text: 'Vá até as <strong>docas ao sul de Olivine</strong> e fale com o NPC <span class="quest-npc">Captain Willy</span>.' },
      { icon: '🎣', text: 'Farme o <strong>Valentine Gold Token</strong> com o <strong>Tentacruel</strong> (hunt normal, não wildscape).' },
      { icon: '📦', text: 'Entregue o <strong>Valentine Gold Token</strong> ao <strong>Captain Willy</strong>.' },
      { icon: '🌊', text: 'Use o <strong>DIVE à direita de Vermilion</strong> e complete o puzzle subaquático.' },
      { icon: '🍀', text: 'Receba o <strong>Lucky Amulet</strong> como recompensa.' },
    ],
    notes: 'O Lucky Amulet funciona para todos os Pokémons, mas tem apenas 50% da eficácia do held X-Lucky equipado. Ele não combina com o Lucky que o Pokémon já tiver — vale apenas o maior bônus.',
  },
  {
    name: 'Vernaccio\'s Paint Cans',
    icon: '🎨',
    level: null,
    reward: '1.000.000 de EXP + 50 Alliance Ball',
    rewardDesc: 'Vernaccio agradecerá pela recuperação dos baldes e como recompensa você receberá <strong>1.000.000 de EXP</strong> e <strong>50 Alliance Balls</strong>.',
    start: 'Vá até <strong>Cianwood</strong> e encontre o NPC <span class="quest-npc">Vernaccio</span>.' +
           '<div class="quest-location-img-wrap"><span class="quest-location-label">📍 Localização do NPC</span>' +
           '<img class="quest-reward-img" src="https://i.imgur.com/MoXRqT0.png" alt="Localização Vernaccio" loading="lazy" /></div>' +
           '<br>Ele irá contar que alguns baldes foram roubados pelos Smeargles e pedirá que você os recupere.',
    parts: [
      {
        title: 'Etapa 1 — Falar com Vernaccio em Cianwood',
        icon: '💬',
        intro: 'Vá até o NPC <span class="quest-npc">Vernaccio</span> na cidade de <strong>Cianwood</strong> e dialogue com ele.<br><br>Ele irá contar que seus preciosos baldes de tinta foram roubados pelos Smeargles e espalhados pelos estúdios de arte abandonados da região. Ele precisa recuperar os baldes <strong>Azul, Vermelho, Verde e Amarelo</strong> para completar sua obra-prima.',
        locationImg: 'https://i.imgur.com/b0Q70hc.png',
        drops: [],
        delivery: null,
      },
      {
        title: 'Etapa 2 — Coletar os Baldes de Tinta',
        icon: '🪣',
        intro: 'Trace uma rota para recolher os 4 baldes. Rota recomendada: <strong>Cianwood → Golden Rod → Ecruteak</strong>, retornando a Cianwood para finalizar.<br><br>⚠️ <strong>Atenção:</strong> Em Golden Rod há <strong>2 baldes</strong> para coletar.<br><br>' +
               '<strong>📍 Localização em Cianwood:</strong><br><br>' +
               '<div style="display:flex;gap:10px;flex-wrap:wrap;">' +
               '<img class="quest-reward-img" src="https://i.imgur.com/HY6qcYI.png" alt="Cianwood mapa 1" loading="lazy" style="flex:1;min-width:140px;max-width:280px;border-radius:10px;" />' +
               '<img class="quest-reward-img" src="https://i.imgur.com/dqoFCmD.png" alt="Cianwood mapa 2" loading="lazy" style="flex:1;min-width:140px;max-width:280px;border-radius:10px;" />' +
               '</div>',
        locationImg: undefined,
        drops: [],
        delivery: null,
      },
      {
        title: 'Etapa 2b — Baldes em Golden Rod',
        icon: '🗺️',
        intro: '⚠️ <strong>ATENÇÃO:</strong> Aqui há <strong>2 baldes</strong> para serem coletados.<br><br>' +
               '<div style="display:flex;gap:10px;flex-wrap:wrap;">' +
               '<img class="quest-reward-img" src="https://i.imgur.com/YsJqsqu.png" alt="Golden Rod mapa 1" loading="lazy" style="flex:1;min-width:140px;max-width:280px;border-radius:10px;" />' +
               '<img class="quest-reward-img" src="https://i.imgur.com/yt1J9Nj.png" alt="Golden Rod mapa 2" loading="lazy" style="flex:1;min-width:140px;max-width:280px;border-radius:10px;" />' +
               '</div>',
        locationImg: undefined,
        drops: [],
        delivery: null,
      },
      {
        title: 'Etapa 2c — Balde em Ecruteak',
        icon: '🗺️',
        intro: 'Localização do balde em <strong>Ecruteak City</strong>:<br><br>' +
               '<div style="display:flex;gap:10px;flex-wrap:wrap;">' +
               '<img class="quest-reward-img" src="https://i.imgur.com/rh6R3G5.png" alt="Ecruteak mapa 1" loading="lazy" style="flex:1;min-width:140px;max-width:280px;border-radius:10px;" />' +
               '<img class="quest-reward-img" src="https://i.imgur.com/qd6QAz7.png" alt="Ecruteak mapa 2" loading="lazy" style="flex:1;min-width:140px;max-width:280px;border-radius:10px;" />' +
               '</div>',
        locationImg: undefined,
        drops: [],
        delivery: null,
      },
      {
        title: 'Etapa 3 — Entregar os Baldes',
        icon: '✅',
        intro: 'Após coletar os <strong>4 baldes</strong>, retorne ao NPC <span class="quest-npc">Vernaccio</span> em <strong>Cianwood</strong>. Ele irá lhe entregar a recompensa final.',
        locationImg: undefined, // sem placeholder aqui
        drops: [],
        delivery: null,
      },
    ],
    steps: [
      { icon: '🗺️', text: 'Vá até <strong>Cianwood</strong> e fale com o NPC <span class="quest-npc">Vernaccio</span>.' },
      { icon: '🪣', text: 'Colete o balde de tinta em <strong>Cianwood</strong>.' },
      { icon: '🪣', text: 'Vá até <strong>Golden Rod</strong> e colete os <strong>2 baldes</strong> de lá.' },
      { icon: '🪣', text: 'Vá até <strong>Ecruteak</strong> e colete o balde restante.' },
      { icon: '🔁', text: 'Retorne a <strong>Cianwood</strong> e entregue todos os baldes ao <span class="quest-npc">Vernaccio</span>.' },
      { icon: '🎁', text: 'Receba a recompensa: <strong>1.000.000 de EXP</strong> e <strong>50 Alliance Balls</strong>.' },
    ],
    info: [
      { label: 'Início da quest',      value: 'Cianwood' },
      { label: 'Localizações extras',  value: 'Cianwood, Ecruteak, Golden Rod' },
      { label: 'Nível de dificuldade', value: '🟢 Baixa' },
      { label: 'Requisitos',           value: 'Um Pokémon com <strong>Fly</strong> e um Pokémon para matar os Smeargles espalhados pelas hunts.' },
    ],
    notes: 'Leve um Pokémon com <strong>Fly</strong> para agilizar o trajeto entre as cidades. Os Smeargles ficam dentro das hunts — tenha um Pokémon de batalha preparado para eliminá-los.',
  },
  {
    name: 'Flint Quest',
    icon: '🏚️',
    items: ['Onix Tail', 'Stone Rocks', 'Horn Drill', 'Rock Plate', 'Crystal Stones', 'Metal Stones'],
    reward: '3 Ancient Stones + 500K EXP + Estante à escolha',
    rewardDesc: 'Flint agradecerá por toda a ajuda e como recompensa você receberá <strong>3 Ancient Stones</strong>, <strong>500K de EXP</strong> e poderá escolher uma das <strong>estantes da casa de Flint</strong> como presente.',
    rewardImg: null, // coloque a URL da imagem da recompensa aqui
    start: 'Encontre o NPC <span class="quest-npc">Flint</span> ao <strong>sul de Pewter</strong>, na floresta de Viridian.' +
           '<div class="quest-location-img-wrap"><span class="quest-location-label">📍 Localização</span>' +
           '<div class="quest-img-placeholder" data-slot="flint-location">📷 Imagem — adicione a URL em <code>rewardImg</code></div></div>' +
           '<br>Fale com ele usando o comando <span class="quest-cmd">hi</span>, depois digite <span class="quest-cmd">help</span> para iniciar a quest.',
    parts: [
      {
        title: 'Parte 1 — Coleta de Materiais',
        icon: '🧱',
        intro: 'Flint pedirá que você colete os seguintes materiais para iniciar a reconstrução da casa:',
        locationImg: null, // imagem desta etapa (opcional)
        drops: [
          { qty: 150, item: 'Onix Tail',   source: 'Onix',   locationImg: null },
          { qty: 200, item: 'Stone Rocks',  source: 'Golem',  locationImg: null },
          { qty: 200, item: 'Horn Drill',   source: 'Rhydon', locationImg: null },
          { qty:  50, item: 'Rock Plate',   source: 'Pupitar',locationImg: null },
        ],
        delivery: 'Com todos os itens em mãos, retorne até o <span class="quest-npc">Flint</span> e fale com ele para entregar os materiais. Ele agradecerá e irá até sua casa para iniciar a reconstrução.',
      },
      {
        title: 'Parte 2 — Reconstrução da Casa',
        icon: '🏡',
        intro: 'Vá até a <strong>casa de Flint</strong>, ainda em Viridian.',
        locationImg: null, // imagem da casa (adicione a URL aqui)
        drops: [
          { qty: 10, item: 'Crystal Stones', source: null, locationImg: null },
          { qty: 10, item: 'Metal Stones',   source: null, locationImg: null },
        ],
        delivery: 'Fale com o <span class="quest-npc">Flint</span> usando <span class="quest-cmd">hi</span>. Quando ele perguntar se você está pronto, responda com <span class="quest-cmd">yes</span> e entregue os materiais.',
      },
    ],
    steps: [
      { icon: '🗺️', text: 'Vá ao <strong>sul de Pewter</strong>, na floresta de Viridian, e encontre o NPC <span class="quest-npc">Flint</span>.' },
      { icon: '💬', text: 'Fale com ele usando <span class="quest-cmd">hi</span> e em seguida <span class="quest-cmd">help</span> para iniciar.' },
      { icon: '🧱', text: 'Colete <strong>150 Onix Tail</strong> (Onix), <strong>200 Stone Rocks</strong> (Golem), <strong>200 Horn Drill</strong> (Rhydon) e <strong>50 Rock Plate</strong> (Pupitar).' },
      { icon: '📦', text: 'Retorne ao <span class="quest-npc">Flint</span> e entregue todos os materiais da Parte 1.' },
      { icon: '🏡', text: 'Vá até a <strong>casa de Flint</strong> em Viridian e fale com ele novamente usando <span class="quest-cmd">hi</span>.' },
      { icon: '🔨', text: 'Responda <span class="quest-cmd">yes</span> e entregue <strong>10 Crystal Stones</strong> e <strong>10 Metal Stones</strong>.' },
      { icon: '🎁', text: 'Receba as recompensas: <strong>3 Ancient Stones</strong>, <strong>500K EXP</strong> e uma estante à escolha.' },
    ],
    notes: 'Para agilizar a coleta da Parte 1, foque nas melhores localizações para cada Pokémon. Certifique-se de estar preparado antes de iniciar, pois Flint poderá solicitar itens e tarefas adicionais.',
  },
];

// ── CSS injetado para quests rich ─────────────────────────────────────
(function () {
  if (document.getElementById('quest-rich-css')) return;
  var s = document.createElement('style');
  s.id = 'quest-rich-css';
  s.textContent = `
/* ── Quest card ── */
.quest-row {
  background: linear-gradient(160deg, rgba(18,26,50,0.97) 0%, rgba(8,13,28,0.99) 100%);
  border: 1px solid rgba(255,210,80,0.12);
  border-radius: 18px;
  overflow: hidden;
  margin-bottom: 14px;
  transition: border-color 0.25s, box-shadow 0.25s;
  position: relative;
}
.quest-row::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2px;
  background: linear-gradient(90deg, transparent, rgba(255,210,80,0.5), transparent);
  border-radius: 18px 18px 0 0;
  opacity: 0;
  transition: opacity 0.25s;
}
.quest-row:hover, .quest-row.open {
  border-color: rgba(255,210,80,0.30);
  box-shadow: 0 0 32px rgba(255,210,80,0.07), 0 8px 32px rgba(0,0,0,0.5);
}
.quest-row:hover::before, .quest-row.open::before { opacity: 1; }

/* ── Header ── */
.quest-row-header {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 18px 22px;
  cursor: pointer;
  user-select: none;
  position: relative;
}
.quest-row-num {
  font-family: var(--font-mono, monospace);
  font-size: 11px;
  font-weight: 700;
  color: rgba(255,210,80,0.35);
  letter-spacing: 1px;
  min-width: 20px;
}
.quest-row-icon {
  font-size: 22px;
  flex-shrink: 0;
  filter: drop-shadow(0 0 8px rgba(255,210,80,0.4));
}
.quest-row-name {
  font-family: var(--font-title, 'Cinzel', serif);
  font-size: 16px;
  font-weight: 700;
  color: #f0d060;
  letter-spacing: 0.6px;
  flex: 1;
  text-shadow: 0 0 20px rgba(255,210,80,0.2);
}
.quest-row-meta {
  display: flex;
  align-items: center;
  gap: 8px;
}
.quest-level-badge {
  font-family: var(--font-mono, monospace);
  font-size: 10px;
  font-weight: 700;
  color: #60aaff;
  background: rgba(96,170,255,0.1);
  border: 1px solid rgba(96,170,255,0.25);
  border-radius: 20px;
  padding: 3px 10px;
  letter-spacing: 0.8px;
  white-space: nowrap;
}
.quest-row-chevron {
  width: 18px; height: 18px;
  color: rgba(255,210,80,0.4);
  flex-shrink: 0;
  transition: transform 0.3s cubic-bezier(0.16,1,0.3,1), color 0.2s;
}
.quest-row.open .quest-row-chevron {
  transform: rotate(180deg);
  color: #f0d060;
}

/* ── Panel (expandido) ── */
.quest-row-panel {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.5s cubic-bezier(0.4,0,0.2,1);
}
.quest-row.open .quest-row-panel {
  max-height: 2400px;
}
.quest-panel-inner {
  padding: 0 24px 28px;
  display: flex;
  flex-direction: column;
  gap: 22px;
  border-top: 1px solid rgba(255,210,80,0.08);
  margin-top: 0;
  padding-top: 22px;
}

/* ── Seção ── */
.quest-section {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.quest-section-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-family: var(--font-title, 'Cinzel', serif);
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: rgba(255,210,80,0.6);
}
.quest-section-title::after {
  content: '';
  flex: 1;
  height: 1px;
  background: rgba(255,210,80,0.12);
}
.quest-section-icon { font-size: 13px; }

/* ── Reward box ── */
.quest-reward-box {
  background: rgba(255,210,80,0.05);
  border: 1px solid rgba(255,210,80,0.18);
  border-left: 3px solid #f0d060;
  border-radius: 12px;
  padding: 14px 18px;
}
.quest-reward-name {
  font-family: var(--font-title, 'Cinzel', serif);
  font-size: 15px;
  font-weight: 700;
  color: #f0d060;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.quest-reward-desc {
  font-family: var(--font-body, 'Rajdhani', sans-serif);
  font-size: 13px;
  color: rgba(255,255,255,0.65);
  line-height: 1.6;
}
.quest-reward-desc strong { color: rgba(255,255,255,0.9); }

/* ── Info box genérico ── */
.quest-info-box {
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.07);
  border-radius: 12px;
  padding: 14px 18px;
  font-family: var(--font-body, 'Rajdhani', sans-serif);
  font-size: 13px;
  color: rgba(255,255,255,0.65);
  line-height: 1.7;
}
.quest-info-box strong { color: rgba(255,255,255,0.9); }
.quest-info-box em { color: rgba(255,180,50,0.8); font-style: normal; }

/* ── Steps ── */
.quest-steps {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.quest-step {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  background: rgba(255,255,255,0.025);
  border: 1px solid rgba(255,255,255,0.06);
  border-radius: 10px;
  padding: 11px 15px;
  transition: background 0.2s, border-color 0.2s;
}
.quest-step:hover {
  background: rgba(255,210,80,0.04);
  border-color: rgba(255,210,80,0.12);
}
.quest-step-num {
  font-family: var(--font-mono, monospace);
  font-size: 10px;
  font-weight: 700;
  color: rgba(255,210,80,0.4);
  min-width: 18px;
  padding-top: 1px;
}
.quest-step-icon {
  font-size: 15px;
  flex-shrink: 0;
  padding-top: 0px;
  line-height: 1.4;
}
.quest-step-text {
  font-family: var(--font-body, 'Rajdhani', sans-serif);
  font-size: 13px;
  color: rgba(255,255,255,0.7);
  line-height: 1.55;
  flex: 1;
}
.quest-step-text strong { color: rgba(255,255,255,0.92); }

/* ── Puzzle image ── */
.quest-puzzle-img-wrap {
  border-radius: 14px;
  overflow: hidden;
  border: 1px solid rgba(255,255,255,0.08);
  position: relative;
}
.quest-puzzle-img-wrap img {
  width: 100%;
  display: block;
  border-radius: 14px;
}
.quest-puzzle-spoiler-label {
  position: absolute;
  top: 10px; left: 10px;
  background: rgba(0,0,0,0.75);
  border: 1px solid rgba(255,210,80,0.3);
  color: rgba(255,210,80,0.85);
  font-family: var(--font-mono, monospace);
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 1px;
  padding: 3px 10px;
  border-radius: 20px;
  backdrop-filter: blur(4px);
}

/* ── Notes box ── */
.quest-notes-box {
  background: rgba(96,170,255,0.04);
  border: 1px solid rgba(96,170,255,0.15);
  border-left: 3px solid rgba(96,170,255,0.5);
  border-radius: 12px;
  padding: 12px 18px;
  font-family: var(--font-body, 'Rajdhani', sans-serif);
  font-size: 12.5px;
  color: rgba(255,255,255,0.55);
  line-height: 1.6;
}
.quest-notes-box strong { color: rgba(255,255,255,0.8); }

/* ── Info grid (ficha resumida) ── */
.quest-info-grid {
  display: flex;
  flex-direction: column;
  gap: 0;
  border: 1px solid rgba(255,210,80,0.1);
  border-radius: 12px;
  overflow: hidden;
}
.quest-info-row {
  display: flex;
  align-items: baseline;
  gap: 12px;
  padding: 10px 16px;
  border-bottom: 1px solid rgba(255,255,255,0.04);
  transition: background 0.15s;
}
.quest-info-row:last-child { border-bottom: none; }
.quest-info-row:hover { background: rgba(255,210,80,0.03); }
.quest-info-row-label {
  font-family: var(--font-title, 'Cinzel', serif);
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.8px;
  text-transform: uppercase;
  color: rgba(255,210,80,0.55);
  min-width: 140px;
  flex-shrink: 0;
}
.quest-info-row-value {
  font-family: var(--font-body, 'Rajdhani', sans-serif);
  font-size: 13px;
  color: rgba(255,255,255,0.7);
  line-height: 1.5;
}
.quest-info-row-value strong { color: rgba(255,255,255,0.9); }

/* ── Inline tags ── */
.quest-npc {
  color: #60d0ff;
  font-weight: 700;
}
.quest-tag-hunt {
  display: inline-block;
  background: rgba(100,229,160,0.1);
  border: 1px solid rgba(100,229,160,0.3);
  color: #66e5a0;
  font-size: 11px;
  font-weight: 700;
  padding: 1px 8px;
  border-radius: 20px;
  letter-spacing: 0.5px;
  font-family: var(--font-mono, monospace);
}

@media (max-width: 600px) {
  .quest-row-name { font-size: 13px; }
  .quest-panel-inner { padding: 0 14px 20px; padding-top: 16px; gap: 16px; }
  .quest-reward-box, .quest-info-box, .quest-notes-box { padding: 11px 14px; }
}

/* ── Parte header ── */
.quest-part-header {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 10px 16px;
  background: rgba(255,210,80,0.05);
  border: 1px solid rgba(255,210,80,0.14);
  border-radius: 10px;
  margin-bottom: 10px;
}
.quest-part-icon { font-size: 16px; }
.quest-part-title {
  font-family: var(--font-title, 'Cinzel', serif);
  font-size: 12px;
  font-weight: 700;
  color: rgba(255,210,80,0.75);
  letter-spacing: 0.8px;
}

/* ── Drop table ── */
.quest-drop-table {
  width: 100%;
  border-collapse: collapse;
  border-radius: 10px;
  overflow: hidden;
  font-family: var(--font-body, 'Rajdhani', sans-serif);
  font-size: 13px;
}
.quest-drop-table thead tr {
  background: rgba(255,255,255,0.04);
}
.quest-drop-table thead th {
  padding: 8px 12px;
  text-align: left;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 1.2px;
  text-transform: uppercase;
  color: rgba(255,255,255,0.3);
  border-bottom: 1px solid rgba(255,255,255,0.06);
}
.quest-drop-table tbody tr {
  border-bottom: 1px solid rgba(255,255,255,0.04);
  transition: background 0.15s;
}
.quest-drop-table tbody tr:last-child { border-bottom: none; }
.quest-drop-table tbody tr:hover { background: rgba(255,210,80,0.03); }
.quest-drop-table td { padding: 9px 12px; vertical-align: middle; }
.quest-drop-qty {
  font-family: var(--font-mono, monospace);
  font-size: 12px;
  font-weight: 700;
  color: #f0d060;
  white-space: nowrap;
  width: 60px;
}
.quest-drop-item {
  color: rgba(255,255,255,0.85);
  font-weight: 600;
}
.quest-drop-source {
  color: rgba(255,255,255,0.38);
  font-size: 11.5px;
}
.quest-drop-source strong { color: rgba(255,255,255,0.55); }
.quest-drop-loc {
  text-align: right;
  width: 80px;
}
.quest-loc-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-family: var(--font-mono, monospace);
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.5px;
  color: #60aaff;
  background: rgba(96,170,255,0.08);
  border: 1px solid rgba(96,170,255,0.2);
  border-radius: 20px;
  padding: 3px 9px;
  cursor: pointer;
  transition: background 0.15s, border-color 0.15s;
  text-decoration: none;
}
.quest-loc-btn:hover {
  background: rgba(96,170,255,0.16);
  border-color: rgba(96,170,255,0.4);
}
.quest-loc-placeholder {
  font-family: var(--font-mono, monospace);
  font-size: 10px;
  color: rgba(255,255,255,0.15);
  font-style: italic;
}

/* ── Image placeholder ── */
.quest-img-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: rgba(255,255,255,0.025);
  border: 1.5px dashed rgba(255,255,255,0.1);
  border-radius: 12px;
  padding: 28px 20px;
  margin-top: 10px;
  font-family: var(--font-mono, monospace);
  font-size: 11px;
  color: rgba(255,255,255,0.2);
  text-align: center;
}
.quest-img-placeholder code {
  color: rgba(255,210,80,0.4);
  font-size: 10px;
}

/* ── Reward image ── */
.quest-reward-img {
  width: 100%;
  border-radius: 12px;
  border: 1px solid rgba(255,255,255,0.08);
  margin-top: 10px;
  display: block;
}

/* ── Cmd tag ── */
.quest-cmd {
  display: inline-block;
  background: rgba(160,212,255,0.08);
  border: 1px solid rgba(160,212,255,0.22);
  color: #a0d4ff;
  font-family: var(--font-mono, monospace);
  font-size: 11px;
  font-weight: 700;
  padding: 1px 8px;
  border-radius: 6px;
  letter-spacing: 0.3px;
}

/* ── Delivery note ── */
.quest-delivery-note {
  background: rgba(102,229,160,0.04);
  border: 1px solid rgba(102,229,160,0.12);
  border-left: 3px solid rgba(102,229,160,0.4);
  border-radius: 10px;
  padding: 11px 15px;
  font-family: var(--font-body, 'Rajdhani', sans-serif);
  font-size: 13px;
  color: rgba(255,255,255,0.6);
  line-height: 1.6;
  margin-top: 8px;
}
.quest-delivery-note strong { color: rgba(255,255,255,0.85); }
  `;
  document.head.appendChild(s);
})();

function renderQuests() {
  var grid = document.getElementById('quests-grid');
  if (!grid) return;
  var q = (document.getElementById('quests-search') ? document.getElementById('quests-search').value : '').toLowerCase().trim();

  var filtered = RAW_QUESTS.filter(function(quest) {
    if (!q) return true;
    return quest.name.toLowerCase().includes(q) || (quest.description && quest.description.toLowerCase().includes(q));
  });

  document.getElementById('quests-count-label').textContent = filtered.length + ' quests';

  if (!filtered.length) {
    grid.innerHTML = '<div class="wiki-empty-state"><span class="empty-icon">📜</span><span class="empty-label">Nenhuma quest cadastrada ainda.</span></div>';
    return;
  }

  grid.innerHTML = filtered.map(function(quest, idx) {
    // ── Header
    var levelBadge = quest.level
      ? '<span class="quest-level-badge">LVL ' + quest.level + '+</span>'
      : '';

    // ── Recompensa
    var rewardSection = '';
    if (quest.reward) {
      rewardSection =
        '<div class="quest-section">' +
          '<div class="quest-section-title"><span class="quest-section-icon">🎁</span> Recompensa</div>' +
          '<div class="quest-reward-box">' +
            '<div class="quest-reward-name">🍀 ' + quest.reward + '</div>' +
            (quest.rewardDesc ? '<div class="quest-reward-desc">' + quest.rewardDesc + '</div>' : '') +
          '</div>' +
        '</div>';
    }

    // ── Pré-requisito
    var prereqSection = '';
    if (quest.level) {
      prereqSection =
        '<div class="quest-section">' +
          '<div class="quest-section-title"><span class="quest-section-icon">📋</span> Pré-requisito</div>' +
          '<div class="quest-info-box">Level mínimo: <strong>' + quest.level + '</strong></div>' +
        '</div>';
    }

    // ── Info (ficha resumida — início, locais, dificuldade, requisitos)
    var infoSection = '';
    if (quest.info && quest.info.length) {
      var infoRows = quest.info.map(function(row) {
        return '<div class="quest-info-row">' +
          '<span class="quest-info-row-label">' + row.label + '</span>' +
          '<span class="quest-info-row-value">' + row.value + '</span>' +
        '</div>';
      }).join('');
      infoSection =
        '<div class="quest-section">' +
          '<div class="quest-section-title"><span class="quest-section-icon">📋</span> Informações</div>' +
          '<div class="quest-info-grid">' + infoRows + '</div>' +
        '</div>';
    }

    // ── Início
    var startSection = '';
    if (quest.start) {
      startSection =
        '<div class="quest-section">' +
          '<div class="quest-section-title"><span class="quest-section-icon">📍</span> Início</div>' +
          '<div class="quest-info-box">' + quest.start + '</div>' +
        '</div>';
    }

    // ── Drop
    var dropSection = '';
    if (quest.drop) {
      dropSection =
        '<div class="quest-section">' +
          '<div class="quest-section-title"><span class="quest-section-icon">⚔️</span> Drop</div>' +
          '<div class="quest-info-box">' + quest.drop + '</div>' +
        '</div>';
    }

    // ── Puzzle
    var puzzleSection = '';
    if (quest.puzzle || quest.puzzleImg) {
      var puzzleImgHtml = '';
      if (quest.puzzleImg) {
        puzzleImgHtml =
          '<div class="quest-puzzle-img-wrap">' +
            '<span class="quest-puzzle-spoiler-label">⚠ SPOILER</span>' +
            '<img src="' + quest.puzzleImg + '" alt="Spoiler do Puzzle" loading="lazy" />' +
          '</div>';
      }
      puzzleSection =
        '<div class="quest-section">' +
          '<div class="quest-section-title"><span class="quest-section-icon">🧩</span> Puzzle</div>' +
          (quest.puzzle ? '<div class="quest-info-box">' + quest.puzzle + '</div>' : '') +
          puzzleImgHtml +
        '</div>';
    }

    // ── Passo a passo
    var stepsSection = '';
    if (quest.steps && quest.steps.length) {
      var stepsHtml = quest.steps.map(function(step, si) {
        return '<div class="quest-step">' +
          '<span class="quest-step-num">0' + (si + 1) + '</span>' +
          '<span class="quest-step-icon">' + step.icon + '</span>' +
          '<span class="quest-step-text">' + step.text + '</span>' +
        '</div>';
      }).join('');
      stepsSection =
        '<div class="quest-section">' +
          '<div class="quest-section-title"><span class="quest-section-icon">📌</span> Passo a Passo</div>' +
          '<div class="quest-steps">' + stepsHtml + '</div>' +
        '</div>';
    }

    // ── Observações
    var notesSection = '';
    if (quest.notes) {
      notesSection =
        '<div class="quest-section">' +
          '<div class="quest-section-title"><span class="quest-section-icon">💡</span> Observações</div>' +
          '<div class="quest-notes-box">' + quest.notes + '</div>' +
        '</div>';
    }

    // ── Recompensa com imagem (override para quests com rewardImg)
    if (quest.reward && quest.rewardImg !== undefined) {
      var rewardImgHtml = quest.rewardImg
        ? '<img class="quest-reward-img" src="' + quest.rewardImg + '" alt="Recompensa" loading="lazy" />'
        : '<div class="quest-img-placeholder">📷 Imagem da recompensa — substitua <code>rewardImg: null</code> pela URL</div>';
      rewardSection =
        '<div class="quest-section">' +
          '<div class="quest-section-title"><span class="quest-section-icon">🎁</span> Recompensa</div>' +
          '<div class="quest-reward-box">' +
            '<div class="quest-reward-name">🏆 ' + quest.reward + '</div>' +
            (quest.rewardDesc ? '<div class="quest-reward-desc">' + quest.rewardDesc + '</div>' : '') +
            rewardImgHtml +
          '</div>' +
        '</div>';
    }

    // ── Partes (parts)
    var partsSection = '';
    if (quest.parts && quest.parts.length) {
      partsSection = quest.parts.map(function(part, pi) {
        // Drop table
        var tableHtml = '';
        if (part.drops && part.drops.length) {
          var rows = part.drops.map(function(d) {
            var locHtml = d.locationImg
              ? '<a class="quest-loc-btn" href="' + d.locationImg + '" target="_blank">📍 VER</a>'
              : '<span class="quest-loc-placeholder">a definir</span>';
            var sourceHtml = d.source
              ? 'Drop de <strong>' + d.source + '</strong>'
              : '<span style="color:rgba(255,255,255,0.25)">—</span>';
            return '<tr>' +
              '<td class="quest-drop-qty">×' + d.qty + '</td>' +
              '<td class="quest-drop-item">' + d.item + '</td>' +
              '<td class="quest-drop-source">' + sourceHtml + '</td>' +
              '<td class="quest-drop-loc">' + locHtml + '</td>' +
            '</tr>';
          }).join('');
          tableHtml =
            '<table class="quest-drop-table">' +
              '<thead><tr>' +
                '<th>QTD</th><th>ITEM</th><th>FONTE</th><th style="text-align:right">LOCAL</th>' +
              '</tr></thead>' +
              '<tbody>' + rows + '</tbody>' +
            '</table>';
        }

        // Location image placeholder
        var locImgHtml = '';
        if (part.locationImg !== undefined) {
          locImgHtml = part.locationImg
            ? '<img class="quest-reward-img" src="' + part.locationImg + '" alt="Localização" loading="lazy" />'
            : '<div class="quest-img-placeholder">📷 Imagem desta etapa — substitua <code>locationImg: null</code> pela URL</div>';
        }

        return '<div class="quest-section">' +
          '<div class="quest-section-title">' +
            '<span class="quest-section-icon">' + (part.icon || '📦') + '</span> ' + part.title +
          '</div>' +
          (part.intro ? '<div class="quest-info-box" style="margin-bottom:0">' + part.intro + '</div>' : '') +
          locImgHtml +
          tableHtml +
          (part.delivery ? '<div class="quest-delivery-note">✅ ' + part.delivery + '</div>' : '') +
        '</div>';
      }).join('');
    }

    return (
      '<div class="quest-row" id="quest-row-' + idx + '">' +
        '<div class="quest-row-header" onclick="toggleQuestRow(' + idx + ')">' +
          '<span class="quest-row-num">' + String(idx + 1).padStart(2, '0') + '</span>' +
          '<span class="quest-row-icon">' + (quest.icon || '📜') + '</span>' +
          '<span class="quest-row-name">' + quest.name + '</span>' +
          '<div class="quest-row-meta">' +
            levelBadge +
            '<svg class="quest-row-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>' +
          '</div>' +
        '</div>' +
        '<div class="quest-row-panel">' +
          '<div class="quest-panel-inner">' +
            rewardSection +
            prereqSection +
            infoSection +
            startSection +
            dropSection +
            partsSection +
            puzzleSection +
            stepsSection +
            notesSection +
          '</div>' +
        '</div>' +
      '</div>'
    );
  }).join('');
}

function toggleQuestRow(idx) {
  var row = document.getElementById('quest-row-' + idx);
  if (!row) return;
  var isOpen = row.classList.contains('open');
  document.querySelectorAll('.quest-row.open').forEach(function(r) { r.classList.remove('open'); });
  if (!isOpen) row.classList.add('open');
}

// Correções de nome: chave = como está no dado, valor = nome correto do Showdown
var SHOWDOWN_NAME_FIXES = {
  'charmelion': 'charmeleon',
  'nidoran-f':  'nidoranf',
  'nidoran-m':  'nidoranm',
  'ho-oh':      'hooh',
  'porygon-z':  'porygonz',
  'mime jr.':   'mimejr',
  'grambull': 'granbull',
  'politoad': 'politoed',
  'mr. mime': 'mrmime',
  'mr.mime':  'mrmime',
};

function toShowdownName(name) {
  var n = name
    .replace(/^shiny\s+/i, '')
    .replace(/['']/g, '')
    .replace(/[éèê]/g, 'e')
    .toLowerCase()
    .trim();

  // Aplica correções manuais de nome
  if (SHOWDOWN_NAME_FIXES[n]) n = SHOWDOWN_NAME_FIXES[n];

  // Mega Charizard X → charizard-mega-x
  // Mega Charizard Y → charizard-mega-y
  // Mega Heracross   → heracross-mega
  var megaXY = n.match(/^mega\s+(.+?)\s+(x|y)$/);
  if (megaXY) return megaXY[1].replace(/\s+/g, '') + '-mega-' + megaXY[2];

  var megaBase = n.match(/^mega\s+(.+)$/);
  if (megaBase) return megaBase[1].replace(/\s+/g, '') + '-mega';

  return n.replace(/\s+/g, '');
}

function getShowdownSprite(pokeName) {
  var isShiny = /^shiny\s+/i.test(pokeName);
  var n = toShowdownName(pokeName);
  return isShiny
    ? 'https://play.pokemonshowdown.com/sprites/ani-shiny/' + n + '.gif'
    : 'https://play.pokemonshowdown.com/sprites/ani/' + n + '.gif';
}

function getShowdownStaticSprite(pokeName) {
  var isShiny = /^shiny\s+/i.test(pokeName);
  var n = toShowdownName(pokeName);
  return isShiny
    ? 'https://play.pokemonshowdown.com/sprites/dex-shiny/' + n + '.png'
    : 'https://play.pokemonshowdown.com/sprites/dex/' + n + '.png';
}


// ===================== PACOTES — LAYOUT RPG =====================
let currentPkg = null;
let currentPkgState = [];
let activePkgIdx = null;
// pkgCartCount já declarado globalmente acima

// Ícones por tipo de pacote (heurística pelo nome)
/* ── Cor do tipo pelo nome do pacote ────────────────────────────── */
function getPkgTypeColor(name) {
  const n = name.toLowerCase();
  if (n.includes('water'))                         return '#00aaff';
  if (n.includes('steel') || n.includes('metal'))  return '#ccddee';
  if (n.includes('rock'))                          return '#aa8855';
  if (n.includes('psychic'))                       return '#ff44bb';
  if (n.includes('poison'))                        return '#aa00cc';
  if (n.includes('normal'))                        return '#bbbbbb';
  if (n.includes('ice'))                           return '#80e8ff';
  if (n.includes('ground') || n.includes('sand'))  return '#cc8800';
  if (n.includes('fire'))                          return '#ff6a00';
  if (n.includes('grass'))                         return '#44cc00';
  if (n.includes('electric'))                      return '#ffe600';
  if (n.includes('dark'))                          return '#6666cc';
  if (n.includes('dragon'))                        return '#ffaa00';
  if (n.includes('ghost'))                         return '#9900ff';
  if (n.includes('fairy'))                         return '#ff66bb';
  if (n.includes('flying'))                        return '#aabbff';
  if (n.includes('bug'))                           return '#99cc00';
  if (n.includes('fighting') || n.includes('figthing')) return '#ff4400';
  if (n.includes('speed'))                         return '#00ffcc';
  if (n.includes('hp'))                            return '#ff4466';
  if (n.startsWith('gym') || n.includes('gym'))    return '#ffd166';
  if (n.startsWith('full'))                        return '#60aaff';
  return '#60aaff';
}

/* ── CSS Talent-style para os cards do sidebar ──────────────────── */
(function injectPkgTalentStyle() {
  if (document.getElementById('pkg-talent-style')) return;
  const s = document.createElement('style');
  s.id = 'pkg-talent-style';
  s.textContent = `
    .pkg-sidebar-list {
      display: grid !important;
      grid-template-columns: repeat(2, 1fr) !important;
      gap: 10px !important;
      padding: 10px !important;
    }
    .pkg-sidebar-item {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      gap: 8px !important;
      padding: 14px 8px 12px !important;
      border-radius: 14px !important;
      background: rgba(255,255,255,0.03) !important;
      border: 1.5px solid var(--pkg-color, rgba(255,255,255,0.1)) !important;
      cursor: pointer !important;
      transition: background .18s, border-color .18s, box-shadow .18s, transform .15s !important;
      position: relative !important;
      text-align: center !important;
    }
    .pkg-sidebar-item:hover {
      background: rgba(255,255,255,0.06) !important;
      border-color: var(--pkg-color, rgba(255,255,255,0.25)) !important;
      box-shadow: 0 4px 20px rgba(0,0,0,0.4), 0 0 0 1px var(--pkg-color, rgba(255,255,255,0.1)) !important;
      transform: translateY(-2px) !important;
    }
    .pkg-sidebar-item.active {
      background: color-mix(in srgb, var(--pkg-color, #60aaff) 12%, transparent) !important;
      border-color: var(--pkg-color, #60aaff) !important;
      box-shadow: 0 0 18px color-mix(in srgb, var(--pkg-color, #60aaff) 30%, transparent) !important;
    }
    .pkg-sidebar-item-icon {
      width: 60px !important;
      height: 60px !important;
      border-radius: 50% !important;
      background: color-mix(in srgb, var(--pkg-color, #60aaff) 14%, #0a0f1a) !important;
      border: 2px solid color-mix(in srgb, var(--pkg-color, #60aaff) 45%, transparent) !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      box-shadow: 0 0 14px color-mix(in srgb, var(--pkg-color, #60aaff) 20%, transparent) !important;
      flex-shrink: 0 !important;
      overflow: hidden !important;
    }
    .pkg-sidebar-item-icon img {
      width: 38px !important;
      height: 38px !important;
      object-fit: contain !important;
    }
    .pkg-sidebar-item-info {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      gap: 3px !important;
    }
    .pkg-sidebar-item-name {
      font-family: var(--font-title, 'Cinzel', serif) !important;
      font-size: 10px !important;
      font-weight: 700 !important;
      letter-spacing: .5px !important;
      color: #fff !important;
      text-align: center !important;
      line-height: 1.3 !important;
      white-space: normal !important;
      overflow: visible !important;
      text-overflow: unset !important;
    }
    .pkg-sidebar-item-sub {
      font-family: var(--font-mono, monospace) !important;
      font-size: 10px !important;
      color: rgba(255,255,255,0.38) !important;
      letter-spacing: .3px !important;
    }
    .pkg-card-cart-badge {
      position: absolute !important;
      top: 6px !important;
      right: 6px !important;
      font-family: var(--font-mono, monospace) !important;
      font-size: 9px !important;
      font-weight: 700 !important;
      padding: 2px 6px !important;
      border-radius: 10px !important;
      background: #22c55e !important;
      color: #fff !important;
      letter-spacing: .3px !important;
    }
  `;
  document.head.appendChild(s);
})();

function getPkgIcon(name) {
  const img = (url) => `<img src="${url}" style="width:38px;height:38px;object-fit:contain" />`;
  const n = name.toLowerCase();
  // Gym e Reduces primeiro (mais específicos, evita conflito com water/speed)
  // Para "Reduces Speed <Tipo>", detecta o tipo pelo nome
  if (n.startsWith('reduces') || n.startsWith('reduce')) {
    if (n.includes('ice'))                          return img('https://i.imgur.com/ssFz0sA.png');
    if (n.includes('sand') || n.includes('ground')) return img('https://i.imgur.com/JPcD2l3.png');
    if (n.includes('fire'))                         return img('https://i.imgur.com/O8TONGE.png');
    if (n.includes('grass'))                        return img('https://i.imgur.com/YjKxtoE.png');
    if (n.includes('electric'))                     return img('https://i.imgur.com/Yv2WEYc.png');
    if (n.includes('psychic'))                      return img('https://i.imgur.com/ASiZi1K.png');
    if (n.includes('poison'))                       return img('https://i.imgur.com/xfX0ReE.png');
    if (n.includes('normal'))                       return img('https://i.imgur.com/w2ChsIe.png');
    if (n.includes('steel') || n.includes('metal')) return img('https://i.imgur.com/GleRjiM.png');
    if (n.includes('rock'))                         return img('https://i.imgur.com/GvD1Mtq.png');
    if (n.includes('dark'))                         return img('https://i.imgur.com/7Luj4az.png');
    if (n.includes('dragon'))                       return img('https://i.imgur.com/o7JWbaN.png');
    if (n.includes('ghost'))                        return img('https://i.imgur.com/HuybbPn.png');
    if (n.includes('fairy'))                        return img('https://i.imgur.com/j3HaXTh.png');
    if (n.includes('flying'))                       return img('https://i.imgur.com/npGjQae.png');
    if (n.includes('bug'))                          return img('https://i.imgur.com/V4IXR51.png');
    if (n.includes('fighting') || n.includes('figthing')) return img('https://i.imgur.com/OKsJXh7.png');
    if (n.includes('water'))                        return img('https://i.imgur.com/zpRe43i.png');
    return img('https://i.imgur.com/zpRe43i.png'); // fallback water
  }
  if (n.includes('viridian'))  return img('https://i.imgur.com/AvX9Hbj.png');
  if (n.includes('cinnabar'))  return img('https://i.imgur.com/RsJe7OO.png');
  if (n.includes('pewter'))    return img('https://i.imgur.com/ViA3uQO.png');
  if (n.includes('cerulean'))  return img('https://i.imgur.com/uCRmZvq.png');
  if (n.includes('vermilion')) return img('https://i.imgur.com/GEfwZ4B.png');
  if (n.includes('celadon'))   return img('https://i.imgur.com/ocPJIHg.png');
  if (n.includes('fuchsia'))   return img('https://i.imgur.com/i8U2tWd.png');
  if (n.includes('saffron'))   return img('https://i.imgur.com/dzVfRLq.png');
  if (n.startsWith('gym'))     return img('https://i.imgur.com/XyBY6d2.png');
  if (n.includes('speed'))                        return img('https://i.imgur.com/ODTCGEc.gif');
  if (n.includes('hp'))                           return img('https://i.imgur.com/QhZ8LL5.gif');
  if (n.includes('water'))                        return img('https://i.imgur.com/zpRe43i.png');
  if (n.includes('steel') || n.includes('metal')) return img('https://i.imgur.com/GleRjiM.png');
  if (n.includes('rock'))                         return img('https://i.imgur.com/GvD1Mtq.png');
  if (n.includes('psychic'))                      return img('https://i.imgur.com/ASiZi1K.png');
  if (n.includes('poison'))                       return img('https://i.imgur.com/xfX0ReE.png');
  if (n.includes('normal'))                       return img('https://i.imgur.com/w2ChsIe.png');
  if (n.includes('ice'))                          return img('https://i.imgur.com/ssFz0sA.png');
  if (n.includes('ground'))                       return img('https://i.imgur.com/JPcD2l3.png');
  if (n.includes('fire'))                         return img('https://i.imgur.com/O8TONGE.png');
  if (n.includes('grass'))                        return img('https://i.imgur.com/YjKxtoE.png');
  if (n.includes('electric'))                     return img('https://i.imgur.com/Yv2WEYc.png');
  if (n.includes('dark'))                         return img('https://i.imgur.com/7Luj4az.png');
  if (n.includes('dragon'))                       return img('https://i.imgur.com/o7JWbaN.png');
  if (n.includes('ghost'))                        return img('https://i.imgur.com/HuybbPn.png');
  if (n.includes('fairy'))                        return img('https://i.imgur.com/j3HaXTh.png');
  if (n.includes('flying'))                       return img('https://i.imgur.com/npGjQae.png');
  if (n.includes('bug'))                          return img('https://i.imgur.com/V4IXR51.png');
  if (n.includes('fighting') || n.includes('figthing')) return img('https://i.imgur.com/OKsJXh7.png');
  return img('https://i.imgur.com/zpRe43i.png');
}

function getPkgItemData(itemName) {
  return items.find(i => i.name.toLowerCase() === itemName.toLowerCase()) || null;
}

function getPkgAllItems(pkg) {
  return (pkg.slots || []).flat();
}
function getPkgTotal(pkg, pi) {
  const src = (pi !== undefined) ? getPkgActiveItems(pkg, pi) : getPkgAllItems(pkg);
  return src.reduce((sum, [name, qty]) => {
    const item = getPkgItemData(name);
    return sum + (item && item.price ? item.price * qty : 0);
  }, 0);
}

// Categoria ativa na sidebar de pacotes
let activePkgCat = 'all';

function getPkgCategory(name) {
  const n = name.toLowerCase();
  if (n.startsWith('talent')) return 'talent';
  if (n.startsWith('gym'))    return 'gym';
  if (n.startsWith('full'))   return 'full';
  if (n.startsWith('reduces') || n.startsWith('reduce')) return 'reduces';
  return 'outros';
}

const PKG_CAT_META = {
  all:     { label: 'Todos',    icon: '📦' },
  talent:  { label: 'Talents',  icon: '✨' },
  gym:     { label: 'Gym',      icon: '<img src="https://i.imgur.com/XyBY6d2.png" style="width:20px;height:20px;object-fit:contain" />' },
  full:    { label: 'Full',     icon: '⚡' },
  reduces: { label: 'Reduces',  icon: '<img src="https://i.imgur.com/KgwwD7D.png" style="width:20px;height:20px;object-fit:contain" />' },
  outros:  { label: 'Outros',   icon: '🎲' },
};

function renderPkgCatTabs() {
  const el = document.getElementById('pkg-cat-tabs');
  if (!el) return;
  // Descobrir quais categorias existem
  const cats = ['all', ...new Set(PACKAGES.map(p => getPkgCategory(p.name)))];
  el.innerHTML = cats.map(cat => {
    const count = cat === 'all' ? PACKAGES.length : PACKAGES.filter(p => getPkgCategory(p.name) === cat).length;
    const meta = PKG_CAT_META[cat] || { label: cat, icon: '📌' };
    return `<button class="pkg-cat-btn${activePkgCat === cat ? ' active' : ''}" onclick="selectPkgCat('${cat}')">
      <span class="pkg-cat-icon">${meta.icon}</span>
      ${meta.label}
      <span class="pkg-cat-count">${count}</span>
    </button>`;
  }).join('');
}

function selectPkgCat(cat) {
  activePkgCat = cat;
  // Se pacote ativo não pertence à nova categoria, deseleciona
  if (activePkgIdx !== null && cat !== 'all') {
    if (getPkgCategory(PACKAGES[activePkgIdx].name) !== cat) {
      activePkgIdx = null;
      document.getElementById('pkg-detail').innerHTML = `
        <div class="pkg-detail-empty" id="pkg-detail-empty">
          <div class="pkg-detail-empty-icon">📋</div>
          <div class="pkg-detail-empty-text">Selecione um pacote</div>
        </div>`;
    }
  }
  renderPackages();
}

// ── Patch CSS: pkg-sidebar-item-name sem truncar ──────────────────────────
(function () {
  var _patchStyle = document.getElementById('pkg-sidebar-name-patch');
  if (_patchStyle) return; // já injetado
  var s = document.createElement('style');
  s.id = 'pkg-sidebar-name-patch';
  s.textContent = `
    .pkg-sidebar-item-name {
      white-space: normal !important;
      overflow: visible !important;
      text-overflow: unset !important;
      overflow-wrap: break-word !important;
      word-break: break-word !important;
      line-height: 1.3 !important;
    }
  `;
  document.head.appendChild(s);
})();

function renderPackages() {
  const sidebarList = document.getElementById('pkg-sidebar-list');
  if (!sidebarList) return;

  renderPkgCatTabs();

  if (!PACKAGES.length) {
    sidebarList.innerHTML = '<div style="padding:16px;font-family:var(--font-mono);font-size:11px;color:var(--muted);text-align:center">Nenhum pacote</div>';
    return;
  }

  const filtered = PACKAGES.map((pkg, pi) => ({ pkg, pi }))
    .filter(({ pkg }) => activePkgCat === 'all' || getPkgCategory(pkg.name) === activePkgCat);

  sidebarList.innerHTML = filtered.map(({ pkg, pi }) => {
    const icon = getPkgIcon(pkg.name);
    const isActive = activePkgIdx === pi;
    const added = pkgCartCount && pkgCartCount[pi] ? pkgCartCount[pi] : 0;
    const glowClass = added ? ' is-in-cart' : '';
    const pkgColor = getPkgTypeColor(pkg.name);
    return `<div class="pkg-sidebar-item${isActive ? ' active' : ''}${glowClass}" onclick="selectPkg(${pi})" style="--pkg-color:${pkgColor}">
      ${added ? `<div class="pkg-card-cart-badge">✓ ×${added}</div>` : ''}
      <div class="pkg-sidebar-item-icon">${icon}</div>
      <div class="pkg-sidebar-item-info">
        <div class="pkg-sidebar-item-name">${pkg.name}</div>
        <div class="pkg-sidebar-item-sub">${getPkgAllItems(pkg).length} ${getPkgAllItems(pkg).length === 1 ? 'item' : 'itens'}</div>
      </div>
    </div>`;
  }).join('');

  if (activePkgIdx !== null) renderPkgDetail(activePkgIdx);
}

function selectPkg(pi) {
  activePkgIdx = pi;
  renderPackages();
  renderPkgDetail(pi);
}

// Slot ativo por pacote
const activeSlotByPkg = {};
// disabledPkgItems[pi] = Set de chaves "si:itemName" desativados
const disabledPkgItems = {};

function pkgItemKey(si, name) { return si + ':' + name; }

function isPkgItemDisabled(pi, si, name) {
  return disabledPkgItems[pi] && disabledPkgItems[pi].has(pkgItemKey(si, name));
}

function togglePkgItem(pi, si, name) {
  if (!disabledPkgItems[pi]) disabledPkgItems[pi] = new Set();
  const key = pkgItemKey(si, name);
  if (disabledPkgItems[pi].has(key)) disabledPkgItems[pi].delete(key);
  else disabledPkgItems[pi].add(key);
  renderPkgDetail(pi);
}

function getPkgActiveItems(pkg, pi) {
  // Retorna apenas itens não desativados de todos os slots
  return (pkg.slots || []).flatMap((slot, si) =>
    slot.filter(([name]) => !isPkgItemDisabled(pi, si, name))
  );
}

function getSlotLabel(pkg, si) {
  const n = pkg.name.toLowerCase();
  if (n.includes('talent')) return 'Talent ' + (si + 1);
  if (n.includes('gym'))    return 'Slot ' + (si + 1);
  if (n.includes('full'))   return 'Slot ' + (si + 1);
  return 'Slot ' + (si + 1);
}

function renderPkgDetail(pi) {
  const detail = document.getElementById('pkg-detail');
  const pkg = PACKAGES[pi];
  const totalRaw = getPkgTotal(pkg, pi);
  const totalData = totalRaw > 0 ? formatKK(totalRaw) : null;
  const added = pkgCartCount && pkgCartCount[pi] ? pkgCartCount[pi] : 0;
  const allItems = getPkgAllItems(pkg);
  const slots = pkg.slots || [allItems];
  const hasSlots = slots.length > 1;

  if (activeSlotByPkg[pi] === undefined) activeSlotByPkg[pi] = 0;
  const si = Math.min(activeSlotByPkg[pi], slots.length - 1);
  const currentSlot = slots[si];

  // Slot tabs — mostra preço só dos itens ativos do slot
  const slotTabsHtml = hasSlots ? `
    <div class="pkg-slot-tabs" id="pkg-slot-tabs-${pi}">
      ${slots.map((slot, idx) => {
        const slotTotal = slot.reduce((s, [n, q]) => {
          if (isPkgItemDisabled(pi, idx, n)) return s;
          const it = getPkgItemData(n);
          return s + (it && it.price ? it.price * q : 0);
        }, 0);
        const slotData = slotTotal > 0 ? formatKK(slotTotal) : null;
        const disabledCount = slot.filter(([n]) => isPkgItemDisabled(pi, idx, n)).length;
        const noPriceCount = slot.filter(([n]) => {
          if (isPkgItemDisabled(pi, idx, n)) return false;
          const it = getPkgItemData(n);
          return !it || !it.price;
        }).length;
        const noPriceWarn = noPriceCount > 0
          ? `<span class="pkg-slot-no-price-warn">⚠ ${noPriceCount} s/preço</span>`
          : '';
        const hasNoPriceCls = noPriceCount > 0 ? ' has-no-price' : '';
        return `<button class="pkg-slot-btn${idx === si ? ' active' : ''}${disabledCount === slot.length ? ' all-disabled' : ''}${hasNoPriceCls}" onclick="selectPkgSlot(${pi}, ${idx})">
          <span class="pkg-slot-btn-label">${getSlotLabel(pkg, idx)}</span>
          ${slotData ? `<span class="pkg-slot-btn-price">${slotData.label}</span>` : ''}
          <span class="pkg-slot-btn-count">${slot.length - disabledCount}/${slot.length} itens</span>
          ${noPriceWarn}
        </button>`;
      }).join('')}
    </div>` : '';

  // Rows — clicáveis para ativar/desativar
  const rowsHtml = currentSlot.map(([name, qty]) => {
    const disabled = isPkgItemDisabled(pi, si, name);
    const item = getPkgItemData(name);
    const lineTotal = !disabled && item && item.price && qty > 0 ? item.price * qty : 0;
    const priceData = lineTotal > 0 ? formatKK(lineTotal) : null;
    return `<div class="pkg-detail-row${disabled ? ' row-disabled' : ''}" onclick="togglePkgItem(${pi}, ${si}, '${name.replace(/'/g,"\'")}')">
      <div class="pkg-detail-row-icon">${disabled ? '○' : '◆'}</div>
      <span class="pkg-detail-row-name">${name}<button class="wiki-lookup-btn" onclick="openWikiLookup('${name.replace(/'/g,"\\'")}', event)" title="Ver drops na Wiki"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></button></span>
      <div class="pkg-detail-row-right">
        <span class="pkg-detail-row-price">${disabled ? '<span class="row-disabled-label">removido</span>' : (priceData ? priceData.label : '—')}</span>
        <span class="pkg-detail-row-qty">×${qty.toLocaleString()}</span>
        <span class="pkg-row-toggle-btn">${disabled ? '↩' : '✕'}</span>
      </div>
    </div>`;
  }).join('');

  const addedClass = added ? ' added' : '';
  const addedLabel = added ? `✓ Adicionado ×${added}` : '+ Adicionar ao Carrinho';
  const activeCount = getPkgActiveItems(pkg, pi).length;
  const totalCount = allItems.length;
  const countLabel = activeCount < totalCount
    ? `${activeCount}/${totalCount} itens ativos · ${slots.length} ${slots.length === 1 ? 'slot' : 'slots'}`
    : `${totalCount} itens · ${slots.length} ${slots.length === 1 ? 'slot' : 'slots'}`;

  detail.innerHTML = `
    <div class="pkg-detail-header">
      <div class="pkg-detail-title">${pkg.name}</div>
      <div class="pkg-detail-meta">
        <span class="pkg-detail-count">${countLabel}</span>
        ${totalData ? `<span class="pkg-detail-price">${totalData.label} · ${totalData.brl}</span>` : ''}
      </div>
    </div>
    ${slotTabsHtml}
    <div class="pkg-detail-body" id="pkg-detail-body-${pi}">${rowsHtml}</div>
    <div class="pkg-detail-footer">
      <div class="pkg-detail-total-block">
        ${totalData ? `
          <span class="pkg-detail-total-label">Total ativo</span>
          <span class="pkg-detail-total-kk">${totalData.label}</span>
          <span class="pkg-detail-total-brl">${totalData.brl}</span>
        ` : '<span class="pkg-detail-total-label" style="color:var(--muted)">preço não definido</span>'}
      </div>
      <div id="pkgrem-detail-${pi}"></div>
      <button class="pkg-detail-add-btn${addedClass}" id="pkgbtn-detail-${pi}" onclick="addPackageToCartDirect(${pi})">
        ${addedLabel}
      </button>
    </div>`;

  if (added) {
    const remSlot = document.getElementById('pkgrem-detail-' + pi);
    if (remSlot) {
      remSlot.innerHTML = `<button class="pkg-detail-rem-btn" onclick="removePackageFromCart(${pi})" title="Remover do carrinho">✕</button>`;
    }
  }
}

function selectPkgSlot(pi, si) {
  activeSlotByPkg[pi] = si;
  renderPkgDetail(pi);
}

function openPkgModal(pi) {
  // Compatibilidade — agora abre inline
  selectPkg(pi);
}

function renderPkgModalRows() {
  // Mantido para compatibilidade
  if (activePkgIdx !== null) renderPkgDetail(activePkgIdx);
}

function updatePkgQty(idx, val) {
  const qty = Math.max(0, parseInt(val, 10) || 0);
  currentPkgState[idx].qty = qty;
  const item = getPkgItemData(currentPkgState[idx].name);
  const lineTotal = item && item.price && qty > 0 ? item.price * qty : 0;
  const priceEl = document.getElementById('pkg-price-' + idx);
  if (priceEl) priceEl.textContent = lineTotal > 0 ? formatKK(lineTotal).label : '—';
  updatePkgTotal();
}

function removePkgItem(idx) {
  currentPkgState[idx].qty = 0;
  const row = document.getElementById('pkg-row-' + idx);
  if (row) row.classList.add('removed');
  const priceEl = document.getElementById('pkg-price-' + idx);
  if (priceEl) priceEl.textContent = '—';
  updatePkgTotal();
}

function updatePkgTotal() {
  let totalRaw = 0;
  currentPkgState.forEach(entry => {
    const item = getPkgItemData(entry.name);
    if (item && item.price && entry.qty > 0) totalRaw += item.price * entry.qty;
  });
  const totalBlock = document.getElementById('pkg-modal-total');
  if (totalBlock) {
    if (totalRaw > 0) {
      const td = formatKK(totalRaw);
      const kkEl = document.getElementById('pkg-modal-kk');
      const brlEl = document.getElementById('pkg-modal-brl');
      if (kkEl) kkEl.textContent = td.label;
      if (brlEl) brlEl.textContent = td.brl;
      totalBlock.style.display = 'flex';
    } else {
      totalBlock.style.display = 'none';
    }
  }
}

function closePkgModal() {
  const overlay = document.getElementById('pkg-overlay');
  if (overlay) overlay.classList.remove('open');
  currentPkg = null;
  currentPkgState = [];
}

function handlePkgOverlayClick(e) {
  if (e.target === document.getElementById('pkg-overlay')) closePkgModal();
}

function addPackageToCart() {
  if (currentPkg === null) return;
  currentPkgState.forEach(entry => {
    if (!entry.qty || entry.qty <= 0) return;
    const idx = items.findIndex(i => i.name.toLowerCase() === entry.name.toLowerCase());
    if (idx === -1) return;
    cart[idx] = (cart[idx] || 0) + entry.qty;
  });
  updateCartBadge();
  closePkgModal();
}

function addPackageToCartDirect(pi) {
  pkgCartCount = pkgCartCount || {};
  pkgCartCount[pi] = (pkgCartCount[pi] || 0) + 1;

  let noPriceNames = [];
  getPkgActiveItems(PACKAGES[pi], pi).forEach(([name, qty]) => {
    if (!qty || qty <= 0) return;
    const idx = items.findIndex(i => i.name.toLowerCase() === name.toLowerCase());
    if (idx === -1) return;
    cart[idx] = (cart[idx] || 0) + qty;
    if (!items[idx].price) noPriceNames.push(name);
    const btn = document.getElementById('addbtn-' + idx);
    const lbl = document.getElementById('addbtn-label-' + idx);
    if (btn) btn.classList.add('added');
    if (lbl) lbl.textContent = '\u2713 ' + cart[idx].toLocaleString();
    const remSlot = document.getElementById('rembtn-' + idx);
    if (remSlot && remSlot.tagName === 'SPAN') {
      const remBtn = document.createElement('button');
      remBtn.className = 'inline-rem-btn';
      remBtn.id = 'rembtn-' + idx;
      remBtn.title = 'Remover do carrinho';
      remBtn.innerHTML = '\u2715';
      remBtn.onclick = () => removeFromCart(idx);
      remSlot.replaceWith(remBtn);
    }
  });

  if (noPriceNames.length > 0) {
    const toast = document.getElementById('no-price-toast');
    const msg = document.getElementById('no-price-toast-msg');
    if (toast && msg) {
      msg.textContent = 'O pacote contém ' + noPriceNames.length + ' item(ns) sem preço definido: ' + noPriceNames.join(', ') + '. O total será ajustado quando os preços forem estabelecidos.';
      toast.classList.add('show');
      clearTimeout(_toastTimer);
      _toastTimer = setTimeout(() => toast.classList.remove('show'), 6000);
    }
  }
  updateCartBadge();

  // Atualiza detalhe inline
  if (activePkgIdx === pi) renderPkgDetail(pi);
  renderPackages();
}

function removePackageFromCart(pi) {
  pkgCartCount = pkgCartCount || {};
  getPkgAllItems(PACKAGES[pi]).forEach(([name]) => {
    const idx = items.findIndex(i => i.name.toLowerCase() === name.toLowerCase());
    if (idx === -1) return;
    delete cart[idx];
    const btn = document.getElementById('addbtn-' + idx);
    const lbl = document.getElementById('addbtn-label-' + idx);
    if (btn) { btn.classList.remove('added'); }
    if (lbl) { lbl.textContent = 'Adicionar'; }
    const remBtn = document.getElementById('rembtn-' + idx);
    if (remBtn && remBtn.tagName === 'BUTTON') {
      const span = document.createElement('span');
      span.id = 'rembtn-' + idx;
      remBtn.replaceWith(span);
    }
  });
  delete pkgCartCount[pi];
  updateCartBadge();
  if (document.getElementById('cart-overlay').classList.contains('open')) {
    renderCart();
  }
  // Atualiza detalhe inline se estiver visível
  if (activePkgIdx === pi) renderPkgDetail(pi);
  renderPackages();
}

// ===================== VISUAL FX =====================


// --- Click Ripple + Sparks ---
(function() {
  const root = document.getElementById('ripple-root');
  const COLORS = ['rgba(58,140,255,0.7)','rgba(240,180,41,0.7)','rgba(96,170,255,0.7)','rgba(255,209,102,0.6)'];
  document.addEventListener('click', e => {
    const x = e.clientX, y = e.clientY;
    const col = COLORS[Math.floor(Math.random()*COLORS.length)];
    // Main ripple
    const r = document.createElement('div');
    r.className = 'click-ripple';
    const sz = 120 + Math.random()*80;
    Object.assign(r.style, {
      left: x+'px', top: y+'px',
      width: sz+'px', height: sz+'px',
      background: `radial-gradient(circle, ${col} 0%, transparent 70%)`,
      border: `1.5px solid ${col}`
    });
    root.appendChild(r);
    setTimeout(() => r.remove(), 700);
    // Sparks
    const numSparks = 8 + Math.floor(Math.random()*6);
    for (let i = 0; i < numSparks; i++) {
      const s = document.createElement('div');
      s.className = 'click-sparks';
      const angle = (i / numSparks) * Math.PI * 2;
      const dist  = 30 + Math.random() * 50;
      const tx    = Math.cos(angle) * dist;
      const ty    = Math.sin(angle) * dist;
      const sz2   = 2 + Math.random()*3;
      Object.assign(s.style, {
        left: x+'px', top: y+'px',
        width: sz2+'px', height: sz2+'px',
        background: col,
        borderRadius: '50%',
        transition: `transform 0.5s ease-out, opacity 0.5s ease-out`
      });
      root.appendChild(s);
      requestAnimationFrame(() => {
        s.style.transform = `translate(${tx}px, ${ty}px) scale(0)`;
        s.style.opacity   = '0';
      });
      setTimeout(() => s.remove(), 550);
    }
  });
})();

// --- Card 3D Tilt REMOVIDO (causava jank: getBoundingClientRect em todos os cards a cada mousemove) ---
// Shine div ainda é injetado para o efeito CSS funcionar
(function() {
  function injectShine() {
    document.querySelectorAll('.card:not([data-shine])').forEach(function(card) {
      card.setAttribute('data-shine','1');
      var shine = document.createElement('div');
      shine.className = 'card-shine';
      card.appendChild(shine);
    });
  }
  var obs = new MutationObserver(injectShine);
  obs.observe(document.getElementById('grid'), { childList: true, subtree: true });
  var pkgSidebar = document.getElementById('pkg-sidebar-list');
  if (pkgSidebar) obs.observe(pkgSidebar, { childList: true, subtree: true });
  var capturaGrid = document.getElementById('captura-grid');
  if (capturaGrid) obs.observe(capturaGrid, { childList: true, subtree: true });
  injectShine();
})();


// --- WebGL plasma shader REMOVIDO (causava jank no scroll) ---
(function() {
  var canvas = document.getElementById('shader-canvas');
  if (canvas) canvas.style.display = 'none';
})();

// --- Floating ambient particles REMOVIDAS (causavam repaint constante) ---

// --- Add burst animation on addToCart ---
const _origAddToCart = addToCart;
addToCart = function(i) {
  _origAddToCart(i);
  const card = document.querySelector(`#addbtn-${i}`)?.closest('.card');
  if (card) { card.classList.remove('burst'); void card.offsetWidth; card.classList.add('burst'); }
};

// ===================== BROKE DATA =====================
// Tabela de max brokes por tier (para shinys)
const BROKE_DATA = {
  't1':         { max: 1280,    label: '1.280 UB' },
  't2':         { max: 900,     label: '~900 UB',  approx: true },
  't3':         { max: 700,     label: '~700 UB',  approx: true },
  't4':         { max: 600,     label: '~600 UB',  approx: true },
  't5':         { max: 400,     label: '~400 UB',  approx: true },
  't6':         { max: 200,     label: '~200 UB',  approx: true },
  'super-raro': { max: 3512,   label: '3.512 UB' },
  'ultra-raro': { max: 9100,   label: '9.100 UB' },
  'legendary':  { max: 22535,  label: '22.535 UB' },
  'mythical':   { max: null,   label: '? UB' },
};

function getBrokeForTag(tag) {
  if (!tag) return null;
  return BROKE_DATA[tag] || null;
}

// ===================== CAPTURA =====================
// Formato: { name: "Nome", price: <raw kk igual RAW>, image: "url" }
// Exemplos de preço: 1000000 = 1kk | 5000000 = 5kk | 500000 = 500k | 0 = sem preço
const POKEMONS = [
{ name: "Shiny Ampharos",    price: 38000000,  tag: "t1",         image: "https://i.imgur.com/DecvtNB.gif", bannerImage: "https://i.imgur.com/Yv2WEYc.png" },
{ name: "Shiny Arbok",       price: 5000000,   tag: "t3",         image: "https://i.imgur.com/Lx8tTwy.gif", bannerImage: "https://i.imgur.com/xfX0ReE.png" },
{ name: "Shiny Ariados",     price: 5000000,   tag: "t3",         image: "https://i.imgur.com/4qVdNjM.gif", bannerImage: "https://i.imgur.com/V4IXR51.png" },
{ name: "Shiny Bellossom",   price: 5000000,   tag: "t3",         image: "https://i.imgur.com/vo0GY2X.gif", bannerImage: "https://i.imgur.com/YjKxtoE.png" },
{ name: "Shiny Blastoise",   price: 38000000,  tag: "t1",         image: "https://i.imgur.com/9iQ7wNL.gif", bannerImage: "https://i.imgur.com/zpRe43i.png" },
{ name: "Shiny Charizard", price: 38000000, tag: "t1", image: "https://i.imgur.com/SrQU5gi.gif", bannerImage: "https://i.imgur.com/O8TONGE.png" },
{ name: "Shiny Crobat",      price: 10000000,   tag: "t2",         image: "https://i.imgur.com/agzGxZH.gif", bannerImage: "https://i.imgur.com/npGjQae.png" },
{ name: "Shiny Donphan",     price: 10000000,   tag: "t2",         image: "https://i.imgur.com/9xd9h6l.gif", bannerImage: "https://i.imgur.com/JPcD2l3.png" },
{ name: "Shiny Dugtrio",     price: 5000000,   tag: "t3",         image: "https://i.imgur.com/F9jJz0e.gif", bannerImage: "https://i.imgur.com/JPcD2l3.png" },
{ name: "Shiny Dusknoir",    price: 170000000, tag: "super-raro", image: "https://i.imgur.com/A0bWaq4.gif", bannerImage: "https://i.imgur.com/HuybbPn.png" },
{ name: "Shiny Espeon",      price: 42000000,  tag: "t1",         image: "https://i.imgur.com/Zws7DJo.gif", bannerImage: "https://i.imgur.com/ASiZi1K.png" },
{ name: "Shiny Exeggutor",   price: 10000000,   tag: "t2",         image: "https://i.imgur.com/OpvTaP1.gif", bannerImage: "https://i.imgur.com/YjKxtoE.png" },
{ name: "Shiny Farfetch'd",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/Vo6volA.gif", bannerImage: "https://i.imgur.com/npGjQae.png" },
{ name: "Shiny Fearow",      price: 5000000,   tag: "t3",         image: "https://i.imgur.com/wNR2Ija.gif", bannerImage: "https://i.imgur.com/npGjQae.png" },
{ name: "Shiny Feraligatr",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/DP4YWT1.gif", bannerImage: "https://i.imgur.com/zpRe43i.png" },
{ name: "Shiny Flareon",     price: 38000000,  tag: "t1",         image: "https://i.imgur.com/9UowZtR.gif", bannerImage: "https://i.imgur.com/O8TONGE.png" },
{ name: "Shiny Florges",     price: 170000000, tag: "super-raro", image: "https://i.imgur.com/fynxTta.gif", bannerImage: "https://i.imgur.com/j3HaXTh.png" },
{ name: "Shiny Golem",       price: 38000000,  tag: "t1",         image: "https://i.imgur.com/6Wphle1.gif", bannerImage: "https://i.imgur.com/GvD1Mtq.png" },
{ name: "Shiny Grambull",    price: 10000000,   tag: "t2",         image: "https://i.imgur.com/lPlawhM.gif", bannerImage: "https://i.imgur.com/j3HaXTh.png" },
{ name: "Shiny Hitmonchan",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/5XHDbmn.gif", bannerImage: "https://i.imgur.com/OKsJXh7.png" },
{ name: "Shiny Hitmonlee",   price: 38000000,  tag: "t1",         image: "https://i.imgur.com/uzewWkj.gif", bannerImage: "https://i.imgur.com/OKsJXh7.png" },
{ name: "Shiny Hitmontop",   price: 38000000,  tag: "t1",         image: "https://i.imgur.com/YWsKw3O.gif", bannerImage: "https://i.imgur.com/OKsJXh7.png" },
{ name: "Shiny Jolteon",     price: 38000000,  tag: "t1",         image: "https://i.imgur.com/3Jc5ZUX.gif", bannerImage: "https://i.imgur.com/Yv2WEYc.png" },
{ name: "Shiny Jynx",        price: 38000000,  tag: "t1",         image: "https://i.imgur.com/VNGVJBo.gif", bannerImage: "https://i.imgur.com/ssFz0sA.png" },
{ name: "Shiny Luxray",      price: 170000000, tag: "super-raro", image: "https://i.imgur.com/sWnyJd1.gif", bannerImage: "https://i.imgur.com/Yv2WEYc.png" },
{ name: "Shiny Magneton",    price: 10000000,   tag: "t2",         image: "https://i.imgur.com/ZcDUckg.gif", bannerImage: "https://i.imgur.com/GleRjiM.png" },
{ name: "Shiny Meganium",    price: 38000000,  tag: "t1",         image: "https://i.imgur.com/eJvTQJ7.gif", bannerImage: "https://i.imgur.com/YjKxtoE.png" },
{ name: "Shiny Nidoking",    price: 38000000,  tag: "t1",         image: "https://i.imgur.com/xeDriFy.gif", bannerImage: "https://i.imgur.com/xfX0ReE.png" },
{ name: "Shiny Nidoqueen",   price: 38000000,  tag: "t1",         image: "https://i.imgur.com/iIMkTqF.gif", bannerImage: "https://i.imgur.com/JPcD2l3.png" },
{ name: "Shiny Ninetales",   price: 38000000,  tag: "t1",         image: "https://i.imgur.com/u0sGCqg.gif", bannerImage: "https://i.imgur.com/O8TONGE.png" },
{ name: "Shiny Pidgeot",     price: 38000000,  tag: "t1",         image: "https://i.imgur.com/pHY01e0.gif", bannerImage: "https://i.imgur.com/npGjQae.png" },
{ name: "Shiny Politoad",    price: 38000000,  tag: "t1",         image: "https://i.imgur.com/yLbIDLz.gif", bannerImage: "https://i.imgur.com/zpRe43i.png" },
{ name: "Shiny Poliwrath",   price: 38000000,  tag: "t1",         image: "https://i.imgur.com/W6WAMQH.gif", bannerImage: "https://i.imgur.com/OKsJXh7.png" },
{ name: "Shiny Primeape",    price: 5000000,   tag: "t3",         image: "https://i.imgur.com/14eRtXp.gif", bannerImage: "https://i.imgur.com/OKsJXh7.png" },
{ name: "Shiny Raichu",      price: 38000000,  tag: "t1",         image: "https://i.imgur.com/EbsLav0.gif", bannerImage: "https://i.imgur.com/Yv2WEYc.png" },
{ name: "Shiny Rhydon",      price: 10000000,   tag: "t2",         image: "https://i.imgur.com/N0xE5Jd.gif", bannerImage: "https://i.imgur.com/JPcD2l3.png" },
{ name: "Shiny Sandslash",   price: 5000000,   tag: "t3",         image: "https://i.imgur.com/KXpdDgh.gif", bannerImage: "https://i.imgur.com/JPcD2l3.png" },
{ name: "Shiny Starmie",     price: 10000000,   tag: "t2",         image: "https://i.imgur.com/y0z0Tkt.gif", bannerImage: "https://i.imgur.com/zpRe43i.png" },
{ name: "Shiny Steelix",     price: 38000000,  tag: "t1",         image: "https://i.imgur.com/zY5AuG0.gif", bannerImage: "https://i.imgur.com/JPcD2l3.png" },
{ name: "Shiny Magcargo",     price: 38000000,  tag: "t1",         image: "https://i.imgur.com/dGiBfxE.gif", bannerImage: "https://i.imgur.com/GvD1Mtq.png" },
{ name: "Shiny Tangela",     price: 10000000,   tag: "t2",         image: "https://i.imgur.com/CkrSdpJ.gif", bannerImage: "https://i.imgur.com/YjKxtoE.png" },
{ name: "Shiny Heracross",     price: 15000000,   tag: "t2",         image: "https://i.imgur.com/r1hdJz1.gif", bannerImage: "https://i.imgur.com/OKsJXh7.png" },
{ name: "Shiny Onix",     price: 10000000,   tag: "t2",         image: "https://i.imgur.com/VO2wrSz.gif", bannerImage: "https://i.imgur.com/GvD1Mtq.png" },
{ name: "Shiny Tangrowth",   price: 170000000, tag: "super-raro", image: "https://i.imgur.com/Ep4wVmN.gif", bannerImage: "https://i.imgur.com/YjKxtoE.png" },
{ name: "Shiny Tentacruel",  price: 38000000,  tag: "t1", dive: true, image: "https://i.imgur.com/I9J30Si.gif", bannerImage: "https://i.imgur.com/xfX0ReE.png" },
{ name: "Shiny Torterra",    price: 170000000, tag: "super-raro", image: "https://i.imgur.com/yp3SFUz.gif", bannerImage: "https://i.imgur.com/JPcD2l3.png" },
{ name: "Shiny Machamp",    price: 170000000, tag: "super-raro", image: "https://i.imgur.com/rVgDyg7.gif", bannerImage: "https://i.imgur.com/OKsJXh7.png" },
{ name: "Shiny Typhlosion",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/2BtRLDx.gif", bannerImage: "https://i.imgur.com/O8TONGE.png" },
{ name: "Shiny Umbreon",     price: 42000000,  tag: "t1",         image: "https://i.imgur.com/G5vLr8q.gif", bannerImage: "https://i.imgur.com/7Luj4az.png" },
{ name: "Shiny Vaporeon",    price: 38000000,  tag: "t1",         image: "https://i.imgur.com/ZiHkl9v.gif", bannerImage: "https://i.imgur.com/zpRe43i.png" },
{ name: "Shiny Venusaur",    price: 38000000,  tag: "t1",         image: "https://i.imgur.com/gmZVZIS.gif", bannerImage: "https://i.imgur.com/YjKxtoE.png" },
{ name: "Shiny Victreebel",  price: 5000000,   tag: "t3",         image: "https://i.imgur.com/Wz5rU8G.gif", bannerImage: "https://i.imgur.com/YjKxtoE.png" },
{ name: "Shiny Vileplume",   price: 10000000,   tag: "t2",         image: "https://i.imgur.com/62jbqox.gif", bannerImage: "https://i.imgur.com/YjKxtoE.png" },
{ name: "Shiny Xatu",        price: 10000000,   tag: "t2",         image: "https://i.imgur.com/I3KwmrR.gif", bannerImage: "https://i.imgur.com/HuybbPn.png" },
{ name: "Dusknoir",          price: 32000000,  tag: "t1",         image: "https://i.imgur.com/yIyXLpT.gif", bannerImage: "https://i.imgur.com/HuybbPn.png" },
{ name: "Luxray",            price: 32000000,  tag: "t1",         image: "https://i.imgur.com/vLUBjp6.gif", bannerImage: "https://i.imgur.com/Yv2WEYc.png" },
{ name: "Tangrowth",         price: 32000000,  tag: "t1",         image: "https://i.imgur.com/EpEQ1Wx.gif", bannerImage: "https://i.imgur.com/YjKxtoE.png" },
{ name: "Torterra",          price: 32000000,  tag: "t1",         image: "https://i.imgur.com/PBn3OXz.gif", bannerImage: "https://i.imgur.com/JPcD2l3.png" },
{ name: "Shiny Dodrio",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/X5uC13u.gif", bannerImage: "https://i.imgur.com/npGjQae.png" },
{ name: "Shiny Kingdra",    price: 170000000, tag: "super-raro", image: "https://i.imgur.com/ZPszNYT.gif", bannerImage: "https://i.imgur.com/zpRe43i.png" },
 <!-- { name: "Shiny Kabutops",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/t7vEAaB.gif" }, -->
{ name: "Shiny Arcanine",    price: 170000000, tag: "super-raro", image: "https://i.imgur.com/BqakQU0.gif", bannerImage: "https://i.imgur.com/O8TONGE.png" },
{ name: "Shiny Kangaskhan",  price: 170000000,  tag: "super-raro",         image: "https://i.imgur.com/wgjSoja.gif", bannerImage: "https://i.imgur.com/OKsJXh7.png" },
{ name: "Shiny Lapras",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/nVzbMx2.gif", bannerImage: "https://i.imgur.com/ssFz0sA.png" },
{ name: "Shiny Qwilfish",     price: 10000000,   tag: "t3", dive: true,  image: "https://i.imgur.com/FYlu9Rd.gif", bannerImage: "https://i.imgur.com/xfX0ReE.png" },
{ name: "Shiny Slowking",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/koy11aG.gif", bannerImage: "https://i.imgur.com/ASiZi1K.png" },
{ name: "Shiny Skarmory",  price: 170000000,  tag: "super-raro",         image: "https://i.imgur.com/B2l8aVE.gif", bannerImage: "https://i.imgur.com/GleRjiM.png" },
{ name: "Shiny Toxicroak",  price: 170000000,  tag: "super-raro",         image: "https://i.imgur.com/BUSWRd6.gif", bannerImage: "https://i.imgur.com/xfX0ReE.png" },
{ name: "Shiny Misdreavus",  price: 170000000,  tag: "super-raro",         image: "https://i.imgur.com/mgtoi05.gif", bannerImage: "https://i.imgur.com/HuybbPn.png" },
{ name: "Shiny Rapidash",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/1dWZFHK.gif", bannerImage: "https://i.imgur.com/Yv2WEYc.png" },
{ name: "Shiny Muk",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/zWWBobI.gif", bannerImage: "https://i.imgur.com/xfX0ReE.png" },
{ name: "Shiny Marowak",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/ZzOu7hp.gif", bannerImage: "https://i.imgur.com/JPcD2l3.png" },
{ name: "Shiny Mantine",  price: 38000000,  tag: "t1",         image: "https://i.imgur.com/wfiogx3.gif", bannerImage: "https://i.imgur.com/npGjQae.png" },
{ name: "Shiny Delibird",     price: 10000000,   tag: "t3",         image: "https://i.imgur.com/HC4VMvm.gif", bannerImage: "https://i.imgur.com/ssFz0sA.png" },
];
// Store original index for O(1) lookup
POKEMONS.forEach((p, i) => { p._idx = i; });

// Injeta bannerImage nos items a partir do POKEMONS
POKEMONS.forEach(p => {
  if (!p.bannerImage) return;
  const item = items.find(it => it.name === p.name);
  if (item) item.bannerImage = p.bannerImage;
});

const BALLS = [
  { id: "ultra",    name: "Ultra Ball",    emoji: '<img src="https://i.imgur.com/D5T6Dgw.png" style="width:40px;height:40px;object-fit:contain" />', color: "var(--gold)",        mult: 1.0 },
  { id: "premier",  name: "Premier Ball",  emoji: '<img src="https://i.imgur.com/sIwvw2L.png" style="width:40px;height:40px;object-fit:contain" />', color: "var(--gold)",        mult: 0.8, minPrice: 1000 },
  { id: "alliance", name: "Alliance Ball", emoji: '<img src="https://i.imgur.com/QFXUD5f.png" style="width:40px;height:40px;object-fit:contain" />', color: "var(--gold)",        mult: 0.8, minPrice: 1000 },
];

let currentCapturaIdx = null;
let selectedBall = null;

function getCapturaTagHtml(tag) {
  if (!tag) return '';
  const labels = {
    't1': 'T1', 't2': 'T2', 't3': 'T3', 't4': 'T4', 't5': 'T5', 't6': 'T6',
    'super-raro': 'Super Raro', 'ultra-raro': 'Ultra Raro', 'raro': 'Raro',
    'legendary': 'Legendary', 'mythical': 'Mítico', 'dive': '<img src="https://i.imgur.com/zpRe43i.png" style="height:14px;vertical-align:middle;margin-right:4px;"> Dive'
  };
  const label = labels[tag];
  if (!label) return '';
  return `<span class="captura-tag ctag-${tag}">${label}</span>`;
}

function renderCaptura() {
  const grid = document.getElementById('captura-grid');
  const q = (document.getElementById('captura-search')?.value || '').toLowerCase();
  const tagFilter = (document.getElementById('captura-filter')?.value || 'all');
  const typeFilter = window._capturaTypeFilter || 'all';
  const filtered = POKEMONS.filter(p => {
    const matchSearch = !q || p.name.toLowerCase().includes(q);
    const matchTag = tagFilter === 'all' ? true
      : tagFilter === 'dive' ? !!p.dive
      : tagFilter === 'none' ? !p.tag
      : p.tag === tagFilter;
    const pokeType = getTypeFromBanner(p.bannerImage);
    const matchType = typeFilter === 'all' ? true : pokeType === typeFilter;
    return matchSearch && matchTag && matchType;
  });
  document.getElementById('captura-count-label').textContent = filtered.length + (filtered.length === 1 ? ' pokémon' : ' pokémons');
  if (!filtered.length) {
    grid.innerHTML = '<div class="no-results">Nenhum Pokémon encontrado.</div>';
    return;
  }

  // ── Modo Lista ─────────────────────────────────────────────────────────────
  // Thumbnail estática pequena ao lado do nome.
  // Clique na linha abre o modal (com GIF animado) — igual ao comportamento anterior.
  // Muito mais leve: zero GIFs simultâneos rodando na tela.
  grid.innerHTML = '<div class="captura-list">' + filtered.map((poke) => {
    const idx = poke._idx;
    const pokeType = getTypeFromBanner(poke.bannerImage);
    const typeColor = pokeType && TYPE_COLORS[pokeType] ? TYPE_COLORS[pokeType] : 'var(--accent)';
    const typeClass = pokeType ? ` type-${pokeType}` : '';

    // Thumbnail: sempre usa sprite estático (PNG) — sem GIF na lista
    const thumbSrc = getShowdownStaticSprite(poke.name);
    const fallbackSrc = poke.image && !/\.gif$/i.test(poke.image) ? poke.image : '';

    const diveMultiplier = poke.dive ? 1.30 : 1.0;
    const effectivePrice = poke.price ? Math.round(poke.price * diveMultiplier) : poke.price;
    const priceData = formatKK(effectivePrice);
    const priceHtml = priceData
      ? `<span class="captura-list-price-kk" style="color:${typeColor}">${priceData.label}</span>
         <span class="captura-list-price-brl">${priceData.brl}</span>`
      : `<span class="price-none">sem preço</span>`;

    const tagsHtml = [
      poke.tag ? getCapturaTagHtml(poke.tag) : '',
      poke.dive ? getCapturaTagHtml('dive') : '',
    ].join('');

    // Banner de tipo (ícone pequeno)
    const typeIconHtml = poke.bannerImage
      ? `<img class="captura-list-type-icon" src="${poke.bannerImage}" alt="" loading="lazy" onerror="this.style.display='none'" />`
      : '';

    const brokeInfo = getBrokeForTag(poke.tag);
    const brokeHtml = brokeInfo
      ? `<div class="captura-list-broke"><span class="broke-icon">💥</span><span class="broke-label">Max Broke</span><span class="broke-val">${brokeInfo.label}</span></div>`
      : '';

    return `<div class="captura-list-row" style="--type-color:${typeColor}" onclick="openCapturaModal(${idx})">
      <img class="captura-list-thumb"
           src="${thumbSrc}"
           ${fallbackSrc ? `onerror="this.src='${fallbackSrc}'"` : `onerror="this.style.opacity='0'"`}
           alt="${poke.name}"
           loading="lazy" />
      <div class="captura-list-info">
        <span class="captura-list-name">${poke.name}</span>
        <div class="captura-list-tags">${tagsHtml}${typeIconHtml}</div>
        ${brokeHtml}
      </div>
      <div class="captura-list-price">${priceHtml}</div>
      <button class="captura-list-catch-btn" onclick="event.stopPropagation();openCapturaModal(${idx})">⬟</button>
    </div>`;
  }).join('') + '</div>';
}

function openCapturaModal(idx) {
  currentCapturaIdx = idx;
  selectedBall = null;
  const poke = POKEMONS[idx];
  const diveMultiplier = poke.dive ? 1.30 : 1.0;
  const effectiveBasePrice = poke.price ? Math.round(poke.price * diveMultiplier) : poke.price;
  const priceData = formatKK(effectiveBasePrice);
  document.getElementById('captura-modal-title').textContent = poke.name;
  const body = document.getElementById('captura-modal-body');
  body.innerHTML = `
    <div class="captura-modal-img-wrap">
      <img class="captura-modal-pokemon-img" src="${poke.image}" alt="${poke.name}" onerror="this.style.display='none'" />
    </div>
    <div class="captura-modal-info">
      <div class="captura-modal-poke-name">${poke.name}</div>
      <div style="margin-top:6px;display:flex;justify-content:center;gap:6px;flex-wrap:wrap">
        ${poke.tag ? getCapturaTagHtml(poke.tag) : ''}
        ${poke.dive ? getCapturaTagHtml('dive') : ''}
      </div>
      ${poke.dive ? `<div style="margin-top:6px;font-family:var(--font-body);font-size:11px;color:#00e5ff;opacity:0.8;letter-spacing:1px;text-align:center"><img src="https://i.imgur.com/zpRe43i.png" style="height:12px;vertical-align:middle;margin-right:4px;"> Pokémon em Dive — +30% aplicado</div>` : ''}
      ${priceData ? `
      <div class="captura-modal-price-block">
        <span class="captura-modal-price-kk">${priceData.label}</span>
        <span class="captura-modal-price-sep">·</span>
        <span class="captura-modal-price-brl">${priceData.brl}</span>
      </div>` : ''}
    </div>
    <div class="captura-ball-section">
      <div class="captura-ball-label">Escolha a Poké Ball</div>
      <div class="captura-ball-options">
        ${BALLS.map(ball => {
          const rawBallPrice = effectiveBasePrice ? Math.round(effectiveBasePrice * ball.mult) : 0;
          const ballPrice = (ball.minPrice && rawBallPrice > 0) ? Math.max(rawBallPrice, ball.minPrice) : rawBallPrice;
          const ballPriceData = formatKK(ballPrice);
          const multLabel = '';
          return `
          <button class="captura-ball-btn" data-ball="${ball.id}" onclick="selectBall('${ball.id}')">
            <span class="captura-ball-check" style="color:${ball.color}">✓</span>
            <span class="captura-ball-icon">${ball.emoji}</span>
            <span class="captura-ball-name">${ball.name}</span>
            ${multLabel}
            ${ballPriceData ? `<span class="ball-price-kk" style="color:${ball.color}">${ballPriceData.label}</span>
            <span class="ball-price-brl">${ballPriceData.brl}</span>` : ''}
          </button>`;
        }).join('')}
      </div>
    </div>
    <div id="captura-ball-aviso" style="
      margin: 10px 0 6px;
      background: linear-gradient(135deg, rgba(255,180,0,0.10) 0%, rgba(255,100,0,0.08) 100%);
      border: 1.5px solid rgba(255,180,0,0.40);
      border-left: 4px solid #ffb300;
      border-radius: 10px;
      padding: 12px 14px;
      display: none;
      align-items: flex-start;
      gap: 10px;
      box-shadow: 0 0 18px rgba(255,160,0,0.12), inset 0 1px 0 rgba(255,200,80,0.08);
    ">
      <span style="font-size:20px;line-height:1;flex-shrink:0;margin-top:1px;">⚠️</span>
      <div style="display:flex;flex-direction:column;gap:5px;">
        <span style="
          font-family:var(--font-title,inherit);
          font-size:13px;
          font-weight:700;
          color:#ffcc44;
          letter-spacing:0.6px;
          text-transform:uppercase;
          text-shadow:0 0 10px rgba(255,180,0,0.5);
        ">As Poké Balls são por sua conta!</span>
        <span style="
          font-size:11.5px;
          color:rgba(255,255,255,0.72);
          line-height:1.55;
          font-family:var(--font-body,inherit);
        ">
          Premier Ball e Alliance Ball exigem <span style="
            background:rgba(255,180,0,0.18);
            border:1px solid rgba(255,180,0,0.45);
            border-radius:5px;
            padding:1px 6px;
            color:#ffcc44;
            font-weight:700;
            font-size:11px;
          ">mínimo 1k por captura</span>.
          Se acabar as balls, você precisa repor para continuar capturando.
        </span>
      </div>
    </div>
    ${(function() {
      const pokeType = getTypeFromBanner(poke.bannerImage);
      const typeColor = pokeType && TYPE_COLORS[pokeType] ? TYPE_COLORS[pokeType] : '#ffd166';
      return buildDropsHtml(poke.name, typeColor);
    })()}
    <div class="captura-modal-price-selected" id="captura-price-selected" style="display:none">
      <span class="captura-price-sel-label">Total com ball selecionada</span>
      <div class="captura-price-sel-vals">
        <span class="captura-price-sel-kk" id="captura-price-sel-kk">—</span>
        <span class="captura-price-sel-brl" id="captura-price-sel-brl">—</span>
      </div>
    </div>
    <div class="captura-success-msg" id="captura-success-msg">
      <span>🎉</span>
      <span id="captura-success-text">Captura confirmada!</span>
    </div>
    <button class="captura-confirm-btn" id="captura-confirm-btn" onclick="confirmCaptura()" disabled>
      <span>⬟ Confirmar Captura</span>
    </button>
  `;
  document.getElementById('captura-overlay').classList.add('open');
}

function selectBall(ballId) {
  selectedBall = ballId;
  document.querySelectorAll('.captura-ball-btn').forEach(b => {
    b.classList.toggle('selected', b.dataset.ball === ballId);
  });
  const confirmBtn = document.getElementById('captura-confirm-btn');
  if (confirmBtn) confirmBtn.disabled = false;
  const msg = document.getElementById('captura-success-msg');
  if (msg) msg.classList.remove('show');
  const aviso = document.getElementById('captura-ball-aviso');
  if (aviso) aviso.style.display = (ballId === 'premier' || ballId === 'alliance') ? 'flex' : 'none';

  // Atualiza bloco de preço final
  if (currentCapturaIdx !== null) {
    const poke = POKEMONS[currentCapturaIdx];
    const ball = BALLS.find(b => b.id === ballId);
    const finalPrice = _calcCapturaFinalPrice(poke, ball);
    const priceData = formatKK(finalPrice);
    const selBlock = document.getElementById('captura-price-selected');
    const selKk    = document.getElementById('captura-price-sel-kk');
    const selBrl   = document.getElementById('captura-price-sel-brl');
    if (selBlock && priceData) {
      selKk.textContent  = priceData.label;
      selBrl.textContent = priceData.brl;
      selBlock.style.display = 'flex';
    }
  }
}

function confirmCaptura() {
  if (!selectedBall || currentCapturaIdx === null) return;
  const poke = POKEMONS[currentCapturaIdx];
  const ball = BALLS.find(b => b.id === selectedBall);
  const finalPrice = _calcCapturaFinalPrice(poke, ball);
  const priceData  = formatKK(finalPrice);
  const priceStr   = priceData ? ` · ${priceData.label} (${priceData.brl})` : '';

  // ── Adiciona ao carrinho ──
  // Monta um nome descritivo: "Shiny Charizard (Alliance Ball)"
  const cartItemName = `${poke.name} (${ball.name})`;
  // Verifica se já existe um item idêntico no array items
  let cartKey = items.findIndex(it => it._capturaId === `${currentCapturaIdx}_${selectedBall}`);
  if (cartKey === -1) {
    // Cria novo item dinâmico no array items
    items.push({
      name: cartItemName,
      price: finalPrice,
      image: poke.image,
      _capturaId: `${currentCapturaIdx}_${selectedBall}`,
      _ballEmoji: ball.emoji,
      _ballName: ball.name,
    });
    cartKey = items.length - 1;
  }
  cart[cartKey] = (cart[cartKey] || 0) + 1;
  updateCartBadge();
  if (!finalPrice) showNoPriceToast(cartItemName);

  const msg = document.getElementById('captura-success-msg');
  const btn = document.getElementById('captura-confirm-btn');
  if (msg) {
    msg.querySelector('#captura-success-text').textContent = `${poke.name} capturado com ${ball.name}${priceStr}!`;
    msg.classList.add('show');
  }
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<span>✓ Captura Registrada</span>`;
    btn.style.borderColor = 'rgba(37,211,102,0.5)';
    btn.style.color = '#25d366';
  }
  setTimeout(() => closeCapturaModal(), 2600);
}

function closeCapturaModal() {
  document.getElementById('captura-overlay').classList.remove('open');
  currentCapturaIdx = null;
  selectedBall = null;
}

function handleCapturaOverlayClick(e) {
  if (e.target === document.getElementById('captura-overlay')) closeCapturaModal();
}

render();


// ── GIF Hover Manager ────────────────────────────────────────────────────────
// Padrão: PNG estático (leve, zero GPU).
// Hover: troca pelo GIF animado do Showdown. Mouseleave: volta ao PNG.
(function GifHoverManager() {
  'use strict';

  function bindCard(card) {
    if (card._gifBound) return;
    card._gifBound = true;

    var img = card.querySelector('img[data-gif]');
    if (!img) return;

    card.addEventListener('mouseenter', function() {
      img.src = img.dataset.gif;
    });
    card.addEventListener('mouseleave', function() {
      img.src = getShowdownStaticSprite(img.alt);
    });
  }

  function bindAll() {
    document.querySelectorAll('.card, .captura-card').forEach(bindCard);
  }

  bindAll();

  var mo = new MutationObserver(bindAll);
  var gridEl = document.getElementById('grid');
  var capturaGridEl = document.getElementById('captura-grid');
  if (gridEl)        mo.observe(gridEl,        { childList: true });
  if (capturaGridEl) mo.observe(capturaGridEl, { childList: true });
})();

// ── Performance: pausa animações de cards fora da viewport ──────────────────
// Cards fora da tela recebem `will-change: auto` e param de consumir GPU.
// Assim só os cards visíveis ficam "ativos".
(function setupCardVisibilityObserver() {
  if (!window.IntersectionObserver) return;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      const img = entry.target.querySelector('img');
      if (img) {
        // Fora da tela: remove promoção de layer e animações
        img.style.willChange = 'auto'; // GIFs: will-change:transform não afeta animação nativa
      }
      // Para as pseudo-animações CSS dos cards fora da tela
      entry.target.style.willChange = entry.isIntersecting ? 'transform, box-shadow' : 'auto';
      // Controla partículas de tipo via classe CSS (pausa quando fora da tela)
      entry.target.classList.toggle('in-view', entry.isIntersecting);
    });
  }, { rootMargin: '120px 0px' }); // 120px de margem = pré-carrega um pouco antes

  // Observa cards iniciais e re-observa a cada render
  function observeCards() {
    document.querySelectorAll('.card, .captura-card').forEach(c => observer.observe(c));
  }

  // Intercepta render para re-observar após cada atualização
  const _origRender = render;
  window.render = function() {
    _origRender.apply(this, arguments);
    requestAnimationFrame(observeCards);
  };
  requestAnimationFrame(observeCards);
})();

// ===================== ENTREGAS =====================
// ============================================================
//  ▼▼▼  ADICIONE SUAS FOTOS AQUI  ▼▼▼
//
//  Coloque as imagens em uma pasta chamada  "entregas"
//  na mesma pasta do index.html, depois adicione cada
//  foto no array abaixo seguindo o modelo:
//
//  { src: "entregas/nome-do-arquivo.jpg",
//    name: "Descrição da entrega",
//    date: "DD/MM/AAAA" },
//
//  Também aceita caminhos absolutos do Windows, ex:
//  { src: "file:///C:/Users/Filipi/fotos/entrega1.jpg", ... }
// ============================================================
const ENTREGAS = [
{ src: "https://i.imgur.com/tU7Djq7.jpeg",  name: "Itens de Talentos — Recall Stark",     date: "16/04/2026" },
{ src: "https://i.imgur.com/nJyeTHn.jpeg",  name: "Shiny Charizard — Gambitt",   date: "21/04/2026" },
{ src: "https://i.imgur.com/5ilqaVR.jpeg",  name: "Itens de Talentos — Saga",        date: "21/04/2026" },
{ src: "https://i.imgur.com/Tu97b05.jpeg",  name: "Itens de Talentos — Jonaspedreiro",        date: "23/04/2026" },
{ src: "https://i.imgur.com/5BbSBo4.png",  name: "Itens de Talentos — K A M I",        date: "26/04/2026" },
{ src: "https://i.imgur.com/EQopeNt.png",  name: "Itens de Talentos / Shiny Heracross — Bihi",        date: "26/04/2026" },
{ src: "https://i.imgur.com/H0KsS8J.png",  name: "Shiny Tentacruel — Qzarny",        date: "27/04/2026" },
{ src: "https://i.imgur.com/UrD74CU.png",  name: "Itens de Talentos — Bllaack",        date: "01/05/2026" },
{ src: "https://i.imgur.com/6UPPwCx.png",  name: "Shiny Starmie — Bllaack",        date: "01/05/2026" },
{ src: "https://i.imgur.com/NhV6uXy.jpeg",  name: "Shiny Tentacruel — Qzarny",        date: "03/05/2026" },
{ src: "https://i.imgur.com/QnneBym.jpeg",  name: "Shiny Qwilfish — Akahitaka",        date: "03/05/2026" },
{ src: "https://i.imgur.com/SwibeCC.jpeg",  name: "Shiny Qwilfish — Akahitaka",        date: "03/05/2026" },
{ src: "https://i.imgur.com/0mAPijC.png",  name: "Shiny Crobat - Itens de Talento — Zripper",        date: "04/05/2026" },
{ src: "https://i.imgur.com/tCKCggp.png",  name: "Shiny Persian — Bihi, quem pegou foi o amigo",        date: "04/05/2026" },
{ src: "https://i.imgur.com/8c7IkrQ.png",  name: "Itens de talento — Saga",        date: "05/05/2026" },
{ src: "https://i.imgur.com/tCKCggp.png",  name: "Shiny Qwilfish — Saga",        date: "05/05/2026" },
{ src: "https://i.imgur.com/tCKCggp.png",  name: "Shiny Qwilfish — Saga, ultimo de uma encomenda de 4 shinys",        date: "05/05/2026" },
];
// ============================================================

let _lightboxIdx = 0;

function renderEntregas() {
  const grid = document.getElementById('entregas-grid');
  const countLabel = document.getElementById('entregas-count-label');
  if (!grid) return;

  const n = ENTREGAS.length;
  if (countLabel) countLabel.textContent = n + (n === 1 ? ' entrega' : ' entregas');

  if (!n) {
    grid.innerHTML = `<div class="entregas-empty">
      <div class="entregas-empty-icon">📷</div>
      <div class="entregas-empty-text">Nenhuma entrega ainda</div>
      <div class="entregas-empty-sub">Adicione as fotos no array ENTREGAS[] dentro do script</div>
    </div>`;
    return;
  }

  // Parse date DD/MM/YYYY → sortable number YYYYMMDD
  function parseDateVal(d) {
    if (!d) return 0;
    const parts = d.split('/');
    if (parts.length !== 3) return 0;
    return parseInt(parts[2] + parts[1] + parts[0], 10);
  }

  // Format date for display: DD/MM/YYYY → "DD de Mês de YYYY"
  const MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  function formatDateLabel(d) {
    if (!d) return d;
    const parts = d.split('/');
    if (parts.length !== 3) return d;
    const mes = MESES[parseInt(parts[1], 10) - 1] || parts[1];
    return `${parseInt(parts[0], 10)} de ${mes} de ${parts[2]}`;
  }

  // Group by date, most recent first
  const groups = {};
  const groupOrder = [];
  ENTREGAS.forEach((item, idx) => {
    const key = item.date || 'Sem data';
    if (!groups[key]) {
      groups[key] = [];
      groupOrder.push(key);
    }
    groups[key].push({ item, idx });
  });

  // Sort groups: most recent first
  groupOrder.sort((a, b) => parseDateVal(b) - parseDateVal(a));

  let html = '';
  groupOrder.forEach(dateKey => {
    const entries = groups[dateKey];
    html += `
    <div class="entregas-date-group">
      <div class="entregas-date-header">
        <div class="entregas-date-line"></div>
        <div class="entregas-date-pill">
          <span class="entregas-date-icon">📅</span>
          <span class="entregas-date-text">${formatDateLabel(dateKey)}</span>
          <span class="entregas-date-count">${entries.length} ${entries.length === 1 ? 'entrega' : 'entregas'}</span>
        </div>
        <div class="entregas-date-line"></div>
      </div>
      <div class="entregas-date-grid">
        ${entries.map(({ item, idx }) => `
        <div class="entrega-card" onclick="openEntregaLightbox(${idx})">
          <img src="${item.src}" alt="${item.name}" loading="lazy"
               onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" />
          <div style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-size:40px;background:var(--surface3)">📦</div>
          <div class="entrega-card-overlay">
            <div>
              <div class="entrega-card-label">${item.name}</div>
              <div class="entrega-card-date">${item.date}</div>
            </div>
          </div>
          <div class="entrega-card-badge">✓ Entregue</div>
        </div>`).join('')}
      </div>
    </div>`;
  });

  grid.innerHTML = html;
}

function openEntregaLightbox(idx) {
  _lightboxIdx = idx;
  document.getElementById('entrega-lightbox').classList.add('open');
  _updateLightboxContent();
}

function _updateLightboxContent() {
  const item = ENTREGAS[_lightboxIdx];
  if (!item) return;
  document.getElementById('entrega-lightbox-img').src = item.src;
  document.getElementById('entrega-lightbox-caption').textContent =
    item.name + ' · ' + item.date + '  (' + (_lightboxIdx + 1) + '/' + ENTREGAS.length + ')';
}

function navEntregaLightbox(dir) {
  _lightboxIdx = (_lightboxIdx + dir + ENTREGAS.length) % ENTREGAS.length;
  _updateLightboxContent();
}

function closeEntregaLightbox(e) {
  if (e && e.type === 'click') {
    const inner = document.querySelector('.entrega-lightbox-inner');
    if (inner && inner.contains(e.target) && !e.target.classList.contains('entrega-lightbox-close')) return;
  }
  document.getElementById('entrega-lightbox').classList.remove('open');
}

document.addEventListener('keydown', e => {
  const lb = document.getElementById('entrega-lightbox');
  if (!lb || !lb.classList.contains('open')) return;
  if (e.key === 'ArrowLeft')  navEntregaLightbox(-1);
  if (e.key === 'ArrowRight') navEntregaLightbox(1);
  if (e.key === 'Escape')     lb.classList.remove('open');
});

// Substituto seguro (adicione no final de app.js, após DOMContentLoaded):
document.addEventListener('DOMContentLoaded', function () {
  if (window.NavRuntime) {
    NavRuntime.onTabSwitch('after', 'app-entregas', function (tab) {
      if (tab === 'entregas' && typeof renderEntregas === 'function') renderEntregas();
    });
  }
});

// Sticky offset — mede header e tabs e expõe como variáveis CSS
function updateStickyOffsets() {
  const header = document.querySelector('header');
  const tabsNav = document.querySelector('.tabs-nav');
  const hh = header ? header.getBoundingClientRect().height : 0;
  const th = tabsNav ? tabsNav.getBoundingClientRect().height : 0;
  document.documentElement.style.setProperty('--header-h', hh + 'px');
  document.documentElement.style.setProperty('--tabs-h', th + 'px');
}
updateStickyOffsets();
window.addEventListener('resize', updateStickyOffsets);

// ===================== TYPE DROPDOWN =====================
window._capturaTypeFilter = 'all';

function toggleTypeDropdown(e) {
  e.stopPropagation();
  const dd = document.getElementById('type-dropdown');
  dd.classList.toggle('open');
}

function selectTypeFilter(type, btn) {
  window._capturaTypeFilter = type;

  // Update active state on items
  document.querySelectorAll('.type-dropdown-item').forEach(el => el.classList.remove('active'));
  btn.classList.add('active');

  // Update button display
  const icon = document.getElementById('type-dropdown-icon');
  const label = document.getElementById('type-dropdown-label');
  if (type === 'all') {
    icon.innerHTML = '<span class="type-dropdown-all-dot"></span>';
    label.textContent = 'Tipo';
  } else {
    const img = btn.querySelector('img');
    const name = btn.querySelector('span:last-child').textContent;
    icon.innerHTML = `<img src="${img.src}" alt="${type}">`;
    label.textContent = name;
  }

  // Close dropdown
  document.getElementById('type-dropdown').classList.remove('open');

  // Re-render
  renderCaptura();
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
  const dd = document.getElementById('type-dropdown');
  if (dd && !dd.contains(e.target)) dd.classList.remove('open');
});

// ===================== POKEMON DROP MAP =====================
// Constrói mapa reverso: pokémonName (lowercase) → [{ name, price }]
const _pokeDropMap = (function() {
  const map = {};
  const priceMap = {};
  RAW.forEach(function(entry) {
    const name = entry[0];
    const price = entry[2] || 0;
    if (name) priceMap[name.toLowerCase()] = price;
  });
  RAW_WIKI.forEach(function(entry) {
    const itemName = entry[0];
    const price = priceMap[itemName.toLowerCase()] || 0;
    for (let i = 1; i < entry.length; i++) {
      const poke = entry[i];
      if (!poke || !poke.trim()) continue;
      const key = poke.trim().toLowerCase();
      if (!map[key]) map[key] = [];
      map[key].push({ name: itemName, price: price });
    }
  });
  return map;
})();

function getPokeDrops(pokeName) {
  const key = pokeName.trim().toLowerCase();
  const keyNoShiny = key.replace(/^shiny\s+/, '');
  return _pokeDropMap[key] || _pokeDropMap[keyNoShiny] || [];
}

function buildDropsHtml(pokeName, typeColor) {
  const drops = getPokeDrops(pokeName);
  if (!drops.length) return '';
  const color = typeColor || '#ffd166';
  const colorDim = color + '22';
  const colorBorder = color + '40';
  const chips = drops.map(function(drop) {
    const priceLabel = drop.price ? formatKK(drop.price) : null;
    const priceHtml = priceLabel
      ? '<span style="font-size:10px;color:rgba(255,255,255,0.38);margin-left:4px">' + priceLabel.label + '</span>'
      : '';
    return '<div style="background:' + colorDim + ';border:1px solid ' + colorBorder + ';border-radius:7px;padding:4px 9px;display:inline-flex;align-items:center;gap:3px">'
      + '<span style="font-size:11px;color:' + color + ';font-weight:600;font-family:var(--font-display,inherit)">' + drop.name + '</span>'
      + priceHtml
      + '</div>';
  }).join('');
  return '<div style="margin-top:12px;border-top:1px solid rgba(255,255,255,0.07);padding-top:11px">'
    + '<div style="font-size:10px;letter-spacing:1.5px;color:rgba(255,255,255,0.35);text-align:center;margin-bottom:8px;font-weight:600;font-family:var(--font-display,inherit)">ITENS DROPADOS</div>'
    + '<div style="display:flex;flex-wrap:wrap;gap:5px;justify-content:center">' + chips + '</div>'
    + '</div>';
}

// ===================== WIKI LOOKUP POPUP =====================
// Substituído pelo item-card-popup.js — função redefinida lá
function openWikiLookup(itemName, e) { /* substituído por item-card-popup.js */ }
function closeWikiPopup() {}
// ===================== CAPTURA LIST MODE CSS =====================
(function injectCapturaListStyles() {
  const style = document.createElement('style');
  style.textContent = `
    /* Garante que o container do grid vire bloco ao exibir a lista */
    #captura-grid:has(.captura-list) {
      display: block !important;
      grid-template-columns: unset !important;
    }
    .captura-list {
      display: flex;
      flex-direction: column;
      gap: 4px;
      padding: 4px 0;
      width: 100%;
      box-sizing: border-box;
      grid-column: 1 / -1;
    }
    /* Neutraliza qualquer classe de tipo global que pinte o fundo */
    .captura-list-row[class],
    .captura-list-row {
      display: flex !important;
      align-items: center !important;
      gap: 12px !important;
      padding: 10px 14px !important;
      background: rgba(255,255,255,0.04) !important;
      border: 1px solid rgba(255,255,255,0.07) !important;
      border-left: 3px solid var(--type-color, #60aaff) !important;
      border-radius: 10px !important;
      cursor: pointer !important;
      transition: background 0.15s, border-color 0.15s, transform 0.12s !important;
      position: relative !important;
      overflow: hidden !important;
      color: #ffffff !important;
      box-shadow: none !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    /* Glow sutil no fundo vindo da esquerda com a cor do tipo */
    .captura-list-row::after {
      content: '';
      position: absolute;
      left: 0; top: 0; bottom: 0;
      width: 120px;
      background: linear-gradient(90deg, color-mix(in srgb, var(--type-color, #60aaff) 12%, transparent), transparent);
      pointer-events: none;
    }
    .captura-list-row:hover {
      background: rgba(255,255,255,0.07) !important;
      border-left-color: var(--type-color, #60aaff) !important;
      border-color: color-mix(in srgb, var(--type-color, #60aaff) 40%, rgba(255,255,255,0.1)) !important;
      transform: translateX(3px) !important;
      box-shadow: 0 2px 16px color-mix(in srgb, var(--type-color, #60aaff) 15%, transparent) !important;
    }
    .captura-list-row:active {
      transform: translateX(1px) scale(0.995) !important;
    }
    .captura-list-thumb {
      width: 48px !important;
      height: 48px !important;
      object-fit: contain !important;
      flex-shrink: 0 !important;
      image-rendering: pixelated !important;
      filter: drop-shadow(0 2px 8px rgba(0,0,0,0.6)) !important;
      z-index: 1;
    }
    .captura-list-info {
      flex: 1 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      gap: 4px !important;
      z-index: 1;
    }
    .captura-list-name {
      font-family: var(--font-display, inherit) !important;
      font-size: 14px !important;
      font-weight: 700 !important;
      color: #ffffff !important;
      white-space: nowrap !important;
      overflow: hidden !important;
      text-overflow: ellipsis !important;
      letter-spacing: 0.4px !important;
      text-shadow: 0 1px 4px rgba(0,0,0,0.8) !important;
    }
    .captura-list-tags {
      display: flex !important;
      align-items: center !important;
      gap: 5px !important;
      flex-wrap: wrap !important;
    }
    .captura-list-type-icon {
      width: 16px !important;
      height: 16px !important;
      object-fit: contain !important;
      opacity: 0.85 !important;
      vertical-align: middle !important;
    }
    .captura-list-price {
      display: flex !important;
      flex-direction: column !important;
      align-items: flex-end !important;
      gap: 2px !important;
      flex-shrink: 0 !important;
      z-index: 1;
    }
    .captura-list-price-kk {
      font-family: var(--font-mono, monospace) !important;
      font-size: 13px !important;
      font-weight: 700 !important;
      letter-spacing: 0.5px !important;
    }
    .captura-list-price-brl {
      font-family: var(--font-body, inherit) !important;
      font-size: 10px !important;
      color: rgba(255,255,255,0.45) !important;
    }
    .captura-list-catch-btn {
      flex-shrink: 0 !important;
      background: color-mix(in srgb, var(--type-color, #60aaff) 15%, transparent) !important;
      border: 1px solid color-mix(in srgb, var(--type-color, #60aaff) 60%, transparent) !important;
      color: var(--type-color, #60aaff) !important;
      border-radius: 8px !important;
      width: 34px !important;
      height: 34px !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      font-size: 15px !important;
      cursor: pointer !important;
      transition: background 0.15s, box-shadow 0.15s !important;
      z-index: 1;
    }
    .captura-list-catch-btn:hover {
      background: var(--type-color, #60aaff) !important;
      color: #000 !important;
      box-shadow: 0 0 12px color-mix(in srgb, var(--type-color, #60aaff) 70%, transparent) !important;
    }
    @media (max-width: 480px) {
      .captura-list-thumb { width: 38px !important; height: 38px !important; }
      .captura-list-name  { font-size: 13px !important; }
      .captura-list-price-kk { font-size: 12px !important; }
    }
  `;
  document.head.appendChild(style);
})();
// ============================================================
// NPC's → Rockets
// Estrutura: { name, wins, pokemons: [{ name, reward }] }
// reward = nome do Pokémon shiny recompensa (buscado em POKEMONS para tag)
// ============================================================

const RAW_ROCKETS = [
  // SHADOW
  { name: 'Shadow', wins: null, pokemons: [
    { name: 'Feraligatr',       reward: 'sh Raichu'    },
    { name: 'Shiny Gengar',     reward: 'sh Sandslash' },
    { name: 'Alakazam',         reward: 'Scizor'       },
    { name: 'Shiny Crobat',     reward: 'sh Golem'     },
    { name: 'Muk',              reward: 'sh Marowak'   },
    { name: 'Houndoom',         reward: 'sh Starmie'   },
  ]},
  // FROST
  { name: 'Frost', wins: null, pokemons: [
    { name: 'Misdreavus',       reward: 'sh Persian'   },
    { name: 'Magcargo',         reward: 'sh Starmie'   },
    { name: 'Hypno',            reward: 'Scizor'       },
    { name: 'Gligar',           reward: 'sh Jynx'      },
    { name: 'Houndour',         reward: 'sh Hitmontop' },
    { name: 'Murkrow',          reward: 'sh Golem'     },
  ]},
  // THORN
  { name: 'Thorn', wins: null, pokemons: [
    { name: 'Shiny Arbok',      reward: 'sh Sandslash' },
    { name: 'Shiny Golbat',     reward: 'sh Golem'     },
    { name: 'Shiny Hypno',      reward: 'Scizor'       },
    { name: 'Shiny Haunter',    reward: 'sh Persian'   },
    { name: 'Shiny Murkrow',    reward: 'sh Jynx'      },
    { name: 'Houndoom',         reward: 'sh Starmie'   },
  ]},
  // CIPHER
  { name: 'Cipher', wins: null, pokemons: [
    { name: 'Feraligatr',       reward: 'sh Raichu'    },
    { name: 'Shiny Persian',    reward: 'sh Hitmontop' },
    { name: 'Venusaur',         reward: 'sh Pidgeot'   },
    { name: 'Electabuzz',       reward: 'sh Sandslash' },
    { name: 'Typhlosion',       reward: 'sh Starmie'   },
    { name: 'Meganium',         reward: 'sh Arcanine'  },
  ]},
  // PHOENIX
  { name: 'Phoenix', wins: null, pokemons: [
    { name: 'Charizard',        reward: 'sh Golem'     },
    { name: 'Shiny Blastoise',  reward: 'sh Venusaur'  },
    { name: 'Venusaur',         reward: 'sh Pidgeot'   },
    { name: 'Shiny Electrode',  reward: 'sh Sandslash' },
    { name: 'Shiny Magneton',   reward: 'sh Arcanine'  },
    { name: 'Blastoise',        reward: 'sh Raichu'    },
  ]},
  // SCYTHE
  { name: 'Scythe', wins: null, pokemons: [
    { name: 'Scyther',          reward: 'sh Arcanine'  },
    { name: 'Shiny Ampharos',   reward: 'sh Golem'     },
    { name: 'Shiny Raichu',     reward: 'sh Sandslash' },
    { name: 'Nidoqueen',        reward: 'sh Jynx'      },
    { name: 'Arcanine',         reward: 'sh Starmie'   },
    { name: 'Shiny Houndoom',   reward: 'sh Hitmontop' },
  ]},
  // MIRAGE
  { name: 'Mirage', wins: null, pokemons: [
    { name: 'Charizard',        reward: 'sh Golem'     },
    { name: 'Shiny Charizard',  reward: 'sh Starmie'   },
    { name: 'Venusaur',         reward: 'sh Pidgeot'   },
    { name: 'Shiny Venusaur',   reward: 'sh Arcanine'  },
    { name: 'Blastoise',        reward: 'sh Venusaur'  },
    { name: 'Shiny Blastoise',  reward: 'sh Raichu'    },
  ]},
  // ZEPHYR
  { name: 'Zephyr', wins: null, pokemons: [
    { name: 'Typhlosion',       reward: 'sh Golem'     },
    { name: 'Shiny Typhlosion', reward: 'sh Starmie'   },
    { name: 'Meganium',         reward: 'sh Pidgeot'   },
    { name: 'Shiny Meganium',   reward: 'sh Arcanine'  },
    { name: 'Feraligatr',       reward: 'sh Venusaur'  },
    { name: 'Shiny Feraligatr', reward: 'sh Raichu'    },
  ]},
  // OBSIDIAN
  { name: 'Obsidian', wins: null, pokemons: [
    { name: 'Shiny Gyarados',   reward: 'sh Raichu'    },
    { name: 'Shiny Persian',    reward: 'sh Hitmontop' },
    { name: 'Shiny Machamp',    reward: 'sh Pidgeot'   },
    { name: 'Shiny Kingdra',    reward: 'sh Clefable'  },
    { name: 'Shiny Pidgeot',    reward: 'sh Golem'     },
    { name: 'Shiny Scizor',     reward: 'sh Arcanine'  },
  ]},
  // VORTEX
  { name: 'Vortex', wins: null, pokemons: [
    { name: 'Shiny Ninetales',  reward: 'sh Starmie'   },
    { name: 'Shiny Magneton',   reward: 'sh Arcanine'  },
    { name: 'Shiny Kabutops',   reward: 'sh Venusaur'  },
    { name: 'Shiny Omastar',    reward: 'sh Raichu'    },
    { name: 'Shiny Pidgeot',    reward: 'sh Golem'     },
    { name: 'Shiny Ampharos',   reward: 'sh Sandslash' },
  ]},
  // TEMPEST
  { name: 'Tempest', wins: null, pokemons: [
    { name: 'Shiny Magmar',     reward: 'sh Starmie'   },
    { name: 'Shiny Snorlax',    reward: 'sh Hitmontop' },
    { name: 'Shiny Mime',       reward: 'Scizor'       },
    { name: 'Shiny Pupitar',    reward: 'sh Venusaur'  },
    { name: 'Shiny Umbreon',    reward: 'sh Clefable'  },
    { name: 'Shiny Misdreavus', reward: 'sh Persian'   },
  ]},
  // ECLIPSE
  { name: 'Eclipse', wins: null, pokemons: [
    { name: 'Shiny Dragonair',  reward: 'sh Clefable'  },
    { name: 'Shiny Arcanine',   reward: 'sh Starmie'   },
    { name: 'Shiny Espeon',     reward: 'sh Persian'   },
    { name: 'Shiny Pinsir',     reward: 'sh Pidgeot'   },
    { name: 'Shiny Tauros',     reward: 'sh Hitmontop' },
    { name: 'Shiny Skarmory',   reward: 'sh Arcanine'  },
  ]},
  // GIOVANNI (especial)
  { name: 'Giovanni', wins: 130, pokemons: [
    { name: 'Shiny Nidoqueen',  reward: 'sh Sandslash' },
    { name: 'Shiny Persian',    reward: 'Machamp'      },
    { name: 'Shiny Rhydon',     reward: 'sh Venusaur'  },
    { name: 'Shiny Nidoking',   reward: 'sh Jynx'      },
    { name: 'Shiny Kangaskhan', reward: 'sh Hitmontop' },
    { name: 'Shiny Dugtrio',    reward: 'Gyarados'     },
  ]},
];

// Helper: busca tag/tier de um Pokémon pelo nome no array POKEMONS
function getRocketRewardData(pokeName) {
  // Normaliza: "sh Raichu" → "Shiny Raichu", "sh Golem" → "Shiny Golem", etc.
  var normalized = pokeName.replace(/^sh\s+/i, 'Shiny ');
  var found = POKEMONS.find(function(p) {
    return p.name.toLowerCase() === normalized.toLowerCase();
  });
  return found || null;
}

function getShowdownSpriteRocket(name) {
  var isShiny = /^shiny\s+/i.test(name);
  var n = toShowdownName(name);
  var base = 'https://play.pokemonshowdown.com/sprites/' + (isShiny ? 'gen5-shiny/' : 'gen5/') + n + '.png';
  return base;
}

var _rocketsRendered = false;

// ── Tipos por Pokémon (Gen 1-2 relevantes para o jogo) ───────────────────────
var POKE_TYPES = {
  // Water
  'feraligatr':['water'],'shiny feraligatr':['water'],'gyarados':['water','flying'],'shiny gyarados':['water','flying'],
  'starmie':['water','psychic'],'shiny starmie':['water','psychic'],'politoad':['water'],'shiny politoad':['water'],
  'vaporeon':['water'],'shiny vaporeon':['water'],'lapras':['water','ice'],'shiny lapras':['water','ice'],
  'slowking':['water','psychic'],'shiny slowking':['water','psychic'],'mantine':['water','flying'],'shiny mantine':['water','flying'],
  'qwilfish':['water','poison'],'shiny qwilfish':['water','poison'],'kingdra':['dragon','water'],'shiny kingdra':['dragon','water'],
  'magmar':['fire'],'shiny magmar':['fire'],
  // Fire
  'charizard':['fire','flying'],'shiny charizard':['fire','flying'],'typhlosion':['fire'],'shiny typhlosion':['fire'],
  'flareon':['fire'],'shiny flareon':['fire'],'ninetales':['fire'],'shiny ninetales':['fire'],
  'rapidash':['fire'],'shiny rapidash':['fire'],'magcargo':['fire','rock'],'shiny magcargo':['fire','rock'],
  'houndoom':['dark','fire'],'houndour':['dark','fire'],
  // Grass
  'venusaur':['grass','poison'],'shiny venusaur':['grass','poison'],'meganium':['grass'],'shiny meganium':['grass'],
  'exeggutor':['grass','psychic'],'shiny exeggutor':['grass','psychic'],'victreebel':['grass','poison'],'shiny victreebel':['grass','poison'],
  'vileplume':['grass','poison'],'shiny vileplume':['grass','poison'],'tangela':['grass'],'shiny tangela':['grass'],
  'bellossom':['grass'],'shiny bellossom':['grass'],'tangrowth':['grass'],'shiny tangrowth':['grass'],
  // Electric
  'raichu':['electric'],'shiny raichu':['electric'],'ampharos':['electric'],'shiny ampharos':['electric'],
  'electrode':['electric'],'shiny electrode':['electric'],'magneton':['electric','steel'],'shiny magneton':['electric','steel'],
  'jolteon':['electric'],'shiny jolteon':['electric'],'electabuzz':['electric'],'luxray':['electric'],'shiny luxray':['electric'],
  // Psychic
  'alakazam':['psychic'],'hypno':['psychic'],'espeon':['psychic'],'shiny espeon':['psychic'],
  'xatu':['psychic','flying'],'shiny xatu':['psychic','flying'],'slowking':['water','psychic'],
  // Ghost/Dark
  'gengar':['ghost','poison'],'shiny gengar':['ghost','poison'],'misdreavus':['ghost'],'shiny misdreavus':['ghost'],
  'haunter':['ghost','poison'],'shiny haunter':['ghost','poison'],'dusknoir':['ghost'],'shiny dusknoir':['ghost'],
  'umbreon':['dark'],'shiny umbreon':['dark'],
  // Fighting
  'machamp':['fighting'],'shiny machamp':['fighting'],'hitmonchan':['fighting'],'shiny hitmonchan':['fighting'],
  'hitmonlee':['fighting'],'shiny hitmonlee':['fighting'],'hitmontop':['fighting'],'shiny hitmontop':['fighting'],
  'primeape':['fighting'],'shiny primeape':['fighting'],'heracross':['bug','fighting'],'shiny heracross':['bug','fighting'],
  'poliwrath':['water','fighting'],'shiny poliwrath':['water','fighting'],
  // Normal/Flying
  'pidgeot':['normal','flying'],'shiny pidgeot':['normal','flying'],'fearow':['normal','flying'],'shiny fearow':['normal','flying'],
  'dodrio':['normal','flying'],'shiny dodrio':['normal','flying'],'kangaskhan':['normal'],'shiny kangaskhan':['normal'],
  'snorlax':['normal'],'shiny snorlax':['normal'],'muk':['poison'],'shiny muk':['poison'],
  // Ground/Rock
  'golem':['rock','ground'],'shiny golem':['rock','ground'],'marowak':['ground'],'shiny marowak':['ground'],
  'nidoking':['poison','ground'],'shiny nidoking':['poison','ground'],'nidoqueen':['poison','ground'],'shiny nidoqueen':['poison','ground'],
  'rhydon':['ground','rock'],'shiny rhydon':['ground','rock'],'dugtrio':['ground'],'shiny dugtrio':['ground'],
  'omastar':['rock','water'],'shiny omastar':['rock','water'],'kabutops':['rock','water'],'shiny kabutops':['rock','water'],
  // Steel/Ice
  'scizor':['bug','steel'],'shiny scizor':['bug','steel'],'steelix':['steel','ground'],'shiny steelix':['steel','ground'],
  'skarmory':['steel','flying'],'shiny skarmory':['steel','flying'],'onix':['rock','ground'],'shiny onix':['rock','ground'],
  'jynx':['ice','psychic'],'shiny jynx':['ice','psychic'],'pinsir':['bug'],'shiny pinsir':['bug'],
  // Poison/Bug
  'arbok':['poison'],'shiny arbok':['poison'],'crobat':['poison','flying'],'shiny crobat':['poison','flying'],
  'ariados':['bug','poison'],'shiny ariados':['bug','poison'],'tentacruel':['water','poison'],'shiny tentacruel':['water','poison'],
  'toxicroak':['poison','fighting'],'shiny toxicroak':['poison','fighting'],
  // Dragon
  'dragonair':['dragon'],'shiny dragonair':['dragon'],
  // Others
  'tauros':['normal'],'shiny tauros':['normal'],'persian':['normal'],'shiny persian':['normal'],
  'gligar':['ground','flying'],'arcanine':['fire'],'shiny arcanine':['fire'],
  'blastoise':['water'],'shiny blastoise':['water'],'pupitar':['rock','ground'],'shiny pupitar':['rock','ground'],
  'murkrow':['dark','flying'],'shiny murkrow':['dark','flying'],'ninetales':['fire'],'shiny ninetales':['fire'],
  // Officer pokemons previously missing
  'forretress':['bug','steel'],'shiny forretress':['bug','steel'],
  'sudowoodo':['rock'],'shiny sudowoodo':['rock'],
  'sandslash':['ground'],'shiny sandslash':['ground'],
  'donphan':['ground'],'shiny donphan':['ground'],
  'scyther':['bug','flying'],'shiny scyther':['bug','flying'],
  'lanturn':['water','electric'],'shiny lanturn':['water','electric'],
  'shiny electabuzz':['electric'],
  'jumpluff':['grass','flying'],'shiny jumpluff':['grass','flying'],
  'piloswine':['ice','ground'],'shiny piloswine':['ice','ground'],
  'cloyster':['water','ice'],'shiny cloyster':['water','ice'],
  'dewgong':['water','ice'],'shiny dewgong':['water','ice'],
  'sneasel':['dark','ice'],'shiny sneasel':['dark','ice'],
  'shiny alakazam':['psychic'],
  'mr. mime':['psychic'],'shiny mr. mime':['psychic'],
  'shiny houndoom':['dark','fire'],
  'tyranitar':['rock','dark'],'shiny tyranitar':['rock','dark'],
  'weezing':['poison'],'shiny weezing':['poison'],

  // Pokémons dos Rockets faltando (adicionados para corrigir fraquezas/counters no card)
  // Thorn
  'golbat':['poison','flying'],'shiny golbat':['poison','flying'],
  'hypno':['psychic'],'shiny hypno':['psychic'],
  // Tempest
  'mr. mime':['psychic'],'shiny mr. mime':['psychic'],'shiny mime':['psychic'],
  'snorlax':['normal'],'shiny snorlax':['normal'],
  'shiny magmar':['fire'],
  'pupitar':['rock','ground'],'shiny pupitar':['rock','ground'],
  // Vortex
  'omastar':['rock','water'],'shiny omastar':['rock','water'],
  'kabutops':['rock','water'],'shiny kabutops':['rock','water'],
  // Pokémons normais (sem shiny) usados pelos Rockets
  'venusaur':['grass','poison'],'blastoise':['water'],'meganium':['grass'],
  'charizard':['fire','flying'],'feraligatr':['water'],'typhlosion':['fire'],
  'alakazam':['psychic'],'electabuzz':['electric'],'arcanine':['fire'],
  'scyther':['bug','flying'],'nidoqueen':['poison','ground'],'nidoking':['poison','ground'],
  'misdreavus':['ghost'],'magcargo':['fire','rock'],'hypno':['psychic'],
  'gligar':['ground','flying'],'murkrow':['dark','flying'],'houndour':['dark','fire'],
  'houndoom':['dark','fire'],'muk':['poison'],'gengar':['ghost','poison'],
  'scizor':['bug','steel'],'gyarados':['water','flying'],
};

// Tabela completa de multiplicadores de dano por tipo atacante vs tipo defensor
// 0 = imune, 0.5 = resistente, 1 = neutro, 2 = fraco
var TYPE_CHART = {
  normal:   { fighting:2, ghost:0 },
  fire:     { fire:0.5, water:2, grass:0.5, ice:0.5, ground:2, rock:2, bug:0.5, steel:0.5, fairy:0.5 },
  water:    { fire:0.5, water:0.5, electric:2, grass:2, ice:0.5, steel:0.5 },
  electric: { electric:0.5, ground:2, flying:0.5, steel:0.5 },
  grass:    { fire:2, water:0.5, electric:0.5, grass:0.5, ice:2, poison:2, ground:0.5, flying:2, bug:2 },
  ice:      { fire:2, ice:0.5, fighting:2, rock:2, steel:2 },
  fighting: { flying:2, psychic:2, bug:0.5, rock:0.5, dark:0.5, fairy:2 },
  poison:   { fighting:0.5, poison:0.5, ground:2, bug:0.5, grass:0.5, psychic:2, fairy:0.5 },
  ground:   { water:2, electric:0, grass:2, ice:2, poison:0.5, rock:0.5 },
  flying:   { electric:2, grass:0.5, ice:2, fighting:0.5, ground:0, bug:0.5, rock:2 },
  psychic:  { fighting:0.5, psychic:0.5, bug:2, ghost:2, dark:2 },
  bug:      { fire:2, grass:0.5, fighting:0.5, ground:0.5, flying:2, rock:2 },
  rock:     { normal:0.5, fire:0.5, water:2, grass:2, fighting:2, poison:0.5, ground:2, flying:0.5, steel:2 },
  ghost:    { normal:0, fighting:0, poison:0.5, bug:0.5, ghost:2, dark:2 },
  dragon:   { fire:0.5, water:0.5, electric:0.5, grass:0.5, ice:2, dragon:2, fairy:2 },
  dark:     { fighting:2, psychic:0, bug:2, ghost:0.5, dark:0.5, fairy:2 },
  steel:    { normal:0.5, fire:2, water:0.5, electric:0.5, grass:0.5, ice:0.5, fighting:2, poison:0, ground:2, flying:0.5, psychic:0.5, bug:0.5, rock:0.5, dragon:0.5, steel:0.5, fairy:0.5 },
  fairy:    { fighting:0.5, bug:0.5, dark:0.5, poison:2, steel:2, dragon:0 },
};

// Calcula as fraquezas reais considerando duplo tipo (resistências cancelam fraquezas)
function getPokeWeaknesses(pokeName) {
  var key = pokeName.replace(/^sh\s+/i,'shiny ').toLowerCase().trim();
  var types = POKE_TYPES[key] || [];
  if (!types.length) return [];

  var allAttackTypes = ['normal','fire','water','electric','grass','ice','fighting','poison',
                        'ground','flying','psychic','bug','rock','ghost','dragon','dark','steel','fairy'];

  var weaknesses = [];
  allAttackTypes.forEach(function(atk) {
    var mult = 1;
    types.forEach(function(def) {
      var row = TYPE_CHART[def];
      if (row && row[atk] !== undefined) mult *= row[atk];
    });
    if (mult > 1) weaknesses.push(atk);
  });
  return weaknesses;
}

// Pokémons no POKEMONS array por tipo principal (para sugerir counters)
var TYPE_COUNTERS = {
  water:    ['electric','grass'],
  fire:     ['water','rock','ground'],
  grass:    ['fire','ice','flying','bug','poison'],
  electric: ['ground'],
  psychic:  ['dark','ghost','bug'],
  ghost:    ['ghost','dark'],
  dark:     ['fighting','fairy','bug'],
  fighting: ['psychic','flying'],
  poison:   ['ground','psychic'],
  ground:   ['water','grass','ice'],
  flying:   ['electric','ice','rock'],
  rock:     ['water','grass','fighting','ground'],
  ice:      ['fire','fighting','rock','steel'],
  dragon:   ['ice','fairy','dragon'],
  steel:    ['fire','fighting','ground'],
  normal:   ['fighting'],
  bug:      ['fire','flying','rock'],
};

// Tipo de cada Pokémon disponível no POKEMONS (para counters)
var POKE_TYPE_MAIN = {
  'shiny ampharos':'electric','shiny arbok':'poison','shiny ariados':'bug','shiny bellossom':'grass',
  'shiny blastoise':'water','shiny charizard':'fire','shiny crobat':'poison','shiny donphan':'ground',
  'shiny dugtrio':'ground','shiny espeon':'psychic','shiny exeggutor':'grass','shiny farfetch\'d':'normal',
  'shiny fearow':'normal','shiny feraligatr':'water','shiny flareon':'fire','shiny golem':'rock',
  'shiny gyarados':'water','shiny hitmonchan':'fighting','shiny hitmonlee':'fighting','shiny hitmontop':'fighting',
  'shiny jolteon':'electric','shiny jynx':'ice','shiny kingdra':'dragon','shiny lapras':'water',
  'shiny machamp':'fighting','shiny magcargo':'fire','shiny magneton':'electric','shiny mantine':'water',
  'shiny marowak':'ground','shiny meganium':'grass','shiny misdreavus':'ghost','shiny muk':'poison',
  'shiny nidoking':'poison','shiny nidoqueen':'poison','shiny ninetales':'fire','shiny onix':'rock',
  'shiny persian':'normal','shiny pidgeot':'normal','shiny politoad':'water','shiny poliwrath':'water',
  'shiny primeape':'fighting','shiny qwilfish':'water','shiny raichu':'electric','shiny rapidash':'fire',
  'shiny rhydon':'ground','shiny sandslash':'ground','shiny scizor':'steel','shiny skarmory':'steel',
  'shiny slowking':'water','shiny starmie':'water','shiny steelix':'steel','shiny tangela':'grass',
  'shiny tangrowth':'grass','shiny tentacruel':'water','shiny torterra':'grass','shiny toxicroak':'poison',
  'shiny typhlosion':'fire','shiny umbreon':'dark','shiny vaporeon':'water','shiny venusaur':'grass',
  'shiny victreebel':'grass','shiny vileplume':'grass','shiny xatu':'psychic','shiny dodrio':'normal',
  'shiny heracross':'bug','shiny arcanine':'fire','shiny kangaskhan':'normal','shiny delibird':'ice',
  'shiny dusknoir':'ghost','shiny espeon':'psychic','shiny luxray':'electric','shiny dragonair':'dragon',
  'shiny pinsir':'bug','shiny tauros':'normal','shiny electrode':'electric',
  'dusknoir':'ghost','luxray':'electric','tangrowth':'grass','torterra':'grass','shiny machamp':'fighting',
  'shiny forretress':'bug','shiny sudowoodo':'rock','shiny scyther':'bug',
};



function getCountersFromPOKEMONS(pokeName) {
  var weaknesses = getPokeWeaknesses(pokeName);
  if (!weaknesses.length) return [];
  var results = [];
  POKEMONS.forEach(function(p) {
    // Usa o tipo do banner (tipo que o Pokémon realmente usa no servidor)
    var pType = getTypeFromBanner(p.bannerImage);
    if (pType && weaknesses.indexOf(pType) !== -1) {
      results.push(p);
    }
  });
  // Ordena por tier: t1 > t2 > t3 > super-raro
  var tierOrder = { 't1':1,'t2':2,'t3':3,'t4':4,'t5':5,'super-raro':0,'hard':6,'mark':7 };
  results.sort(function(a,b) {
    return (tierOrder[a.tag]||9) - (tierOrder[b.tag]||9);
  });
  return results;
}

function getRocketsUsingPokemon(pokeName) {
  var norm = pokeName.toLowerCase();
  var found = [];
  RAW_ROCKETS.forEach(function(rocket) {
    rocket.pokemons.forEach(function(entry) {
      if (entry.name.toLowerCase() === norm) {
        found.push(rocket.name);
      }
    });
  });
  return found;
}

function openRocketPokeInfo(pokeName) {
  var existing = document.getElementById('rocket-poke-modal');
  if (existing) existing.remove();

  var rocketLookupKey = pokeName.replace(/^sh\s+/i,'shiny ').toLowerCase().trim();
  var counters = getCountersFromPOKEMONS(rocketLookupKey);
  var usedBy   = getRocketsUsingPokemon(pokeName);
  var weaknesses = getPokeWeaknesses(rocketLookupKey);
  var types = (POKE_TYPES[rocketLookupKey] || []);
  var spriteUrl = getShowdownSpriteRocket(pokeName);

  var TCFG = {
    't1':{'label':'T1','cls':'tier-t1'},'t2':{'label':'T2','cls':'tier-t2'},'t3':{'label':'T3','cls':'tier-t3'},
    't4':{'label':'T4','cls':'tier-t4'},'t5':{'label':'T5','cls':'tier-t5'},'hard':{'label':'HARD','cls':'tier-hard'},
    'mark':{'label':'MARK','cls':'tier-mark'},'super-raro':{'label':'SUPER RARO','cls':'tier-super-raro'},
  };

  var TYPE_COLORS_LOCAL = {
    fire:'#f97316',water:'#3b82f6',grass:'#22c55e',electric:'#eab308',psychic:'#ec4899',
    ghost:'#8b5cf6',dark:'#6b7280',fighting:'#ef4444',poison:'#a855f7',ground:'#b45309',
    flying:'#7dd3fc',rock:'#a3a3a3',ice:'#67e8f9',dragon:'#6366f1',steel:'#94a3b8',
    normal:'#d4d4d4',bug:'#84cc16',fairy:'#f9a8d4',
  };

  var typeChips = types.map(function(t) {
    var c = TYPE_COLORS_LOCAL[t] || '#aaa';
    return '<span style="background:'+c+';color:#000;font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;text-transform:uppercase;">'+t+'</span>';
  }).join(' ');

  var weakChips = weaknesses.map(function(t) {
    var c = TYPE_COLORS_LOCAL[t] || '#aaa';
    return '<span style="background:'+c+'22;border:1px solid '+c+';color:'+c+';font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;text-transform:uppercase;">'+t+'</span>';
  }).join(' ');

  var usedByHtml = usedBy.length
    ? usedBy.map(function(n){return '<span class="rpoke-rocket-tag">🚀 '+n+'</span>';}).join('')
    : '<span style="color:#666;font-size:12px">Nenhum</span>';

  var counterCards = counters.length
    ? counters.map(function(p) {
        var tc = TCFG[p.tag] ? '<span class="tier-tag '+TCFG[p.tag].cls+'">'+TCFG[p.tag].label+'</span>' : '';
        var spr = getShowdownSpriteRocket(p.name);
        var gif = p.image || '';
        var mainSrc = gif || spr;
        var isShinyCounter = /^sh\s+/i.test(p.name) || /^shiny\s+/i.test(p.name);
        var counterLookup = p.name.replace(/^sh\s+/i,'shiny ').replace(/^shiny\s+/i,'shiny ').trim().toLowerCase();
        var counterTypes = POKE_TYPES[counterLookup] || [];
        var counterTypeChips = counterTypes.map(function(t) {
          var bm = BANNER_TYPE_MAP.find(function(m) { return m.type === t; });
          return bm ? '<img src="https://i.imgur.com/'+bm.url+'.png" alt="'+t+'" title="'+t+'" style="width:16px;height:16px;object-fit:contain;border-radius:3px" loading="lazy" />' : '';
        }).join('');
        var counterDisplayName = isShinyCounter
          ? '<span style="color:#ffd166;font-weight:700">✨ '+p.name+'</span>'
          : p.name;
        return '<div class="rpoke-counter-card">' +
          '<img src="'+mainSrc+'" alt="'+p.name+'" onerror="this.src=\''+spr+'\';this.onerror=null;" />' +
          '<div class="rpoke-counter-name">'+counterDisplayName+'</div>' +
          (counterTypeChips ? '<div style="display:flex;flex-wrap:wrap;gap:2px;justify-content:center">'+counterTypeChips+'</div>' : '') +
          '<div>'+tc+'</div>' +
        '</div>';
      }).join('')
    : '<div style="color:#666;font-size:12px;padding:8px">Nenhum counter encontrado no catálogo.</div>';

  var modal = document.createElement('div');
  modal.id = 'rocket-poke-modal';
  modal.innerHTML =
    '<div class="rpoke-backdrop" onclick="document.getElementById(\'rocket-poke-modal\').remove()"></div>' +
    '<div class="rpoke-panel">' +
      '<button class="rpoke-close" onclick="document.getElementById(\'rocket-poke-modal\').remove()">✕</button>' +
      '<div class="rpoke-header">' +
        '<img class="rpoke-main-sprite" src="'+spriteUrl+'" alt="'+pokeName+'" onerror="this.style.opacity=\'0.3\'" />' +
        '<div class="rpoke-title-block">' +
          '<div class="rpoke-poke-name">'+pokeName+'</div>' +
          '<div class="rpoke-chips">'+typeChips+'</div>' +
        '</div>' +
      '</div>' +

      '<div class="rpoke-section-label">⚔️ Fraquezas</div>' +
      '<div class="rpoke-chips-row">'+(weakChips||'<span style="color:#666;font-size:12px">Sem fraquezas conhecidas</span>')+'</div>' +

      '<div class="rpoke-section-label">🚀 Usado pelos Rockets</div>' +
      '<div class="rpoke-usedby">'+usedByHtml+'</div>' +

      '<div class="rpoke-section-label">✅ Pokémons recomendados para batalhar</div>' +
      '<div class="rpoke-counters-grid">'+counterCards+'</div>' +
    '</div>';

  document.body.appendChild(modal);
}

// ===================== NPC SUB-CATEGORIAS =====================
function switchNpcSubcat(subcat, btn) {
  document.querySelectorAll('.npc-subcat-btn').forEach(function(b) { b.classList.remove('active'); });
  if (btn) btn.classList.add('active');
  document.querySelectorAll('.npc-subcat-content').forEach(function(el) { el.style.display = 'none'; });
  var panel = document.getElementById('npc-tab-' + subcat);
  if (panel) panel.style.display = 'block';
  if (subcat === 'rockets') renderRockets();
  if (subcat === 'officers') renderOfficers();
}

function renderRockets() {
  var grid = document.getElementById('rockets-grid');
  if (!grid) return;

  var q = (document.getElementById('rockets-search') ? document.getElementById('rockets-search').value : '').toLowerCase().trim();

  var filtered = RAW_ROCKETS.filter(function(r) {
    return !q || r.name.toLowerCase().includes(q);
  });

  document.getElementById('rockets-count-label').textContent = filtered.length + ' rockets';

  if (!filtered.length) {
    grid.innerHTML = '<div class="wiki-empty-state"><span class="empty-icon">🚀</span><span class="empty-label">Nenhum Rocket encontrado.</span></div>';
    return;
  }

  grid.innerHTML = filtered.map(function(rocket, idx) {
    var isGiovanni = rocket.name === 'Giovanni';

    var pokeCards = rocket.pokemons.map(function(entry) {
      var pokeName = entry.name;
      var rewardKey = entry.reward;
      var rewardData = getRocketRewardData(rewardKey);
      var rewardName = rewardKey.replace(/^sh\s+/i, 'Shiny ');
      var rewardTag = rewardData ? rewardData.tag : null;
      var rewardImg = rewardData ? rewardData.image : null;
      var TCFG = {
        't1':{'label':'T1','cls':'tier-t1'},'t2':{'label':'T2','cls':'tier-t2'},'t3':{'label':'T3','cls':'tier-t3'},
        't4':{'label':'T4','cls':'tier-t4'},'t5':{'label':'T5','cls':'tier-t5'},'hard':{'label':'HARD','cls':'tier-hard'},
        'mark':{'label':'MARK','cls':'tier-mark'},'super-raro':{'label':'SUPER RARO','cls':'tier-super-raro'},
      };
      var tagHtml = rewardTag && TCFG[rewardTag.toLowerCase()]
        ? '<span class="tier-tag '+TCFG[rewardTag.toLowerCase()].cls+'">'+TCFG[rewardTag.toLowerCase()].label+'</span>'
        : '';
      var spriteUrl    = getShowdownSpriteRocket(pokeName);
      var rewardSpriteUrl = rewardImg || getShowdownSpriteRocket(rewardName);

      var isShinyPoke = /^sh\s+/i.test(pokeName) || /^shiny\s+/i.test(pokeName);
      var displayPokeName = isShinyPoke
        ? '<span style="color:#ffd166;font-weight:700">✨ '+pokeName+'</span>'
        : '<span style="color:var(--text-muted,#aab)">'+pokeName+'</span>';
      var lookupKeyRocket = pokeName.replace(/^sh\s+/i,'shiny ').toLowerCase().trim();
      var typesRocket = POKE_TYPES[lookupKeyRocket] || [];
      var typeChipsRocket = typesRocket.map(function(t) {
        var bm = BANNER_TYPE_MAP.find(function(m) { return m.type === t; });
        return bm ? '<img src="https://i.imgur.com/'+bm.url+'.png" alt="'+t+'" title="'+t+'" style="width:18px;height:18px;object-fit:contain;border-radius:3px" loading="lazy" />' : '';
      }).join('');

      return '<div class="rocket-poke-card" style="flex-direction:column;gap:4px" onclick="openRocketPokeInfo(\''+pokeName.replace(/'/g,"\\'")+'\')" title="Ver info de '+pokeName+'">' +
        '<img class="rocket-poke-sprite" src="'+spriteUrl+'" alt="'+pokeName+'" loading="lazy" onerror="this.src=\'https://play.pokemonshowdown.com/sprites/gen5/substitute.png\'" />' +
        '<div class="rocket-poke-name" style="font-size:11px;text-align:center;line-height:1.2">'+displayPokeName+'</div>' +
        (typeChipsRocket ? '<div style="display:flex;flex-wrap:wrap;gap:3px;justify-content:center;margin-top:2px">'+typeChipsRocket+'</div>' : '') +
        '<div class="rocket-poke-info-hint">🔍 ver info</div>' +
      '</div>';
    }).join('');

    var winsNote = rocket.wins ? '<span class="rocket-wins-note">🏆 Requer '+rocket.wins+' batalhas contra os demais Rockets</span>' : '';
    var headerClass = isGiovanni ? 'rocket-row-header giovanni-header' : 'rocket-row-header';

    return '<div class="rocket-row'+(isGiovanni?' giovanni-row':'')+'" id="rocket-row-'+idx+'">' +
      '<div class="'+headerClass+'" onclick="toggleRocketRow('+idx+')">' +
        '<span class="rocket-row-icon">'+(isGiovanni?'👑':'🚀')+'</span>' +
        '<span class="rocket-row-name">'+rocket.name+'</span>' +
        (winsNote?winsNote:'') +
        '<svg class="rocket-row-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>' +
      '</div>' +
      '<div class="rocket-row-panel">' +
        '<div class="rocket-poke-grid">'+pokeCards+'</div>' +
      '</div>' +
    '</div>';
  }).join('');

  if (!document.getElementById('npcs-css')) {
    var npcStyle = document.createElement('style');
    npcStyle.id = 'npcs-css';
    npcStyle.textContent = `
      .npc-subcats {
        display: flex;
        gap: 8px;
        padding: 12px 0 4px;
        flex-wrap: wrap;
      }
      .npc-subcat-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 7px 18px;
        background: rgba(255,255,255,0.04);
        border: 1px solid var(--border, #2a2f45);
        border-radius: 20px;
        color: var(--muted, #8899aa);
        font-family: var(--font-title, inherit);
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        cursor: pointer;
        transition: all 0.18s;
      }
      .npc-subcat-btn:hover {
        background: rgba(96,170,255,0.08);
        border-color: rgba(96,170,255,0.35);
        color: #fff;
      }
      .npc-subcat-btn.active {
        background: rgba(96,170,255,0.12);
        border-color: rgba(96,170,255,0.6);
        color: #60aaff;
      }
      .npc-subcat-content { display: none; }
      .npc-subcat-content:first-of-type { display: block; }
    `;
    document.head.appendChild(npcStyle);
  }

  if (!document.getElementById('rockets-css')) {
    var style = document.createElement('style');
    style.id = 'rockets-css';
    style.textContent = `
      #rockets-grid { padding: 8px 0; }
      .rocket-row { border: 1px solid var(--border, #2a2f45); border-radius: 10px; margin-bottom: 10px; overflow: hidden; background: var(--card-bg, #161b2e); transition: box-shadow 0.2s; }
      .rocket-row:hover { box-shadow: 0 0 12px rgba(96,170,255,0.15); }
      .giovanni-row { border-color: #f5c518 !important; box-shadow: 0 0 18px rgba(245,197,24,0.18); }
      .rocket-row-header { display: flex; align-items: center; gap: 10px; padding: 13px 16px; cursor: pointer; user-select: none; transition: background 0.15s; }
      .rocket-row-header:hover { background: rgba(255,255,255,0.04); }
      .giovanni-header { background: linear-gradient(90deg, rgba(245,197,24,0.12) 0%, transparent 100%); }
      .rocket-row-icon { font-size: 18px; }
      .rocket-row-name { font-weight: 700; font-size: 15px; flex: 1; }
      .rocket-wins-note { font-size: 11px; color: #f5c518; background: rgba(245,197,24,0.1); border-radius: 5px; padding: 2px 8px; white-space: nowrap; }
      .rocket-row-chevron { width: 18px; height: 18px; stroke: var(--muted, #8899aa); transition: transform 0.2s; }
      .rocket-row.open .rocket-row-chevron { transform: rotate(180deg); }
      .rocket-row-panel { display: none; padding: 4px 12px 14px; border-top: 1px solid var(--border, #2a2f45); }
      .rocket-row.open .rocket-row-panel { display: block; }
      .rocket-poke-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 10px; margin-top: 10px; }
      .rocket-poke-card { background: rgba(255,255,255,0.03); border: 1px solid var(--border, #2a2f45); border-radius: 8px; padding: 10px 8px; display: flex; align-items: center; gap: 6px; justify-content: space-between; transition: background 0.15s, border-color 0.15s; cursor: pointer; }
      .rocket-poke-card:hover { background: rgba(96,170,255,0.08); border-color: rgba(96,170,255,0.4); }
      .rocket-poke-enemy, .rocket-poke-reward { display: flex; flex-direction: column; align-items: center; gap: 2px; flex: 1; }
      .rocket-poke-sprite { width: 56px; height: 56px; image-rendering: pixelated; object-fit: contain; }
      .reward-sprite { filter: drop-shadow(0 0 6px rgba(96,170,255,0.35)); }
      .rocket-poke-name, .rocket-poke-reward-name { font-size: 11px; text-align: center; color: var(--text-muted, #aab); line-height: 1.2; }
      .rocket-poke-reward-name { color: var(--accent, #60aaff); font-weight: 600; }
      .rocket-poke-tags { margin-top: 3px; }
      .rocket-poke-arrow { font-size: 16px; color: var(--muted, #556); flex-shrink: 0; }
      .rocket-poke-info-hint { font-size: 9px; color: rgba(96,170,255,0.5); margin-top: 2px; }
      .rocket-poke-card:hover .rocket-poke-info-hint { color: rgba(96,170,255,0.9); }
      .tier-super-raro { background: linear-gradient(90deg,#a855f7,#ec4899); color: #fff; font-size: 10px; padding: 2px 6px; border-radius: 4px; font-weight: 700; }

      /* ── Modal Pokémon Info ── */
      .rpoke-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 9000; }
      .rpoke-panel { position: fixed; top: 50%; left: 50%; transform: translate(-50%,-50%); z-index: 9001; background: #0f1628; border: 1px solid #2a2f45; border-radius: 14px; width: min(520px, 94vw); max-height: 85vh; overflow-y: auto; padding: 20px 20px 24px; box-shadow: 0 8px 40px rgba(0,0,0,0.6); }
      .rpoke-close { position: absolute; top: 12px; right: 14px; background: none; border: none; color: #aaa; font-size: 18px; cursor: pointer; padding: 4px 8px; border-radius: 6px; transition: background 0.15s; }
      .rpoke-close:hover { background: rgba(255,255,255,0.08); color: #fff; }
      .rpoke-header { display: flex; align-items: center; gap: 14px; margin-bottom: 16px; }
      .rpoke-main-sprite { width: 80px; height: 80px; image-rendering: pixelated; }
      .rpoke-poke-name { font-size: 20px; font-weight: 800; color: #fff; margin-bottom: 6px; }
      .rpoke-chips { display: flex; flex-wrap: wrap; gap: 4px; }
      .rpoke-section-label { font-size: 11px; font-weight: 700; color: #60aaff; text-transform: uppercase; letter-spacing: 0.08em; margin: 14px 0 7px; }
      .rpoke-chips-row { display: flex; flex-wrap: wrap; gap: 5px; }
      .rpoke-usedby { display: flex; flex-wrap: wrap; gap: 6px; }
      .rpoke-rocket-tag { background: rgba(96,170,255,0.1); border: 1px solid rgba(96,170,255,0.3); color: #60aaff; font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 20px; }
      .rpoke-counters-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(90px, 1fr)); gap: 8px; margin-top: 4px; }
      .rpoke-counter-card { background: rgba(255,255,255,0.03); border: 1px solid #2a2f45; border-radius: 8px; padding: 8px 4px; display: flex; flex-direction: column; align-items: center; gap: 4px; transition: background 0.15s; }
      .rpoke-counter-card:hover { background: rgba(96,170,255,0.07); }
      .rpoke-counter-card img { width: 52px; height: 52px; image-rendering: pixelated; cursor: pointer; }
      .rpoke-counter-name { font-size: 10px; text-align: center; color: #ccd; line-height: 1.2; }

      @media (max-width: 480px) {
        .rocket-poke-grid { grid-template-columns: 1fr 1fr; }
        .rocket-poke-sprite { width: 44px; height: 44px; }
        .rpoke-counters-grid { grid-template-columns: repeat(3, 1fr); }
      }
    `;
    document.head.appendChild(style);
  }
}

function toggleRocketRow(idx) {
  var row = document.getElementById('rocket-row-' + idx);
  if (!row) return;
  var isOpen = row.classList.contains('open');
  document.querySelectorAll('.rocket-row.open').forEach(function(r) { r.classList.remove('open'); });
  if (!isOpen) row.classList.add('open');
}

// ===================== OFFICERS =====================

// Tipo temático de cada Officer → banner image URL
var OFFICER_TYPE_BANNER = {
  'Officer Blaze':    'https://i.imgur.com/O8TONGE.png',  // fire
  'Officer Marina':   'https://i.imgur.com/zpRe43i.png',  // water
  'Sergeant Volt':    'https://i.imgur.com/Yv2WEYc.png',  // electric
  'Captain Verdant':  'https://i.imgur.com/YjKxtoE.png',  // grass
  'Inspector Frost':  'https://i.imgur.com/ssFz0sA.png',  // ice
  'Commander Mind':   'https://i.imgur.com/ASiZi1K.png',  // psychic
  'Warden Shade':     'https://i.imgur.com/7Luj4az.png',  // dark
  'Lieutenant Alloy': 'https://i.imgur.com/GleRjiM.png',  // steel
  'Marshal Boulder':  'https://i.imgur.com/GvD1Mtq.png',  // rock
  'Detective Terra':  'https://i.imgur.com/JPcD2l3.png',  // ground
  'Chief Toxin':      'https://i.imgur.com/xfX0ReE.png',  // poison
  'Ranger Strike':    'https://i.imgur.com/OKsJXh7.png',  // fighting
  'Captain Chitin':   'https://i.imgur.com/V4IXR51.png',  // bug
};

// Tipo temático de cada Officer (para calcular fraquezas/counters no modal)
var OFFICER_TYPE_KEY = {
  'Officer Blaze':    'fire',
  'Officer Marina':   'water',
  'Sergeant Volt':    'electric',
  'Captain Verdant':  'grass',
  'Inspector Frost':  'ice',
  'Commander Mind':   'psychic',
  'Warden Shade':     'dark',
  'Lieutenant Alloy': 'steel',
  'Marshal Boulder':  'rock',
  'Detective Terra':  'ground',
  'Chief Toxin':      'poison',
  'Ranger Strike':    'fighting',
  'Captain Chitin':   'bug',
};

var RAW_OFFICERS = [
  { name: 'Officer Blaze',    icon: '🔥', rank: 'officer',
    pokemons: ['sh Charizard','sh Magmar','sh Flareon','sh Typhlosion','sh Ninetales','sh Arcanine'] },
  { name: 'Officer Marina',   icon: '💧', rank: 'officer',
    pokemons: ['sh Feraligatr','sh Lapras','sh Gyarados','sh Vaporeon','sh Starmie','sh Blastoise'] },
  { name: 'Sergeant Volt',    icon: '⚡', rank: 'sergeant',
    pokemons: ['sh Magneton','sh Ampharos','sh Lanturn','sh Electabuzz','sh Raichu','sh Jolteon'] },
  { name: 'Captain Verdant',  icon: '🌿', rank: 'captain',
    pokemons: ['sh Meganium','sh Vileplume','sh Venusaur','sh Exeggutor','sh Victreebel','sh Jumpluff'] },
  { name: 'Inspector Frost',  icon: '❄️', rank: 'inspector',
    pokemons: ['sh Piloswine','sh Cloyster','sh Jynx','sh Lapras','sh Dewgong','sh Sneasel'] },
  { name: 'Commander Mind',   icon: '🔮', rank: 'commander',
    pokemons: ['sh Starmie','sh Alakazam','sh Espeon','sh Exeggutor','sh Mr. Mime','sh Xatu'] },
  { name: 'Warden Shade',     icon: '👻', rank: 'warden',
    pokemons: ['Houndoom','sh Sneasel','Tyranitar','sh Houndoom','sh Tyranitar','sh Umbreon'] },
  { name: 'Lieutenant Alloy', icon: '⚙️', rank: 'lieutenant',
    pokemons: ['sh Scizor','sh Magneton','sh Skarmory','sh Steelix','sh Forretress','Scizor'] },
  { name: 'Marshal Boulder',  icon: '🪨', rank: 'marshal',
    pokemons: ['sh Omastar','sh Golem','sh Tyranitar','sh Sudowoodo','sh Kabutops','sh Rhydon'] },
  { name: 'Detective Terra',  icon: '🌍', rank: 'detective',
    pokemons: ['sh Nidoqueen','sh Nidoking','sh Marowak','sh Sandslash','sh Donphan','sh Dugtrio'] },
  { name: 'Chief Toxin',      icon: '☠️', rank: 'chief',
    pokemons: ['sh Weezing','sh Muk','sh Nidoking','sh Crobat','sh Toxicroak','sh Vileplume'] },
  { name: 'Ranger Strike',    icon: '🥊', rank: 'ranger',
    pokemons: ['sh Primeape','sh Machamp','sh Heracross','sh Hitmonchan','sh Poliwrath','sh Hitmonlee'] },
  { name: 'Captain Chitin',   icon: '🪲', rank: 'captain',
    pokemons: ['sh Forretress','sh Ariados','sh Scyther','sh Scizor','sh Pinsir','sh Heracross'] },
];

var OFFICER_RANK_CONFIG = {
  officer:    { color: '#3b82f6', label: 'Officer'    },
  sergeant:   { color: '#22c55e', label: 'Sergeant'   },
  captain:    { color: '#f59e0b', label: 'Captain'    },
  inspector:  { color: '#60a5fa', label: 'Inspector'  },
  commander:  { color: '#a855f7', label: 'Commander'  },
  warden:     { color: '#6b7280', label: 'Warden'     },
  lieutenant: { color: '#94a3b8', label: 'Lieutenant' },
  marshal:    { color: '#b45309', label: 'Marshal'    },
  detective:  { color: '#ec4899', label: 'Detective'  },
  chief:      { color: '#ef4444', label: 'Chief'      },
  ranger:     { color: '#84cc16', label: 'Ranger'     },
};

var _officersSearchTimer;

function officerPokeKey(rawName) {
  return rawName.replace(/^sh\s+/i, 'shiny ').toLowerCase().trim();
}

function getOfficerSprite(rawName) {
  var isShiny = /^sh\s+/i.test(rawName);
  var n = toShowdownName((isShiny ? 'shiny ' : '') + rawName.replace(/^sh\s+/i, ''));
  return isShiny
    ? 'https://play.pokemonshowdown.com/sprites/ani-shiny/' + n + '.gif'
    : 'https://play.pokemonshowdown.com/sprites/ani/' + n + '.gif';
}

function getOfficerFallbackSprite(rawName) {
  var isShiny = /^sh\s+/i.test(rawName);
  var n = toShowdownName((isShiny ? 'shiny ' : '') + rawName.replace(/^sh\s+/i, ''));
  return isShiny
    ? 'https://play.pokemonshowdown.com/sprites/gen5-shiny/' + n + '.png'
    : 'https://play.pokemonshowdown.com/sprites/gen5/' + n + '.png';
}

function renderOfficers() {
  var grid = document.getElementById('officers-grid');
  if (!grid) return;

  var q = (document.getElementById('officers-search') ? document.getElementById('officers-search').value : '').toLowerCase().trim();
  var filtered = RAW_OFFICERS.filter(function(o) { return !q || o.name.toLowerCase().includes(q); });

  document.getElementById('officers-count-label').textContent = filtered.length + ' officers';

  if (!filtered.length) {
    grid.innerHTML = '<div class="wiki-empty-state"><span class="empty-icon">👮</span><span class="empty-label">Nenhum Officer encontrado.</span></div>';
    return;
  }

  grid.innerHTML = filtered.map(function(officer, idx) {
    var rankCfg   = OFFICER_RANK_CONFIG[officer.rank] || { color: '#60aaff', label: officer.rank };
    var isHighRank = (officer.rank === 'captain' || officer.rank === 'commander' || officer.rank === 'chief' || officer.rank === 'marshal');
    var bannerUrl  = OFFICER_TYPE_BANNER[officer.name];

    var rankBadge = '<span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;text-transform:uppercase;background:'+rankCfg.color+'22;border:1px solid '+rankCfg.color+';color:'+rankCfg.color+'">'+rankCfg.label+'</span>';

    // Banner de tipo no header — substitui o ícone/emoji à esquerda
    var typeBannerHtml = bannerUrl
      ? '<img src="'+bannerUrl+'" alt="tipo" style="width:28px;height:28px;object-fit:contain;border-radius:4px;flex-shrink:0" loading="lazy" />'
      : '<span class="rocket-row-icon">'+officer.icon+'</span>';

    var pokeCards = officer.pokemons.map(function(rawName) {
      var isShiny   = /^sh\s+/i.test(rawName);
      var lookupKey = officerPokeKey(rawName);
      var types     = POKE_TYPES[lookupKey] || [];
      var spriteUrl = getOfficerSprite(rawName);
      var fallback  = getOfficerFallbackSprite(rawName);

      // Chips de tipo usando imagem do banner
      var typeChips = types.map(function(t) {
        var bannerImg = BANNER_TYPE_MAP.find(function(m) { return m.type === t; });
        if (bannerImg) {
          return '<img src="https://i.imgur.com/'+bannerImg.url+'.png" alt="'+t+'" title="'+t+'" '+
            'style="width:18px;height:18px;object-fit:contain;border-radius:3px" loading="lazy" />';
        }
        return '';
      }).join('');

      var displayName = isShiny
        ? '<span style="color:#ffd166;font-weight:700">✨ '+rawName+'</span>'
        : '<span style="color:var(--text-muted,#aab)">'+rawName+'</span>';

      return '<div class="rocket-poke-card" style="flex-direction:column;gap:4px;cursor:pointer" '+
        'onclick="openOfficerPokeInfo(\''+rawName.replace(/'/g,"\\'")+'\''+')" title="Ver info de '+rawName+'">' +
        '<img class="rocket-poke-sprite" src="'+spriteUrl+'" alt="'+rawName+'" loading="lazy" '+
          'onerror="this.src=\''+fallback+'\';this.onerror=function(){this.src=\'https://play.pokemonshowdown.com/sprites/gen5/substitute.png\'}" />' +
        '<div class="rocket-poke-name" style="font-size:11px;text-align:center;line-height:1.2">'+displayName+'</div>' +
        (typeChips ? '<div style="display:flex;flex-wrap:wrap;gap:3px;justify-content:center;margin-top:2px">'+typeChips+'</div>' : '') +
        '<div class="rocket-poke-info-hint">🔍 ver info</div>' +
      '</div>';
    }).join('');

    return '<div class="rocket-row" id="officer-row-'+idx+'" '+
      'style="'+(isHighRank ? 'border-color:'+rankCfg.color+'88!important;box-shadow:0 0 14px '+rankCfg.color+'22;' : '')+'">' +
      '<div class="rocket-row-header" onclick="toggleOfficerRow('+idx+')" '+
        'style="'+(isHighRank ? 'background:linear-gradient(90deg,'+rankCfg.color+'18 0%,transparent 100%);' : '')+'">' +
        typeBannerHtml +
        '<span class="rocket-row-name">'+officer.name+'</span>' +
        rankBadge +
        '<svg class="rocket-row-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>' +
      '</div>' +
      '<div class="rocket-row-panel">' +
        '<div class="rocket-poke-grid">'+pokeCards+'</div>' +
      '</div>' +
    '</div>';
  }).join('');
}

function toggleOfficerRow(idx) {
  var row = document.getElementById('officer-row-' + idx);
  if (!row) return;
  var isOpen = row.classList.contains('open');
  document.querySelectorAll('#officers-grid .rocket-row.open').forEach(function(r) { r.classList.remove('open'); });
  if (!isOpen) row.classList.add('open');
}

function openOfficerPokeInfo(rawName) {
  var existing = document.getElementById('officer-poke-modal');
  if (existing) existing.remove();

  var lookupKey  = officerPokeKey(rawName);
  var isShiny    = /^sh\s+/i.test(rawName);
  var counters   = getCountersFromPOKEMONS(lookupKey);
  var weaknesses = getPokeWeaknesses(lookupKey);
  var types      = POKE_TYPES[lookupKey] || [];
  var spriteUrl  = getOfficerSprite(rawName);
  var fallback   = getOfficerFallbackSprite(rawName);

  // Qual Officer usa este Pokémon
  var usedBy = [];
  RAW_OFFICERS.forEach(function(o) {
    o.pokemons.forEach(function(p) {
      if (p.toLowerCase() === rawName.toLowerCase()) usedBy.push(o.name);
    });
  });

  var TCFG = {
    't1':{'label':'T1','cls':'tier-t1'},'t2':{'label':'T2','cls':'tier-t2'},'t3':{'label':'T3','cls':'tier-t3'},
    't4':{'label':'T4','cls':'tier-t4'},'t5':{'label':'T5','cls':'tier-t5'},'hard':{'label':'HARD','cls':'tier-hard'},
    'mark':{'label':'MARK','cls':'tier-mark'},'super-raro':{'label':'SUPER RARO','cls':'tier-super-raro'},
  };
  var TC = {
    fire:'#f97316',water:'#3b82f6',grass:'#22c55e',electric:'#eab308',psychic:'#ec4899',
    ghost:'#8b5cf6',dark:'#6b7280',fighting:'#ef4444',poison:'#a855f7',ground:'#b45309',
    flying:'#7dd3fc',rock:'#a3a3a3',ice:'#67e8f9',dragon:'#6366f1',steel:'#94a3b8',
    normal:'#d4d4d4',bug:'#84cc16',fairy:'#f9a8d4',
  };

  // Tipo chips com imagem banner no modal
  var typeChips = types.map(function(t) {
    var bannerImg = BANNER_TYPE_MAP.find(function(m) { return m.type === t; });
    var c = TC[t] || '#aaa';
    if (bannerImg) {
      return '<span style="display:inline-flex;align-items:center;gap:4px;background:'+c+'22;border:1px solid '+c+';border-radius:6px;padding:3px 8px">'+
        '<img src="https://i.imgur.com/'+bannerImg.url+'.png" alt="'+t+'" style="width:16px;height:16px;object-fit:contain" />'+
        '<span style="color:'+c+';font-size:10px;font-weight:700;text-transform:uppercase">'+t+'</span>'+
      '</span>';
    }
    return '<span style="background:'+c+';color:#000;font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;text-transform:uppercase">'+t+'</span>';
  }).join(' ');

  var weakChips = weaknesses.map(function(t) {
    var bannerImg = BANNER_TYPE_MAP.find(function(m) { return m.type === t; });
    var c = TC[t] || '#aaa';
    if (bannerImg) {
      return '<span style="display:inline-flex;align-items:center;gap:4px;background:'+c+'22;border:1px solid '+c+';border-radius:6px;padding:3px 8px">'+
        '<img src="https://i.imgur.com/'+bannerImg.url+'.png" alt="'+t+'" style="width:16px;height:16px;object-fit:contain" />'+
        '<span style="color:'+c+';font-size:10px;font-weight:700;text-transform:uppercase">'+t+'</span>'+
      '</span>';
    }
    return '<span style="background:'+c+'22;border:1px solid '+c+';color:'+c+';font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;text-transform:uppercase">'+t+'</span>';
  }).join(' ');

  var usedByHtml = usedBy.length
    ? usedBy.map(function(n) {
        var b = OFFICER_TYPE_BANNER[n];
        return '<span class="rpoke-rocket-tag" style="display:inline-flex;align-items:center;gap:5px">'+
          (b ? '<img src="'+b+'" style="width:16px;height:16px;object-fit:contain" />' : '👮')+
          n+'</span>';
      }).join('')
    : '<span style="color:#666;font-size:12px">Nenhum</span>';

  var counterCards = counters.length
    ? counters.map(function(p) {
        var tc = TCFG[p.tag] ? '<span class="tier-tag '+TCFG[p.tag].cls+'">'+TCFG[p.tag].label+'</span>' : '';
        var spr = getShowdownSpriteRocket(p.name);
        var mainSrc = p.image || spr;
        var isShinyCounter = /^sh\s+/i.test(p.name) || /^shiny\s+/i.test(p.name);
        var counterLookup = p.name.replace(/^sh\s+/i,'shiny ').replace(/^shiny\s+/i,'shiny ').trim().toLowerCase();
        var counterTypes = POKE_TYPES[counterLookup] || [];
        var counterTypeChips = counterTypes.map(function(t) {
          var bm = BANNER_TYPE_MAP.find(function(m) { return m.type === t; });
          return bm ? '<img src="https://i.imgur.com/'+bm.url+'.png" alt="'+t+'" title="'+t+'" style="width:16px;height:16px;object-fit:contain;border-radius:3px" loading="lazy" />' : '';
        }).join('');
        var counterDisplayName = isShinyCounter
          ? '<span style="color:#ffd166;font-weight:700">✨ '+p.name+'</span>'
          : p.name;
        return '<div class="rpoke-counter-card">'+
          '<img src="'+mainSrc+'" alt="'+p.name+'" onerror="this.src=\''+spr+'\';this.onerror=null;" />'+
          '<div class="rpoke-counter-name">'+counterDisplayName+'</div>'+
          (counterTypeChips ? '<div style="display:flex;flex-wrap:wrap;gap:2px;justify-content:center">'+counterTypeChips+'</div>' : '') +
          '<div>'+tc+'</div>'+
        '</div>';
      }).join('')
    : '<div style="color:#666;font-size:12px;padding:8px">Nenhum counter encontrado no catálogo.</div>';

  var displayName = isShiny ? '<span style="color:#ffd166">✨ '+rawName+'</span>' : rawName;

  var modal = document.createElement('div');
  modal.id = 'officer-poke-modal';
  modal.innerHTML =
    '<div class="rpoke-backdrop" onclick="document.getElementById(\'officer-poke-modal\').remove()"></div>'+
    '<div class="rpoke-panel">'+
      '<button class="rpoke-close" onclick="document.getElementById(\'officer-poke-modal\').remove()">✕</button>'+
      '<div class="rpoke-header">'+
        '<img class="rpoke-main-sprite" src="'+spriteUrl+'" alt="'+rawName+'" '+
          'onerror="this.src=\''+fallback+'\';this.onerror=function(){this.style.opacity=\'0.3\'}" />'+
        '<div class="rpoke-title-block">'+
          '<div class="rpoke-poke-name">'+displayName+'</div>'+
          '<div class="rpoke-chips" style="flex-wrap:wrap;gap:5px">'+typeChips+'</div>'+
        '</div>'+
      '</div>'+
      '<div class="rpoke-section-label">⚔️ Fraquezas</div>'+
      '<div class="rpoke-chips-row" style="flex-wrap:wrap;gap:5px">'+(weakChips||'<span style="color:#666;font-size:12px">Sem fraquezas conhecidas</span>')+'</div>'+
      '<div class="rpoke-section-label">👮 Usado pelos Officers</div>'+
      '<div class="rpoke-usedby">'+usedByHtml+'</div>'+
      '<div class="rpoke-section-label">✅ Pokémons recomendados para batalhar</div>'+
      '<div class="rpoke-counters-grid">'+counterCards+'</div>'+
    '</div>';

  document.body.appendChild(modal);
}
// ===================== HAZARD TASKS =====================

var RAW_HAZARD = [
  { npc: 'Nerida',  imgId: 'eIoGIEv.png', task: '6 Sh Wailord, 6 Sh Whiscash, 6 Sh Crawdaunt, 6 Sh Luvdisk, 6 Sh Clamperl' },
  { npc: 'Verdra',  imgId: 'sCT8XeS.png', task: '15 Sh Roselia, 15 Sh Cradily' },
  { npc: 'Rohgar',  imgId: '0c8mJ4B.png', task: '6 Sh Mightyena, 6 Sh Zangoose, 6 Sh Seviper, 6 Sh Absol, 6 Sh Sharpedo' },
  { npc: 'Draven',  imgId: 'HTMFh6N.png', task: '15 Sh Flygon, 15 Sh Salamalence' },
  { npc: 'Ferris',  imgId: 'b6dRGyY.png', task: '10 Sh Aggron, 10 Sh Mawile, 10 Sh Metagross' },
  { npc: 'Talia',   imgId: 'Ue7V6kw.png', task: '8 Sh Breloom, 8 Sh Shiftry, 7 Sh Cacturne, 7 Sh Tropius' },
  { npc: 'Nyxen',   imgId: 'wJ8hCPS.png', task: '10 Sh Sableye, 10 Sh Banette, 10 Sh Dusclops' },
  { npc: 'Voltrix', imgId: 'M1VkDef.png', task: '30 Sh Manectric' },
  { npc: 'Glacis',  imgId: 'T3EKiyY.png', task: '15 Sh Glalie, 15 Sh Walrein' },
  { npc: 'Hadriel', imgId: 'I5wubJc.png', task: '10 Sh Hariyama, 10 Sh Medicham, 10 Sh Slaking' },
  { npc: 'Lucine',  imgId: 'w8p1cJw.png', task: '8 Sh Linoone, 8 Sh Delcatty, 7 Sh Swellow, 7 Sh Kecleon' },
  { npc: 'Veska',   imgId: 'c78R578.png', task: '5 Sh Beautifly, 5 Sh Dustox, 4 Sh Masquerain, 4 Sh Ninjask, 4 Sh Volbeat, 4 Sh Ilumise, 4 Sh Shedinja' },
  { npc: 'Calder',  imgId: 'kgjNPJa.png', task: '15 Sh Camerupt, 15 Sh Torkoal' },
  { npc: 'Kaela',   imgId: 'wlF1RZh.png', task: '10 Sh Sceptile, 10 Sh Blaziken, 10 Sh Swampert' },
  { npc: 'Orlan',   imgId: '7E6igom.png', task: '15 Sh Pelipper, 15 Sh Altaria' },
  { npc: 'Selene',  imgId: '7E6igom.png', task: '5 Sh Gardevoir, 5 Sh Grumpig, 5 Sh Chimecho, 5 Sh Claydol, 5 Sh Lunatone, 5 Sh Solrock' },
  { npc: 'Maera',   imgId: 'NhzLpkd.png', task: '8 Sh Milotic, 8 Sh Huntail, 7 Sh Gorebyss, 7 Sh Relicanth' },
];

function getImgurDirectUrl(imgId) {
  return 'https://i.imgur.com/' + imgId + '.jpg';
}

function parseHazardTask(taskStr) {
  return taskStr.split(',').map(function(part) {
    part = part.trim();
    var m = part.match(/^(\d+)\s+Sh\s+(.+)$/i);
    if (m) return { qty: parseInt(m[1]), name: m[2].trim() };
    return { qty: 0, name: part };
  });
}

function getShowdownSpriteHazard(name) {
  var key = name.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  var fixes = { 'salamalence': 'salamence', 'ilumise': 'illumise', 'luvdisk': 'luvdisc' };
  if (fixes[key]) key = fixes[key];
  return 'https://play.pokemonshowdown.com/sprites/ani-shiny/' + key + '.gif';
}

function openHazardMapModal(npcName, imgId) {
  var existing = document.getElementById('hazard-map-modal');
  if (existing) existing.remove();

  var modal = document.createElement('div');
  modal.id = 'hazard-map-modal';
  modal.innerHTML =
    '<div class="hzmap-backdrop" onclick="document.getElementById(\'hazard-map-modal\').remove()"></div>' +
    '<div class="hzmap-panel">' +
      '<div class="hzmap-header">' +
        '<div class="hzmap-title">' +
          '<span class="hzmap-title-icon">📍</span>' +
          '<span>Localização — ' + npcName + '</span>' +
        '</div>' +
        '<button class="hzmap-close" onclick="document.getElementById(\'hazard-map-modal\').remove()">✕</button>' +
      '</div>' +
      '<div class="hzmap-body">' +
        '<div class="hzmap-loading" id="hzmap-loading">Carregando imagem...</div>' +
        '<img ' +
          'class="hzmap-img" ' +
          'src="' + getImgurDirectUrl(imgId) + '" ' +
          'alt="Localização ' + npcName + '" ' +
          'onload="document.getElementById(\'hzmap-loading\').style.display=\'none\';this.style.opacity=\'1\'" ' +
          'onerror="document.getElementById(\'hzmap-loading\').textContent=\'Não foi possível carregar a imagem.\'" ' +
          'style="opacity:0;transition:opacity 0.3s"' +
        '/>' +
      '</div>' +
      '<div class="hzmap-footer">' +
        '<a class="hzmap-ext-link" href="' + getImgurDirectUrl(imgId) + '" target="_blank" rel="noopener">' +
          '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>' +
          'Abrir no Imgur' +
        '</a>' +
      '</div>' +
    '</div>';

  document.body.appendChild(modal);

  // Close on Escape
  function onKey(e) {
    if (e.key === 'Escape') {
      var m = document.getElementById('hazard-map-modal');
      if (m) m.remove();
      document.removeEventListener('keydown', onKey);
    }
  }
  document.addEventListener('keydown', onKey);
}

function renderHazard() {
  var grid = document.getElementById('hazard-grid');
  if (!grid) return;

  var q = (document.getElementById('hazard-search') ? document.getElementById('hazard-search').value : '').toLowerCase().trim();

  var filtered = RAW_HAZARD.filter(function(h) {
    return !q || h.npc.toLowerCase().includes(q) || h.task.toLowerCase().includes(q);
  });

  document.getElementById('hazard-count-label').textContent = filtered.length + ' NPCs';

  if (!filtered.length) {
    grid.innerHTML = '<div class="wiki-empty-state"><span class="empty-icon">⚠️</span><span class="empty-label">Nenhum NPC encontrado.</span></div>';
    return;
  }

  if (!document.getElementById('hazard-css')) {
    var s = document.createElement('style');
    s.id = 'hazard-css';
    s.textContent = `
      /* ── Hazard Page ── */
      .hazard-page { max-width: 960px; margin: 0 auto; padding: 8px 0 40px; }
      .hazard-hero { text-align: center; padding: 28px 20px 20px; margin-bottom: 8px; }
      .hazard-hero-icon { font-size: 40px; margin-bottom: 8px; }
      .hazard-hero-title {
        font-family: var(--font-title);
        font-size: 22px; font-weight: 900; letter-spacing: 3px;
        text-transform: uppercase; color: #fff; margin-bottom: 4px;
      }
      .hazard-hero-sub { font-size: 12px; color: var(--muted); letter-spacing: 1px; }

      /* ── Grid of cards ── */
      .hazard-grid-list {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
        gap: 14px; padding: 0 8px;
      }
      .hazard-card {
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,200,50,0.12);
        border-radius: 14px; overflow: hidden;
        transition: border-color 0.2s, background 0.2s, transform 0.15s;
      }
      .hazard-card:hover {
        background: rgba(255,200,50,0.04);
        border-color: rgba(255,200,50,0.28);
        transform: translateY(-2px);
      }
      .hazard-card-header {
        display: flex; align-items: center; gap: 10px;
        padding: 12px 14px 10px;
        border-bottom: 1px solid rgba(255,200,50,0.08);
      }
      .hazard-npc-icon {
        width: 34px; height: 34px; border-radius: 50%;
        background: rgba(255,200,50,0.12);
        border: 1.5px solid rgba(255,200,50,0.3);
        display: flex; align-items: center; justify-content: center;
        font-size: 16px; flex-shrink: 0;
      }
      .hazard-npc-name {
        font-family: var(--font-title);
        font-size: 15px; font-weight: 700; letter-spacing: 1.5px;
        text-transform: uppercase; color: #ffe066; flex: 1;
      }
      .hazard-map-btn {
        display: inline-flex; align-items: center; gap: 5px;
        font-family: var(--font-mono, monospace);
        font-size: 10px; font-weight: 700; letter-spacing: 0.5px;
        text-transform: uppercase; color: #60c0ff;
        background: rgba(96,192,255,0.1);
        border: 1px solid rgba(96,192,255,0.25);
        border-radius: 6px; padding: 5px 9px;
        cursor: pointer; white-space: nowrap;
        transition: background 0.15s, border-color 0.15s, transform 0.1s;
      }
      .hazard-map-btn:hover {
        background: rgba(96,192,255,0.2);
        border-color: rgba(96,192,255,0.5);
        transform: scale(1.04);
      }
      .hazard-poke-list {
        display: flex; flex-wrap: wrap; gap: 8px;
        padding: 12px 14px 14px;
      }
      .hazard-poke-chip {
        display: flex; flex-direction: column; align-items: center; gap: 3px;
        background: rgba(255,255,255,0.04);
        border: 1px solid rgba(255,255,255,0.07);
        border-radius: 10px; padding: 8px 10px 6px; min-width: 64px;
        transition: background 0.15s, border-color 0.15s;
      }
      .hazard-poke-chip:hover { background: rgba(255,220,80,0.07); border-color: rgba(255,220,80,0.2); }
      .hazard-poke-sprite { width: 48px; height: 48px; object-fit: contain; image-rendering: pixelated; }
      .hazard-poke-name {
        font-size: 10px; font-weight: 700; color: #ffe066;
        text-align: center; letter-spacing: 0.3px; line-height: 1.2;
      }
      .hazard-poke-qty {
        font-family: var(--font-mono, monospace);
        font-size: 11px; font-weight: 900;
        color: rgba(255,255,255,0.5);
        background: rgba(255,255,255,0.06);
        border-radius: 5px; padding: 1px 6px;
      }

      /* ── Map Modal ── */
      #hazard-map-modal {
        position: fixed; inset: 0; z-index: 9000;
        display: flex; align-items: center; justify-content: center;
        animation: hzFadeIn 0.2s ease;
      }
      @keyframes hzFadeIn { from { opacity: 0; } to { opacity: 1; } }
      .hzmap-backdrop {
        position: absolute; inset: 0;
        background: rgba(0,0,0,0.75);
        backdrop-filter: blur(6px);
        -webkit-backdrop-filter: blur(6px);
      }
      .hzmap-panel {
        position: relative; z-index: 1;
        width: min(1100px, 96vw);
        max-height: 92vh;
        display: flex; flex-direction: column;
        background: #0c1424;
        border: 1px solid rgba(255,200,50,0.25);
        border-radius: 16px; overflow: hidden;
        box-shadow: 0 24px 80px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,200,50,0.08);
        animation: hzSlideUp 0.25s cubic-bezier(0.16,1,0.3,1);
      }
      @keyframes hzSlideUp {
        from { transform: translateY(28px) scale(0.97); opacity: 0; }
        to   { transform: translateY(0)    scale(1);    opacity: 1; }
      }
      .hzmap-header {
        display: flex; align-items: center; justify-content: space-between;
        padding: 14px 18px;
        border-bottom: 1px solid rgba(255,200,50,0.12);
        background: rgba(255,200,50,0.04);
      }
      .hzmap-title {
        display: flex; align-items: center; gap: 8px;
        font-family: var(--font-title);
        font-size: 14px; font-weight: 700; letter-spacing: 1.5px;
        text-transform: uppercase; color: #ffe066;
      }
      .hzmap-title-icon { font-size: 18px; }
      .hzmap-close {
        background: rgba(255,255,255,0.06);
        border: 1px solid rgba(255,255,255,0.12);
        color: #fff; border-radius: 8px;
        width: 30px; height: 30px;
        display: flex; align-items: center; justify-content: center;
        font-size: 14px; cursor: pointer;
        transition: background 0.15s;
      }
      .hzmap-close:hover { background: rgba(255,80,80,0.2); border-color: rgba(255,80,80,0.4); }
      .hzmap-body {
        position: relative;
        flex: 1;
        min-height: 65vh;
        background: #070d1a;
        display: flex; align-items: center; justify-content: center;
        overflow: hidden;
      }
      .hzmap-loading {
        position: absolute;
        font-family: var(--font-mono, monospace);
        font-size: 12px; color: var(--muted); letter-spacing: 1px;
      }
      .hzmap-img {
        width: 100%; height: 100%;
        object-fit: contain;
        display: block;
      }
      .hzmap-iframe {
        position: absolute; inset: 0;
        width: 100%; height: 100%;
        border: none;
      }
      }
      .hzmap-footer {
        padding: 10px 18px;
        border-top: 1px solid rgba(255,255,255,0.05);
        display: flex; justify-content: flex-end;
      }
      .hzmap-ext-link {
        display: inline-flex; align-items: center; gap: 5px;
        font-family: var(--font-mono, monospace);
        font-size: 10px; font-weight: 700;
        text-transform: uppercase; letter-spacing: 0.5px;
        color: rgba(255,255,255,0.35);
        text-decoration: none;
        transition: color 0.15s;
      }
      .hzmap-ext-link:hover { color: rgba(255,255,255,0.7); }
    `;
    document.head.appendChild(s);
  }

  grid.innerHTML =
    '<div class="hazard-page">' +
      '<div class="hazard-hero">' +
        '<div class="hazard-hero-icon">⚠️</div>' +
        '<div class="hazard-hero-title">Hazard Tasks</div>' +
        '<div class="hazard-hero-sub">NPCs que entregam tasks de Shinys — clique em "Ver Mapa" para ver a localização do NPC</div>' +
      '</div>' +
      '<div class="hazard-grid-list">' +
        filtered.map(function(h) {
          var entries = parseHazardTask(h.task);
          var chips = entries.map(function(e) {
            var sprite = getShowdownSpriteHazard(e.name);
            var fallback = 'https://play.pokemonshowdown.com/sprites/gen5/substitute.png';
            return '<div class="hazard-poke-chip">' +
              '<img class="hazard-poke-sprite" src="' + sprite + '" alt="' + e.name + '" loading="lazy" ' +
                'onerror="this.src=\'' + fallback + '\';this.onerror=null;" />' +
              '<div class="hazard-poke-name">' + e.name + '</div>' +
              '<div class="hazard-poke-qty">×' + e.qty + '</div>' +
            '</div>';
          }).join('');

          return '<div class="hazard-card">' +
            '<div class="hazard-card-header">' +
              '<div class="hazard-npc-icon">🧑</div>' +
              '<div class="hazard-npc-name">' + h.npc + '</div>' +
              '<button class="hazard-map-btn" onclick="openHazardMapModal(\'' + h.npc + '\',\'' + h.imgId + '\')">' +
                '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">' +
                  '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>' +
                  '<circle cx="12" cy="10" r="3"/>' +
                '</svg>' +
                'Ver Mapa' +
              '</button>' +
            '</div>' +
            '<div class="hazard-poke-list">' + chips + '</div>' +
          '</div>';
        }).join('') +
      '</div>' +
    '</div>';
}

// ===================== WIKI: STAR CALCULATION =====================
function renderStarCalc() {
  var el = document.getElementById('wiki-starcalc-content');
  if (!el) return;

  // ── Dados por tier ─────────────────────────────────────────────
  var TIERS = [
    {
      id: 't3', label: 'Tier 3', icon: '🔵', color: '#3a8cff',
      dmgBonus: '2% por nível de estrela',
      steps: [
        { from: 0, to: 1, dd: 4,   kk: 1,    pokes: 1  },
        { from: 1, to: 2, dd: 12,  kk: 3,    pokes: 2  },
        { from: 2, to: 3, dd: 28,  kk: 7,    pokes: 4  },
        { from: 3, to: 4, dd: 60,  kk: 15,   pokes: 8  },
        { from: 4, to: 5, dd: 124, kk: 31,   pokes: 16 },
      ],
      total: { dd: 228, kk: 57, pokes: 31 }
    },
    {
      id: 't2', label: 'Tier 2', icon: '🟢', color: '#22c55e',
      dmgBonus: '4% por nível de estrela',
      steps: [
        { from: 0, to: 1, dd: 6,   kk: 1.5,  pokes: 1  },
        { from: 1, to: 2, dd: 18,  kk: 4.5,  pokes: 2  },
        { from: 2, to: 3, dd: 42,  kk: 10.5, pokes: 4  },
        { from: 3, to: 4, dd: 90,  kk: 22.5, pokes: 8  },
        { from: 4, to: 5, dd: 186, kk: 46.5, pokes: 16 },
      ],
      total: { dd: 342, kk: 85.5, pokes: 31 }
    },
    {
      id: 't1', label: 'Tier 1', icon: '🟡', color: '#fbbf24',
      dmgBonus: '6% por nível de estrela',
      steps: [
        { from: 0, to: 1, dd: 12,  kk: 3,    pokes: 1  },
        { from: 1, to: 2, dd: 36,  kk: 9,    pokes: 2  },
        { from: 2, to: 3, dd: 84,  kk: 21,   pokes: 4  },
        { from: 3, to: 4, dd: 180, kk: 45,   pokes: 8  },
        { from: 4, to: 5, dd: 372, kk: 93,   pokes: 16 },
      ],
      total: { dd: 684, kk: 171, pokes: 31 }
    },
    {
      id: 'sr', label: 'Super Raro', icon: '🟣', color: '#a855f7',
      dmgBonus: '8% por nível de estrela',
      steps: [
        { from: 0, to: 1, dd: 16,  kk: 4,    pokes: 1  },
        { from: 1, to: 2, dd: 48,  kk: 12,   pokes: 2  },
        { from: 2, to: 3, dd: 112, kk: 28,   pokes: 4  },
        { from: 3, to: 4, dd: 240, kk: 60,   pokes: 8  },
        { from: 4, to: 5, dd: 496, kk: 124,  pokes: 16 },
      ],
      total: { dd: 912, kk: 228, pokes: 31 }
    },
    {
      id: 'ur', label: 'Ultra Raro', icon: '🔴', color: '#ef4444',
      dmgBonus: '10% por nível de estrela',
      steps: [
        { from: 0, to: 1, dd: 24,  kk: 6,    pokes: 1  },
        { from: 1, to: 2, dd: 72,  kk: 18,   pokes: 2  },
        { from: 2, to: 3, dd: 168, kk: 42,   pokes: 4  },
        { from: 3, to: 4, dd: 360, kk: 90,   pokes: 8  },
        { from: 4, to: 5, dd: 744, kk: 186,  pokes: 16 },
      ],
      total: { dd: 1368, kk: 342, pokes: 31 }
    },
    {
      id: 'lg', label: 'Legendary', icon: '🌟', color: '#f59e0b',
      dmgBonus: '15% por nível de estrela',
      steps: [
        { from: 0, to: 1, dd: 48,  kk: 12,   pokes: 1  },
        { from: 1, to: 2, dd: 144, kk: 36,   pokes: 2  },
        { from: 2, to: 3, dd: 336, kk: 84,   pokes: 4  },
        { from: 3, to: 4, dd: 720, kk: 180,  pokes: 8  },
        { from: 4, to: 5, dd: 1488,kk: 372,  pokes: 16 },
      ],
      total: { dd: 2736, kk: 684, pokes: 31 }
    },
  ];

  var STAR_ICONS = ['☆','★','★★','★★★','★★★★','★★★★★'];

  // ── Calculadora interativa ──────────────────────────────────────
  function calcCost(tier, fromStar, toStar) {
    var dd = 0, kk = 0, pokes = 0;
    for (var i = fromStar; i < toStar; i++) {
      var step = tier.steps[i];
      dd += step.dd; kk += step.kk; pokes += step.pokes;
    }
    return { dd: dd, kk: kk, pokes: pokes };
  }

  // ── Build HTML ──────────────────────────────────────────────────
  var tiersHtml = TIERS.map(function(tier) {
    var stepsHtml = tier.steps.map(function(s) {
      return '<tr>' +
        '<td><span class="sc-star-from">' + STAR_ICONS[s.from] + ' ' + s.from + '</span></td>' +
        '<td><span class="sc-arrow">→</span></td>' +
        '<td><span class="sc-star-to">' + STAR_ICONS[s.to] + ' ' + s.to + '</span></td>' +
        '<td><span class="sc-dd">💎 ' + s.dd + ' DD</span></td>' +
        '<td><span class="sc-kk">🍀 ' + s.kk + ' KK</span></td>' +
        '<td><span class="sc-pokes">🐾 ' + s.pokes + ' Poke' + (s.pokes > 1 ? 's' : '') + '</span></td>' +
      '</tr>';
    }).join('');

    return '<div class="sc-tier-card" id="sc-card-' + tier.id + '">' +
      '<div class="sc-tier-header" style="border-left:4px solid ' + tier.color + '">' +
        '<div class="sc-tier-title">' +
          '<span class="sc-tier-icon">' + tier.icon + '</span>' +
          '<span class="sc-tier-name" style="color:' + tier.color + '">' + tier.label + '</span>' +
        '</div>' +
        '<div class="sc-tier-dmg">+' + tier.dmgBonus + '</div>' +
      '</div>' +
      '<div class="sc-tier-body">' +
        '<table class="sc-steps-table">' +
          '<thead><tr>' +
            '<th colspan="3">Evolução</th>' +
            '<th>💎 DD</th>' +
            '<th>🍀 KK</th>' +
            '<th>🐾 Pokémons</th>' +
          '</tr></thead>' +
          '<tbody>' + stepsHtml + '</tbody>' +
          '<tfoot><tr class="sc-total-row">' +
            '<td colspan="3"><strong>Total 0 → 5 ★</strong></td>' +
            '<td><strong>💎 ' + tier.total.dd + '</strong></td>' +
            '<td><strong>🍀 ' + tier.total.kk + '</strong></td>' +
            '<td><strong>🐾 ' + tier.total.pokes + ' Pokémons</strong></td>' +
          '</tr></tfoot>' +
        '</table>' +
      '</div>' +
    '</div>';
  }).join('');

  // Options for dropdowns
  var tierOpts = TIERS.map(function(t) {
    return '<option value="' + t.id + '">' + t.icon + ' ' + t.label + '</option>';
  }).join('');

  var starOpts = function(selected, minVal) {
    minVal = minVal || 0;
    return [0,1,2,3,4,5].filter(function(n){ return n >= minVal; }).map(function(n) {
      var icon = n === 0 ? '☆ 0' : STAR_ICONS[n] + ' ' + n;
      return '<option value="' + n + '"' + (n === selected ? ' selected' : '') + '>' + icon + ' \u2605</option>';
    }).join('');
  };

  el.innerHTML = `
  <style>
  .sc-page { padding: 20px 24px 40px; max-width: 900px; margin: 0 auto; }

  /* Hero */
  .sc-hero { text-align:center; padding: 28px 20px 20px; margin-bottom: 28px; }
  .sc-hero-icon { font-size: 42px; margin-bottom: 10px; }
  .sc-hero-title { font-family: var(--font-title); font-size: 22px; font-weight: 700; color: #fff; letter-spacing: 1.5px; margin-bottom: 6px; }
  .sc-hero-sub { font-size: 13px; color: var(--muted); }

  /* Calculator */
  .sc-calculator {
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,209,102,0.2);
    border-radius: 16px;
    padding: 20px 24px;
    margin-bottom: 32px;
  }
  .sc-calc-title {
    font-family: var(--font-title);
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: var(--gold);
    margin-bottom: 16px;
    display: flex; align-items: center; gap: 8px;
  }
  .sc-calc-fields {
    display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end; margin-bottom: 16px;
  }
  .sc-calc-field { display: flex; flex-direction: column; gap: 5px; flex: 1; min-width: 120px; }
  .sc-calc-field label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.8px; color: var(--muted); }
  .sc-calc-field select {
    background: #1a2340;
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 8px;
    color: #fff;
    font-family: var(--font-body);
    font-size: 13px;
    padding: 8px 10px;
    cursor: pointer;
    outline: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23aaa' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 10px center;
    padding-right: 30px;
  }
  .sc-calc-field select option {
    background: #1a2340;
    color: #fff;
  }
  .sc-calc-field select:focus { border-color: var(--gold); background-color: #1a2340; }
  .sc-calc-btn {
    background: linear-gradient(135deg, rgba(255,209,102,0.2), rgba(255,209,102,0.08));
    border: 1px solid rgba(255,209,102,0.4);
    border-radius: 8px;
    color: var(--gold);
    font-family: var(--font-title);
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 1px;
    padding: 9px 20px;
    cursor: pointer;
    transition: all 0.2s;
    white-space: nowrap;
  }
  .sc-calc-btn:hover { background: rgba(255,209,102,0.18); border-color: var(--gold); }
  .sc-calc-result {
    display: none;
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 12px;
    padding: 16px 20px;
    margin-top: 4px;
  }
  .sc-calc-result.visible { display: flex; gap: 20px; flex-wrap: wrap; }
  .sc-calc-result-label {
    width: 100%;
    font-size: 12px;
    color: var(--muted);
    margin-bottom: 4px;
    font-family: var(--font-mono, monospace);
  }
  .sc-calc-result-item {
    display: flex; flex-direction: column; gap: 2px;
    background: rgba(255,255,255,0.04);
    border-radius: 8px;
    padding: 10px 16px;
    flex: 1; min-width: 80px; text-align: center;
  }
  .sc-calc-result-val { font-size: 20px; font-weight: 900; font-family: var(--font-mono, monospace); color: #fff; }
  .sc-calc-result-sub { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.6px; }
  .sc-calc-result-val.dd { color: #60d0ff; }
  .sc-calc-result-val.kk { color: #4ade80; }
  .sc-calc-result-val.poke { color: #f472b6; }

  /* Notes */
  .sc-notes {
    background: rgba(58,140,255,0.07);
    border: 1px solid rgba(58,140,255,0.2);
    border-radius: 12px;
    padding: 14px 18px;
    margin-bottom: 28px;
    font-size: 12px;
    color: rgba(255,255,255,0.7);
    line-height: 1.7;
  }
  .sc-notes strong { color: #fff; }

  /* Tier cards */
  .sc-tier-card {
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.07);
    border-radius: 14px;
    margin-bottom: 20px;
    overflow: hidden;
  }
  .sc-tier-header {
    display: flex; justify-content: space-between; align-items: center;
    padding: 14px 18px;
    background: rgba(255,255,255,0.03);
    border-bottom: 1px solid rgba(255,255,255,0.06);
  }
  .sc-tier-title { display: flex; align-items: center; gap: 10px; }
  .sc-tier-icon { font-size: 20px; }
  .sc-tier-name { font-family: var(--font-title); font-size: 15px; font-weight: 700; letter-spacing: 1px; }
  .sc-tier-dmg { font-size: 11px; color: var(--muted); font-family: var(--font-mono, monospace); }
  .sc-tier-body { padding: 0; overflow-x: auto; }

  /* Table */
  .sc-steps-table { width: 100%; border-collapse: collapse; font-size: 13px; }
  .sc-steps-table th {
    padding: 9px 12px;
    text-align: left;
    font-size: 10px;
    font-family: var(--font-title);
    letter-spacing: 1px;
    text-transform: uppercase;
    color: var(--muted);
    border-bottom: 1px solid rgba(255,255,255,0.06);
  }
  .sc-steps-table td { padding: 10px 12px; border-bottom: 1px solid rgba(255,255,255,0.04); }
  .sc-steps-table tbody tr:hover { background: rgba(255,255,255,0.03); }
  .sc-steps-table tfoot tr { background: rgba(255,255,255,0.04); }
  .sc-steps-table tfoot td { border-top: 1px solid rgba(255,255,255,0.1); border-bottom: none; padding: 12px; }
  .sc-star-from { color: var(--muted); font-family: var(--font-mono, monospace); font-size: 12px; }
  .sc-star-to { color: #fff; font-family: var(--font-mono, monospace); font-size: 12px; }
  .sc-arrow { color: rgba(255,255,255,0.3); font-size: 12px; }
  .sc-dd { color: #60d0ff; font-family: var(--font-mono, monospace); font-size: 12px; white-space: nowrap; }
  .sc-kk { color: #4ade80; font-family: var(--font-mono, monospace); font-size: 12px; white-space: nowrap; }
  .sc-pokes { color: #f472b6; font-family: var(--font-mono, monospace); font-size: 12px; white-space: nowrap; }
  .sc-total-row td { font-size: 12px; }
  .sc-total-row strong { color: #fff; }

  /* Pattern note */
  .sc-pattern {
    background: rgba(168,85,247,0.07);
    border: 1px solid rgba(168,85,247,0.2);
    border-radius: 12px;
    padding: 14px 18px;
    margin-top: 28px;
    font-size: 12px;
    color: rgba(255,255,255,0.7);
    line-height: 1.7;
  }
  .sc-pattern-title { font-family: var(--font-title); font-size: 12px; font-weight: 700; color: #c084fc; letter-spacing: 1px; margin-bottom: 8px; }

  @media (max-width: 600px) {
    .sc-page { padding: 14px 12px 40px; }
    .sc-steps-table th, .sc-steps-table td { padding: 8px 8px; }
  }
  </style>
  <div class="sc-page">

    <!-- Hero -->
    <div class="sc-hero">
      <div class="sc-hero-icon">⭐</div>
      <div class="sc-hero-title">Star Calculation</div>
      <div class="sc-hero-sub">Calculadora de custos para evolução de estrelas — 100% de sucesso</div>
    </div>

    <!-- Calculadora -->
    <div class="sc-calculator">
      <div class="sc-calc-title">⚡ Calculadora Rápida</div>
      <div class="sc-calc-fields">
        <div class="sc-calc-field">
          <label>Tier</label>
          <select id="sc-sel-tier">${tierOpts}</select>
        </div>
        <div class="sc-calc-field">
          <label>Star Atual</label>
          <select id="sc-sel-from" onchange="updateStarToOpts()">${starOpts(0)}</select>
        </div>
        <div class="sc-calc-field">
          <label>Star Objetivo</label>
          <select id="sc-sel-to">${starOpts(5, 1)}</select>
        </div>
        <button class="sc-calc-btn" onclick="runStarCalc()">Calcular</button>
      </div>
      <div class="sc-calc-result" id="sc-result">
        <div class="sc-calc-result-label" id="sc-result-label"></div>
        <div class="sc-calc-result-item">
          <span class="sc-calc-result-val dd" id="sc-res-dd">—</span>
          <span class="sc-calc-result-sub">💎 Diamond Dust</span>
        </div>
        <div class="sc-calc-result-item">
          <span class="sc-calc-result-val kk" id="sc-res-kk">—</span>
          <span class="sc-calc-result-sub">🍀 KK</span>
        </div>
        <div class="sc-calc-result-item">
          <span class="sc-calc-result-val poke" id="sc-res-pokes">—</span>
          <span class="sc-calc-result-sub">🐾 Pokémons Iguais</span>
        </div>
      </div>
    </div>

    <!-- Notas -->
    <div class="sc-notes">
      ⚠️ <strong>Valores considerando 100% de sucesso.</strong> &nbsp;•&nbsp;
      A <strong>proporção DD → KK</strong> é sempre 4:1. &nbsp;•&nbsp;
      Os <strong>Pokémons necessários</strong> (0→5★) são sempre <strong>31</strong> independente do tier. &nbsp;•&nbsp;
      Cada step custa o dobro do anterior + o custo base do tier. &nbsp;•&nbsp;
      <strong>Legendary</strong> aumenta 15% de dano por estrela.
    </div>

    <!-- Cards por tier -->
    ${tiersHtml}

    <!-- Padrão explicado -->
    <div class="sc-pattern">
      <div class="sc-pattern-title">🔍 O padrão dos custos</div>
      Sim, existe um padrão! O custo base de DD por step é fixo para cada tier:<br><br>
      <strong>T3</strong> = base 4 DD &nbsp;|&nbsp; <strong>T2</strong> = base 6 DD &nbsp;|&nbsp; <strong>T1</strong> = base 12 DD &nbsp;|&nbsp; <strong>SR</strong> = base 16 DD &nbsp;|&nbsp; <strong>UR</strong> = base 24 DD &nbsp;|&nbsp; <strong>Legendary</strong> = base 48 DD<br><br>
      Dentro de cada tier, os steps seguem a fórmula: <strong>custo_step(n) = base × (2ⁿ⁻¹ × 4 - custo_step_anterior_acumulado... simplificando: 4, 12, 28, 60, 124</strong> — cada valor é ~2× o anterior + base.<br><br>
      A proporção <strong>DD ÷ KK = 4:1</strong> é constante em todos os tiers e steps.
    </div>

  </div>
  `;
}

function runStarCalc() {
  var tierSel = document.getElementById('sc-sel-tier');
  var fromSel = document.getElementById('sc-sel-from');
  var toSel   = document.getElementById('sc-sel-to');
  if (!tierSel || !fromSel || !toSel) return;

  var tierId  = tierSel.value;
  var fromStar = parseInt(fromSel.value);
  var toStar   = parseInt(toSel.value);

  var TIERS_MAP = {
    t3:  { label:'Tier 3',    steps: [{dd:4,kk:1,pokes:1},{dd:12,kk:3,pokes:2},{dd:28,kk:7,pokes:4},{dd:60,kk:15,pokes:8},{dd:124,kk:31,pokes:16}] },
    t2:  { label:'Tier 2',    steps: [{dd:6,kk:1.5,pokes:1},{dd:18,kk:4.5,pokes:2},{dd:42,kk:10.5,pokes:4},{dd:90,kk:22.5,pokes:8},{dd:186,kk:46.5,pokes:16}] },
    t1:  { label:'Tier 1',    steps: [{dd:12,kk:3,pokes:1},{dd:36,kk:9,pokes:2},{dd:84,kk:21,pokes:4},{dd:180,kk:45,pokes:8},{dd:372,kk:93,pokes:16}] },
    sr:  { label:'Super Raro',steps: [{dd:16,kk:4,pokes:1},{dd:48,kk:12,pokes:2},{dd:112,kk:28,pokes:4},{dd:240,kk:60,pokes:8},{dd:496,kk:124,pokes:16}] },
    ur:  { label:'Ultra Raro', steps: [{dd:24,kk:6,pokes:1},{dd:72,kk:18,pokes:2},{dd:168,kk:42,pokes:4},{dd:360,kk:90,pokes:8},{dd:744,kk:186,pokes:16}] },
    lg:  { label:'Legendary',  steps: [{dd:48,kk:12,pokes:1},{dd:144,kk:36,pokes:2},{dd:336,kk:84,pokes:4},{dd:720,kk:180,pokes:8},{dd:1488,kk:372,pokes:16}] },
  };

  var tier = TIERS_MAP[tierId];
  var res = document.getElementById('sc-result');
  var resLabel = document.getElementById('sc-result-label');

  if (!tier || fromStar >= toStar) {
    res.classList.remove('visible');
    res.classList.add('visible');
    res.style.background = 'rgba(255,80,80,0.08)';
    res.style.border = '1px solid rgba(255,80,80,0.25)';
    resLabel.textContent = fromStar >= toStar
      ? '⚠️ Star Objetivo deve ser maior que Star Atual!'
      : '⚠️ Tier inválido.';
    document.getElementById('sc-res-dd').textContent    = '—';
    document.getElementById('sc-res-kk').textContent    = '—';
    document.getElementById('sc-res-pokes').textContent = '—';
    return;
  }

  res.style.background = '';
  res.style.border = '';

  var dd = 0, kk = 0, pokes = 0;
  for (var i = fromStar; i < toStar; i++) {
    var s = tier.steps[i];
    dd += s.dd; kk += s.kk; pokes += s.pokes;
  }

  var STAR_ICONS = ['☆','★','★★','★★★','★★★★','★★★★★'];
  resLabel.textContent =
    tier.label + ' — ' + fromStar + '★ → ' + toStar + '★';
  document.getElementById('sc-res-dd').textContent = dd + ' DD';
  document.getElementById('sc-res-kk').textContent = kk + ' KK';
  document.getElementById('sc-res-pokes').textContent = pokes + ' Pokémon' + (pokes > 1 ? 's' : '');
  res.classList.add('visible');
}
// Atualiza as opções do select "Star Objetivo" para sempre ser > Star Atual
function updateStarToOpts() {
  var fromSel = document.getElementById('sc-sel-from');
  var toSel   = document.getElementById('sc-sel-to');
  if (!fromSel || !toSel) return;
  var fromVal = parseInt(fromSel.value);
  var currentTo = parseInt(toSel.value);
  var STAR_ICONS = ['☆','★','★★','★★★','★★★★','★★★★★'];
  var opts = '';
  for (var n = fromVal + 1; n <= 5; n++) {
    var isSelected = (currentTo > fromVal && n === currentTo) || (currentTo <= fromVal && n === fromVal + 1);
    opts += '<option value="' + n + '"' + (isSelected ? ' selected' : '') + '>' + (n === 0 ? '☆ 0' : STAR_ICONS[n] + ' ' + n) + ' ★</option>';
  }
  toSel.innerHTML = opts;
}

// ===================== WIKI: PUNCHING BAG =====================
function renderPunchingBag() {
  var el = document.getElementById('wiki-punchingbag-content');
  if (!el || el._pbRendered) return;
  el._pbRendered = true;

  var STATS = [
    { icon: '⚔️', name: 'Attack',        key: 'atk',   perLvl: 0.1  },
    { icon: '🛡️', name: 'Defense',       key: 'def',   perLvl: 0.05 },
    { icon: '❤️', name: 'HP',            key: 'hp',    perLvl: 0.1  },
    { icon: '🎯', name: 'Precisão',      key: 'prec',  perLvl: 0.2  },
    { icon: '💨', name: 'Evasão',        key: 'eva',   perLvl: 0.2  },
    { icon: '💥', name: 'Critical DMG',  key: 'cdmg',  perLvl: 0.1  },
    { icon: '🍀', name: 'Critical Chance',key: 'cchance',perLvl: 0.1  },
    { icon: '🔰', name: 'Critical Res',  key: 'cres',  perLvl: 0.1  },
  ];

  var BAGS = [
    { icon: '🥊', name: 'Punching Bag (Solo)',   pokeMin: 1, pokeMax: 1, desc: 'Versão básica. Comporta apenas 1 Pokémon por vez. Mais lento.' },
    { icon: '👊', name: 'Punching Bag (2 Pokes)', pokeMin: 2, pokeMax: 2, desc: 'Treina 2 Pokémons simultaneamente. Consome cargas 2× mais rápido.' },
    { icon: '💪', name: 'Punching Bag (3 Pokes)', pokeMin: 3, pokeMax: 3, desc: 'Treina 3 Pokémons simultaneamente. Consome cargas 3× mais rápido.' },
    { icon: '🏋️', name: 'Punching Bag (4 Pokes)', pokeMin: 4, pokeMax: 4, desc: 'Capacidade máxima. Treina 4 Pokémons ao mesmo tempo. Treino máximo!' },
  ];

  el.innerHTML = `
  <div class="pb-page">

    <!-- Hero -->
    <div class="pb-hero">
      <div class="pb-hero-icon">🥊</div>
      <div class="pb-hero-title">Punching Bag</div>
      <div class="pb-hero-sub">Sistema de treinamento de atributos para seus Pokémons</div>
    </div>

    <!-- Como funciona -->
    <div class="pb-howto">
      <div class="pb-howto-title">📖 Como treinar um Pokémon</div>
      <div class="pb-steps-list">
        <div class="pb-step">
          <div class="pb-step-num">1</div>
          <div>Compre o <strong>dummy (Punching Bag)</strong> e as <strong>cargas</strong> na store (por <span class="pb-tag-dd">DDs</span>), ou com a NPC <strong>July</strong> no TC (por <span class="pb-tag-kk">KKs</span>).</div>
        </div>
        <div class="pb-step">
          <div class="pb-step-num">2</div>
          <div>Coloque o <strong>dummy na sua house</strong> — ele precisa de bastante espaço!</div>
        </div>
        <div class="pb-step">
          <div class="pb-step-num">3</div>
          <div>Adicione as <strong>cargas</strong> ao dummy e coloque o <strong>Pokémon</strong> nele para iniciar o treino.</div>
        </div>
        <div class="pb-step">
          <div class="pb-step-num">4</div>
          <div>Para ver os stats treinados: <strong>Ctrl + clique</strong> na Pokéball → <strong>Customize</strong>.</div>
        </div>
      </div>
      <div class="pb-tip-box">
        💡 <span>Cada punching bag comporta entre <strong>1 e 4 Pokémons</strong> por vez. Quanto mais Pokémons, mais rápido as cargas são consumidas — mas o treino é simultâneo!</span>
      </div>
    </div>

    <!-- Bônus por nível -->
    <div class="pb-section">
      <div class="pb-section-title">📊 Bônus por nível de treinamento</div>
      <div class="pb-stats-grid">
        ${STATS.map(function(s) {
          return '<div class="pb-stat-card">' +
            '<div class="pb-stat-icon">' + s.icon + '</div>' +
            '<div class="pb-stat-name">' + s.name + '</div>' +
            '<div class="pb-stat-bonus">+' + s.perLvl + '%</div>' +
            '<div class="pb-stat-per-lvl">por nível</div>' +
          '</div>';
        }).join('')}
      </div>
    </div>

    <!-- Calculadora -->
    <div class="pb-section">
      <div class="pb-section-title">🧮 Calculadora de Bônus Acumulado</div>
      <div class="pb-calc-card">
        <div class="pb-calc-header">
          <div class="pb-calc-header-icon">⚡</div>
          <div class="pb-calc-header-text">Insira o nível de treinamento do seu Pokémon</div>
        </div>
        <div class="pb-calc-body">
          <div class="pb-calc-row">
            <div class="pb-calc-label">Nível atual</div>
            <div class="pb-level-input-wrap">
              <input type="number" id="pb-level-input" class="pb-level-input" min="0" max="1000" value="0"
                oninput="pbSyncSlider(this.value); pbCalc()" />
              <input type="range" id="pb-level-slider" class="pb-level-slider" min="0" max="500" value="0"
                oninput="pbSyncInput(this.value); pbCalc()" />
              <span class="pb-level-max">máx livre</span>
            </div>
          </div>
          <div class="pb-results-grid" id="pb-results">
            ${STATS.map(function(s) {
              return '<div class="pb-result-cell" id="pb-cell-' + s.key + '">' +
                '<div class="pb-result-icon">' + s.icon + '</div>' +
                '<div class="pb-result-name">' + s.name + '</div>' +
                '<div class="pb-result-val" id="pb-val-' + s.key + '">+0%</div>' +
                '<div class="pb-result-sub" id="pb-sub-' + s.key + '">nível 0</div>' +
              '</div>';
            }).join('')}
          </div>
        </div>
      </div>
    </div>

    <!-- Bags variants -->
    <div class="pb-section">
      <div class="pb-section-title">🥊 Tipos de Punching Bag</div>
      <div class="pb-bags-grid">
        ${BAGS.map(function(b) {
          return '<div class="pb-bag-card">' +
            '<div class="pb-bag-icon">' + b.icon + '</div>' +
            '<div class="pb-bag-name">' + b.name + '</div>' +
            '<div class="pb-bag-poke">' + (b.pokeMin === b.pokeMax ? b.pokeMin : b.pokeMin + '–' + b.pokeMax) + ' Pokémon' + (b.pokeMax > 1 ? 's' : '') + '</div>' +
            '<div class="pb-bag-desc">' + b.desc + '</div>' +
          '</div>';
        }).join('')}
      </div>
    </div>

  </div>
  `;

  // Store stats data for calculator
  el._pbStats = STATS;
  pbCalc();
}

function pbSyncSlider(val) {
  var slider = document.getElementById('pb-level-slider');
  if (slider) slider.value = Math.min(val, 500);
}

function pbSyncInput(val) {
  var input = document.getElementById('pb-level-input');
  if (input) input.value = val;
}

function pbCalc() {
  var el = document.getElementById('wiki-punchingbag-content');
  if (!el || !el._pbStats) return;
  var input = document.getElementById('pb-level-input');
  if (!input) return;
  var level = Math.max(0, parseInt(input.value) || 0);

  el._pbStats.forEach(function(s) {
    var bonus = (level * s.perLvl).toFixed(level * s.perLvl % 1 === 0 ? 0 : 2);
    var valEl  = document.getElementById('pb-val-' + s.key);
    var subEl  = document.getElementById('pb-sub-' + s.key);
    var cellEl = document.getElementById('pb-cell-' + s.key);
    if (valEl)  valEl.textContent  = '+' + bonus + '%';
    if (subEl)  subEl.textContent  = 'nível ' + level;
    if (cellEl) {
      if (level > 0) cellEl.classList.add('has-bonus');
      else cellEl.classList.remove('has-bonus');
    }
  });
}

// ===================== WIKI: ROUPAS DE SPEED =====================
function renderRoupasSpeed() {
  var el = document.getElementById('wiki-roupasspeed-content');
  if (!el) return;

  var roupas = [
    {
      id: 'ski',
      nome: 'Roupa de Ski',
      terreno: 'Neve',
      pergunta: 'Como ando mais rápido na neve?',
      pedra: 'Ice Stone',
      qtd: 3,
      cor: '#5bc8f5',
      corRgb: '91,200,245',
      emoji: '❄️',
      img: 'https://i.imgur.com/DjU6sM4.png',
      dica: 'Equipar esta roupa permite se mover mais rápido em terrenos cobertos de neve.',
      mapImg: null
    },
    {
      id: 'sandboard',
      nome: 'Sandboard',
      terreno: 'Areia',
      pergunta: 'Como ando mais rápido na areia?',
      pedra: 'Enigma Stone',
      qtd: 3,
      cor: '#e8b840',
      corRgb: '232,184,64',
      emoji: '🏜️',
      img: 'https://i.imgur.com/YUCTD6p.jpeg',
      dica: 'Equipar esta roupa permite deslizar rapidamente sobre terrenos arenosos.',
      mapImg: null
    },
    {
      id: 'mergulho',
      nome: 'Roupa de Mergulho',
      terreno: 'Água',
      pergunta: 'Como ando mais rápido na água?',
      pedra: 'Water Stone',
      qtd: 3,
      cor: '#4a9eff',
      corRgb: '74,158,255',
      emoji: '🌊',
      img: 'https://i.imgur.com/LbDx18X.png',
      dica: 'Equipar esta roupa permite nadar com velocidade elevada em rios, lagos e oceanos.',
      mapImg: null
    }
  ];

  // Inject CSS once
  if (!document.getElementById('rsp2-css')) {
    var s = document.createElement('style');
    s.id = 'rsp2-css';
    s.textContent = `
      /* ── Roupas Speed v2 — card style ── */
      .rsp2-page { max-width: 960px; margin: 0 auto; padding: 8px 0 60px; }

      .rsp2-hero { text-align: center; padding: 32px 20px 28px; }
      .rsp2-hero-icon { font-size: 52px; line-height: 1; margin-bottom: 10px; }
      .rsp2-hero-title {
        font-family: var(--font-title);
        font-size: 22px; font-weight: 900; letter-spacing: 3px;
        text-transform: uppercase; color: #fff; margin-bottom: 6px;
      }
      .rsp2-hero-sub { font-size: 12px; color: var(--muted); letter-spacing: 1px; }

      /* Grid of 3 cards */
      .rsp2-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
        gap: 16px;
        padding: 0 8px;
      }

      /* Individual card */
      .rsp2-card {
        background: rgba(255,255,255,0.025);
        border: 1.5px solid rgba(var(--rsp2-rgb), 0.15);
        border-radius: 16px; overflow: hidden;
        cursor: pointer;
        transition: border-color 0.2s, background 0.2s, transform 0.18s, box-shadow 0.2s;
        position: relative;
      }
      .rsp2-card::before {
        content: '';
        position: absolute; inset: 0;
        background: radial-gradient(ellipse at 50% -10%, rgba(var(--rsp2-rgb), 0.07), transparent 70%);
        pointer-events: none;
      }
      .rsp2-card:hover {
        border-color: rgba(var(--rsp2-rgb), 0.45);
        background: rgba(var(--rsp2-rgb), 0.04);
        transform: translateY(-3px);
        box-shadow: 0 8px 30px rgba(var(--rsp2-rgb), 0.12), 0 0 0 1px rgba(var(--rsp2-rgb), 0.08);
      }

      /* Card header */
      .rsp2-card-header {
        display: flex; align-items: center; gap: 10px;
        padding: 13px 15px 11px;
        border-bottom: 1px solid rgba(var(--rsp2-rgb), 0.1);
      }
      .rsp2-npc-icon {
        width: 36px; height: 36px; border-radius: 50%; flex-shrink: 0;
        background: rgba(var(--rsp2-rgb), 0.15);
        border: 1.5px solid rgba(var(--rsp2-rgb), 0.35);
        display: flex; align-items: center; justify-content: center;
        font-size: 18px;
      }
      .rsp2-card-name {
        font-family: var(--font-title);
        font-size: 14px; font-weight: 700; letter-spacing: 1.5px;
        text-transform: uppercase; color: var(--rsp2-cor); flex: 1;
      }
      .rsp2-map-btn {
        display: inline-flex; align-items: center; gap: 5px;
        font-family: var(--font-mono, monospace);
        font-size: 10px; font-weight: 700; letter-spacing: 0.5px;
        text-transform: uppercase; color: #60c0ff;
        background: rgba(96,192,255,0.1);
        border: 1px solid rgba(96,192,255,0.25);
        border-radius: 6px; padding: 5px 9px;
        cursor: pointer; white-space: nowrap;
        transition: background 0.15s, border-color 0.15s, transform 0.1s;
      }
      .rsp2-map-btn:hover {
        background: rgba(96,192,255,0.22);
        border-color: rgba(96,192,255,0.55);
        transform: scale(1.04);
      }

      /* Card image area */
      .rsp2-img-area {
        padding: 18px 18px 10px;
        display: flex; justify-content: center; align-items: center;
        background: rgba(0,0,0,0.15);
        min-height: 160px; position: relative; overflow: hidden;
      }
      .rsp2-img-glow {
        position: absolute; inset: 0;
        background: radial-gradient(ellipse at 50% 60%, rgba(var(--rsp2-rgb), 0.12), transparent 70%);
        pointer-events: none;
      }
      .rsp2-item-img {
        width: 120px; height: 120px; object-fit: contain;
        image-rendering: auto;
        position: relative; z-index: 1;
        filter: drop-shadow(0 0 12px rgba(var(--rsp2-rgb), 0.4));
        transition: transform 0.3s, filter 0.3s;
      }
      .rsp2-card:hover .rsp2-item-img {
        transform: scale(1.07) translateY(-4px);
        filter: drop-shadow(0 4px 18px rgba(var(--rsp2-rgb), 0.6));
      }

      /* Card info footer */
      .rsp2-card-info {
        padding: 12px 15px 16px;
        display: flex; flex-direction: column; gap: 10px;
      }
      .rsp2-terreno-row {
        display: flex; align-items: center; gap: 8px;
      }
      .rsp2-terreno-emoji { font-size: 22px; }
      .rsp2-terreno-label {
        font-size: 11px; font-weight: 700; letter-spacing: 1.5px;
        text-transform: uppercase; color: rgba(255,255,255,0.3);
      }
      .rsp2-terreno-name {
        font-family: var(--font-title);
        font-size: 15px; font-weight: 700; color: var(--rsp2-cor);
        margin-left: auto;
      }
      .rsp2-req-row {
        display: flex; align-items: center; gap: 10px;
        background: rgba(var(--rsp2-rgb), 0.07);
        border: 1px solid rgba(var(--rsp2-rgb), 0.18);
        border-radius: 10px; padding: 8px 12px;
      }
      .rsp2-req-num {
        font-family: var(--font-mono, monospace);
        font-size: 22px; font-weight: 900; color: var(--rsp2-cor); line-height: 1;
      }
      .rsp2-req-sep { width: 1px; height: 28px; background: rgba(var(--rsp2-rgb), 0.2); }
      .rsp2-req-text { flex: 1; }
      .rsp2-req-pedra {
        font-family: var(--font-title);
        font-size: 13px; font-weight: 700; color: #fff; margin-bottom: 2px;
      }
      .rsp2-req-hint {
        font-size: 10px; color: rgba(255,255,255,0.35); letter-spacing: 0.3px;
      }
      .rsp2-dica {
        font-size: 11px; color: rgba(255,255,255,0.38);
        font-style: italic; line-height: 1.6; border-top: 1px solid rgba(255,255,255,0.06);
        padding-top: 10px;
      }

      /* ── Map Modal (reuse hzmap style with rsp2 theme) ── */
      #rsp2-map-modal {
        position: fixed; inset: 0; z-index: 9000;
        display: flex; align-items: center; justify-content: center;
        animation: rsp2FadeIn 0.2s ease;
      }
      @keyframes rsp2FadeIn { from { opacity: 0; } to { opacity: 1; } }
      .rsp2-map-backdrop {
        position: absolute; inset: 0;
        background: rgba(0,0,0,0.78);
        backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
      }
      .rsp2-map-panel {
        position: relative; z-index: 1;
        width: min(1100px, 96vw); max-height: 92vh;
        display: flex; flex-direction: column;
        background: #0c1424;
        border: 1px solid rgba(var(--rsp2-modal-rgb, 255,220,80), 0.25);
        border-radius: 16px; overflow: hidden;
        box-shadow: 0 24px 80px rgba(0,0,0,0.75), 0 0 0 1px rgba(var(--rsp2-modal-rgb, 255,220,80), 0.08);
        animation: rsp2SlideUp 0.25s cubic-bezier(0.16,1,0.3,1);
      }
      @keyframes rsp2SlideUp {
        from { transform: translateY(28px) scale(0.97); opacity: 0; }
        to   { transform: translateY(0)    scale(1);    opacity: 1; }
      }
      .rsp2-map-header {
        display: flex; align-items: center; justify-content: space-between;
        padding: 14px 18px;
        border-bottom: 1px solid rgba(var(--rsp2-modal-rgb, 255,220,80), 0.12);
        background: rgba(var(--rsp2-modal-rgb, 255,220,80), 0.04);
      }
      .rsp2-map-title {
        display: flex; align-items: center; gap: 8px;
        font-family: var(--font-title);
        font-size: 14px; font-weight: 700; letter-spacing: 1.5px;
        text-transform: uppercase; color: var(--rsp2-modal-cor, #ffe066);
      }
      .rsp2-map-close {
        background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12);
        color: #fff; border-radius: 8px; width: 30px; height: 30px;
        display: flex; align-items: center; justify-content: center;
        font-size: 14px; cursor: pointer; transition: background 0.15s;
      }
      .rsp2-map-close:hover { background: rgba(255,80,80,0.2); border-color: rgba(255,80,80,0.4); }
      .rsp2-map-body {
        position: relative; flex: 1; min-height: 65vh;
        background: #070d1a;
        display: flex; align-items: center; justify-content: center; overflow: hidden;
      }
      .rsp2-map-loading {
        position: absolute;
        font-family: var(--font-mono, monospace);
        font-size: 12px; color: var(--muted); letter-spacing: 1px;
        pointer-events: none;
      }
      .rsp2-map-iframe {
        position: absolute; inset: 0; width: 100%; height: 100%;
        border: none; opacity: 0; transition: opacity 0.4s;
      }
      .rsp2-map-iframe.loaded { opacity: 1; }
      .rsp2-map-img {
        position: absolute; inset: 0; margin: auto;
        max-width: 100%; max-height: 100%;
        width: auto; height: auto;
        object-fit: contain;
        opacity: 0; transition: opacity 0.4s;
      }
      .rsp2-map-img.loaded { opacity: 1; }
      .rsp2-map-bg {
        position: absolute; inset: 0;
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
      }
      .rsp2-map-footer {
        padding: 10px 18px; border-top: 1px solid rgba(255,255,255,0.06);
        display: flex; align-items: center; gap: 10px;
        font-size: 11px; color: rgba(255,255,255,0.3);
        background: rgba(0,0,0,0.25);
      }

      @media(max-width:640px) { .rsp2-grid { grid-template-columns: 1fr; } }
    `;
    document.head.appendChild(s);
  }

  var html = '<div class="rsp2-page">';
  html += '<div class="rsp2-hero">';
  html += '  <div class="rsp2-hero-icon">🎽</div>';
  html += '  <div class="rsp2-hero-title">Roupas de Speed</div>';
  html += '  <div class="rsp2-hero-sub">Clique em "Ver Mapa" para localizar o NPC responsável</div>';
  html += '</div>';
  html += '<div class="rsp2-grid">';

  roupas.forEach(function(r) {
    html += '<div class="rsp2-card" style="--rsp2-rgb:' + r.corRgb + ';--rsp2-cor:' + r.cor + '">';

    // Header
    html += '<div class="rsp2-card-header">';
    html += '  <div class="rsp2-npc-icon">' + r.emoji + '</div>';
    html += '  <div class="rsp2-card-name">' + r.nome + '</div>';
    html += '  <button class="rsp2-map-btn" onclick="event.stopPropagation();openRsp2Map(\'' + r.id + '\')">';
    html += '    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>';
    html += '    VER MAPA';
    html += '  </button>';
    html += '</div>';

    // Image
    html += '<div class="rsp2-img-area">';
    html += '  <div class="rsp2-img-glow"></div>';
    html += '  <img class="rsp2-item-img" src="' + r.img + '" alt="' + r.nome + '" loading="lazy" onerror="this.style.display=\'none\'" />';
    html += '</div>';

    // Info
    html += '<div class="rsp2-card-info">';
    html += '  <div class="rsp2-terreno-row">';
    html += '    <span class="rsp2-terreno-emoji">' + r.emoji + '</span>';
    html += '    <span class="rsp2-terreno-label">Terreno</span>';
    html += '    <span class="rsp2-terreno-name">' + r.terreno + '</span>';
    html += '  </div>';
    html += '  <div class="rsp2-req-row">';
    html += '    <div class="rsp2-req-num">×' + r.qtd + '</div>';
    html += '    <div class="rsp2-req-sep"></div>';
    html += '    <div class="rsp2-req-text">';
    html += '      <div class="rsp2-req-pedra">' + r.pedra + '</div>';
    html += '      <div class="rsp2-req-hint">Entregar ao NPC responsável</div>';
    html += '    </div>';
    html += '  </div>';
    html += '  <div class="rsp2-dica">' + r.dica + '</div>';
    html += '</div>';

    html += '</div>'; // .rsp2-card
  });

  html += '</div>'; // .rsp2-grid
  html += '</div>'; // .rsp2-page
  el.innerHTML = html;
}

// Map data for each roupa (reuse hazard map system)
var RSP2_MAP_DATA = {
  ski:       { npc: 'NPC Neve',  img: 'https://i.imgur.com/DjU6sM4.png',  emoji: '❄️', cor: '#5bc8f5', rgb: '91,200,245',  label: 'Roupa de Ski' },
  sandboard: { npc: 'NPC Areia', img: 'https://i.imgur.com/YUCTD6p.jpeg', emoji: '🏜️', cor: '#e8b840', rgb: '232,184,64', label: 'Sandboard' },
  mergulho:  { npc: 'NPC Água',  img: 'https://i.imgur.com/LbDx18X.png',  emoji: '🌊', cor: '#4a9eff', rgb: '74,158,255',  label: 'Roupa de Mergulho' }
};

function openRsp2Map(id) {
  var existing = document.getElementById('rsp2-map-modal');
  if (existing) existing.remove();
  var data = RSP2_MAP_DATA[id] || { npc: id, img: null, emoji: '🗺️', cor: '#ffe066', rgb: '255,224,102', label: id };
  document.documentElement.style.setProperty('--rsp2-modal-rgb', data.rgb);
  document.documentElement.style.setProperty('--rsp2-modal-cor', data.cor);

  var bodyContent = data.img
    ? '<div class="rsp2-map-bg" style="background-image:url(\'' + data.img + '\')"></div>'
    : '<div style="font-family:var(--font-mono,monospace);font-size:13px;color:rgba(255,255,255,0.35);text-align:center;padding:40px;line-height:2">🗺️<br>Mapa ainda não cadastrado para este NPC.<br>Em breve!</div>';

  var modal = document.createElement('div');
  modal.id = 'rsp2-map-modal';
  modal.innerHTML =
    '<div class="rsp2-map-backdrop" onclick="document.getElementById(\'rsp2-map-modal\').remove()"></div>' +
    '<div class="rsp2-map-panel">' +
      '<div class="rsp2-map-header">' +
        '<div class="rsp2-map-title"><span>' + data.emoji + '</span><span>' + data.npc + '</span></div>' +
        '<button class="rsp2-map-close" onclick="document.getElementById(\'rsp2-map-modal\').remove()">✕</button>' +
      '</div>' +
      '<div class="rsp2-map-body">' + bodyContent + '</div>' +
      '<div class="rsp2-map-footer">' +
        '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/></svg>' +
        'Localização do NPC responsável pela ' + data.label +
      '</div>' +
    '</div>';

  document.body.appendChild(modal);
}

function toggleRspCard(id) {
  var card = document.getElementById('rsp-card-' + id);
  if (!card) return;
  var isOpen = card.classList.contains('open');
  document.querySelectorAll('.rsp-card.open').forEach(function(c) { c.classList.remove('open'); });
  if (!isOpen) card.classList.add('open');
}

// ===================== WIKI: POKETALENTS =====================
// Mapa tipo → { bannerUrl, iconUrl, color, rgb }
var TALENT_TYPE_META = {
  water:    { banner: 'https://i.imgur.com/zpRe43i.png', color: '#00aaff', rgb: '0,170,255',     emoji: '💧' },
  steel:    { banner: 'https://i.imgur.com/GleRjiM.png', color: '#ccddee', rgb: '204,221,238',   emoji: '⚙️' },
  rock:     { banner: 'https://i.imgur.com/GvD1Mtq.png', color: '#aa8855', rgb: '170,136,85',    emoji: '🪨' },
  psychic:  { banner: 'https://i.imgur.com/ASiZi1K.png', color: '#ff44bb', rgb: '255,68,187',    emoji: '🔮' },
  poison:   { banner: 'https://i.imgur.com/xfX0ReE.png', color: '#aa00cc', rgb: '170,0,204',     emoji: '☠️' },
  normal:   { banner: 'https://i.imgur.com/w2ChsIe.png', color: '#bbbbbb', rgb: '187,187,187',   emoji: '⭐' },
  ice:      { banner: 'https://i.imgur.com/ssFz0sA.png', color: '#80e8ff', rgb: '128,232,255',   emoji: '❄️' },
  ground:   { banner: 'https://i.imgur.com/JPcD2l3.png', color: '#cc8800', rgb: '204,136,0',     emoji: '🌍' },
  fire:     { banner: 'https://i.imgur.com/O8TONGE.png', color: '#ff6a00', rgb: '255,106,0',     emoji: '🔥' },
  grass:    { banner: 'https://i.imgur.com/YjKxtoE.png', color: '#44cc00', rgb: '68,204,0',      emoji: '🌿' },
  electric: { banner: 'https://i.imgur.com/Yv2WEYc.png', color: '#ffe600', rgb: '255,230,0',     emoji: '⚡' },
  dark:     { banner: 'https://i.imgur.com/7Luj4az.png', color: '#6666cc', rgb: '102,102,204',   emoji: '🌑' },
  dragon:   { banner: 'https://i.imgur.com/o7JWbaN.png', color: '#ffaa00', rgb: '255,170,0',     emoji: '🐉' },
  ghost:    { banner: 'https://i.imgur.com/HuybbPn.png', color: '#9900ff', rgb: '153,0,255',     emoji: '👻' },
  fairy:    { banner: 'https://i.imgur.com/j3HaXTh.png', color: '#ff66bb', rgb: '255,102,187',   emoji: '🌸' },
  flying:   { banner: 'https://i.imgur.com/npGjQae.png', color: '#aabbff', rgb: '170,187,255',   emoji: '🦅' },
  bug:      { banner: 'https://i.imgur.com/V4IXR51.png', color: '#99cc00', rgb: '153,204,0',     emoji: '🐛' },
  fighting: { banner: 'https://i.imgur.com/OKsJXh7.png', color: '#ff4400', rgb: '255,68,0',      emoji: '🥊' },
};

// Resolve o tipo de um pacote Talent pelo nome
function getTalentPkgType(pkgName) {
  var n = pkgName.toLowerCase();
  var keys = Object.keys(TALENT_TYPE_META);
  for (var i = 0; i < keys.length; i++) {
    if (n.includes(keys[i])) return keys[i];
  }
  if (n.includes('figthing') || n.includes('fighting')) return 'fighting';
  return null;
}

var _talentPanelOpen = null; // tipo atualmente aberto no painel lateral

function renderTalents() {
  var el = document.getElementById('wiki-talents-content');
  if (!el) return;

  // Injeta estilos uma única vez
  if (!document.getElementById('talent-styles-v2')) {
    var s = document.createElement('style');
    s.id = 'talent-styles-v2';
    s.textContent = `
      /* ── Layout geral ── */
      .tpg { padding: 0 0 48px; }

      /* ── Hero ── */
      .tpg-hero {
        text-align: center; padding: 30px 20px 22px;
        background: linear-gradient(180deg, rgba(255,224,102,0.07) 0%, transparent 100%);
        border-bottom: 1px solid rgba(255,255,255,0.06); margin-bottom: 0;
      }
      .tpg-hero-icon { font-size: 40px; margin-bottom: 8px; }
      .tpg-hero-title {
        font-family: var(--font-title); font-size: 20px; font-weight: 900;
        letter-spacing: 2.5px; text-transform: uppercase; color: #ffe066;
        text-shadow: 0 0 20px rgba(255,224,102,0.35);
      }
      .tpg-hero-desc {
        font-size: 12.5px; color: rgba(255,255,255,0.4);
        margin-top: 7px; line-height: 1.65; max-width: 560px; margin-left: auto; margin-right: auto;
      }

      /* ── Body com painel lateral ── */
      .tpg-body {
        display: flex; gap: 0; min-height: 500px;
        border-top: 1px solid rgba(255,255,255,0.05);
      }

      /* ── Coluna esquerda: lista de tipos ── */
      .tpg-list {
        width: 220px; min-width: 180px; flex-shrink: 0;
        border-right: 1px solid rgba(255,255,255,0.06);
        overflow-y: auto; padding: 14px 10px;
        display: flex; flex-direction: column; gap: 4px;
      }
      .tpg-section-label {
        font-size: 10px; font-weight: 700; letter-spacing: 1.8px;
        text-transform: uppercase; color: rgba(255,255,255,0.25);
        padding: 10px 8px 6px; margin-top: 4px;
      }
      .tpg-section-label:first-child { margin-top: 0; }

      .tpg-type-btn {
        display: flex; align-items: center; gap: 10px;
        padding: 9px 10px; border-radius: 10px;
        background: transparent; border: 1px solid transparent;
        cursor: pointer; transition: background 0.15s, border-color 0.15s;
        width: 100%; text-align: left;
      }
      .tpg-type-btn:hover {
        background: rgba(var(--tb-rgb), 0.08);
        border-color: rgba(var(--tb-rgb), 0.2);
      }
      .tpg-type-btn.active {
        background: rgba(var(--tb-rgb), 0.14);
        border-color: rgba(var(--tb-rgb), 0.4);
        box-shadow: 0 0 0 1px rgba(var(--tb-rgb), 0.15) inset;
      }
      .tpg-type-btn-icon {
        width: 32px; height: 32px; border-radius: 50%;
        overflow: hidden; flex-shrink: 0;
        border: 2px solid rgba(var(--tb-rgb), 0.35);
        box-shadow: 0 0 8px rgba(var(--tb-rgb), 0.25);
      }
      .tpg-type-btn-icon img { width: 100%; height: 100%; object-fit: cover; }
      .tpg-type-btn-label {
        font-family: var(--font-title); font-size: 12px; font-weight: 700;
        letter-spacing: 1px; text-transform: uppercase;
        color: rgba(var(--tb-rgb), 1);
        flex: 1;
      }
      .tpg-type-btn-arrow {
        font-size: 10px; color: rgba(var(--tb-rgb), 0.5);
        transition: transform 0.15s;
      }
      .tpg-type-btn.active .tpg-type-btn-arrow { transform: translateX(3px); }

      /* Special buttons */
      .tpg-special-btn {
        display: flex; align-items: center; gap: 10px;
        padding: 9px 10px; border-radius: 10px;
        background: transparent; border: 1px solid transparent;
        cursor: pointer; transition: background 0.15s, border-color 0.15s;
        width: 100%; text-align: left;
      }
      .tpg-special-btn:hover { background: rgba(var(--sb-rgb),0.08); border-color: rgba(var(--sb-rgb),0.2); }
      .tpg-special-btn.active { background: rgba(var(--sb-rgb),0.14); border-color: rgba(var(--sb-rgb),0.4); }
      .tpg-special-btn-icon {
        width: 32px; height: 32px; border-radius: 50%;
        background: rgba(var(--sb-rgb),0.15);
        border: 2px solid rgba(var(--sb-rgb),0.35);
        display: flex; align-items: center; justify-content: center;
        font-size: 16px; flex-shrink: 0;
      }
      .tpg-special-btn-label {
        font-family: var(--font-title); font-size: 12px; font-weight: 700;
        letter-spacing: 1px; text-transform: uppercase; color: rgba(var(--sb-rgb),1); flex: 1;
      }

      /* ── Painel direito: detalhe ── */
      .tpg-panel {
        flex: 1; min-width: 0;
        padding: 24px 24px 32px;
        display: flex; flex-direction: column; gap: 20px;
      }

      /* Estado vazio */
      .tpg-empty {
        flex: 1; display: flex; flex-direction: column;
        align-items: center; justify-content: center; gap: 10px;
        color: rgba(255,255,255,0.2); text-align: center;
        font-size: 13px; padding: 60px 20px;
      }
      .tpg-empty-icon { font-size: 36px; opacity: 0.35; margin-bottom: 4px; }

      /* Cabeçalho do painel */
      .tpg-panel-header {
        display: flex; align-items: center; gap: 14px;
        padding-bottom: 16px;
        border-bottom: 1px solid rgba(var(--pd-rgb,255,255,255), 0.1);
      }
      .tpg-panel-banner {
        width: 54px; height: 54px; border-radius: 50%;
        overflow: hidden; flex-shrink: 0;
        border: 2px solid rgba(var(--pd-rgb,255,255,255), 0.4);
        box-shadow: 0 0 18px rgba(var(--pd-rgb,255,255,255), 0.25);
      }
      .tpg-panel-banner img { width: 100%; height: 100%; object-fit: cover; }
      .tpg-panel-banner-emoji {
        width: 54px; height: 54px; border-radius: 50%;
        background: rgba(var(--pd-rgb,255,255,255),0.1);
        border: 2px solid rgba(var(--pd-rgb,255,255,255),0.4);
        display: flex; align-items: center; justify-content: center;
        font-size: 26px; flex-shrink: 0;
      }
      .tpg-panel-info { flex: 1; }
      .tpg-panel-name {
        font-family: var(--font-title); font-size: 18px; font-weight: 900;
        letter-spacing: 2px; text-transform: uppercase;
        color: rgb(var(--pd-rgb,255,255,255));
        text-shadow: 0 0 20px rgba(var(--pd-rgb,255,255,255),0.3);
      }
      .tpg-panel-sub { font-size: 12px; color: rgba(255,255,255,0.38); margin-top: 3px; }

      /* Buff chips */
      .tpg-buffs { display: flex; flex-wrap: wrap; gap: 8px; }
      .tpg-buff-chip {
        display: flex; align-items: center; gap: 7px;
        padding: 7px 13px; border-radius: 20px;
        background: rgba(var(--pd-rgb,255,255,255),0.08);
        border: 1px solid rgba(var(--pd-rgb,255,255,255),0.22);
      }
      .tpg-buff-chip-icon { font-size: 14px; }
      .tpg-buff-chip-label { font-size: 11px; color: rgba(255,255,255,0.45); font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; }
      .tpg-buff-chip-val {
        font-family: var(--font-mono,monospace); font-size: 15px; font-weight: 900;
        color: rgb(var(--pd-rgb,255,255,255));
        text-shadow: 0 0 8px rgba(var(--pd-rgb,255,255,255),0.5);
        margin-left: 2px;
      }

      /* Seção de ingredientes */
      .tpg-ingr-title {
        font-size: 10px; font-weight: 700; letter-spacing: 2px;
        text-transform: uppercase; color: rgba(255,255,255,0.3);
        margin-bottom: 10px;
      }

      /* Slot tabs */
      .tpg-slots { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
      .tpg-slot-btn {
        padding: 5px 12px; border-radius: 8px; font-size: 11px; font-weight: 700;
        letter-spacing: 0.5px; cursor: pointer;
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.12);
        color: rgba(255,255,255,0.5);
        transition: background 0.15s, border-color 0.15s, color 0.15s;
      }
      .tpg-slot-btn.active {
        background: rgba(var(--pd-rgb,255,255,255),0.14);
        border-color: rgba(var(--pd-rgb,255,255,255),0.45);
        color: rgb(var(--pd-rgb,255,255,255));
      }

      /* Lista de ingredientes do slot ativo */
      .tpg-ingr-list { display: flex; flex-direction: column; gap: 6px; }
      .tpg-ingr-row {
        display: flex; align-items: center; gap: 10px;
        padding: 9px 12px; border-radius: 10px;
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.07);
        transition: background 0.15s;
      }
      .tpg-ingr-row:hover { background: rgba(var(--pd-rgb,255,255,255),0.06); }
      .tpg-ingr-img {
        width: 30px; height: 30px; object-fit: contain;
        border-radius: 6px;
        background: rgba(255,255,255,0.04);
        flex-shrink: 0;
      }
      .tpg-ingr-img-placeholder {
        width: 30px; height: 30px; border-radius: 6px;
        background: rgba(255,255,255,0.06);
        display: flex; align-items: center; justify-content: center;
        font-size: 14px; flex-shrink: 0;
      }
      .tpg-ingr-name {
        flex: 1; font-size: 13px; color: rgba(255,255,255,0.75);
        font-weight: 500;
      }
      .tpg-ingr-qty {
        font-family: var(--font-mono,monospace); font-size: 13px; font-weight: 700;
        color: rgb(var(--pd-rgb,255,255,255));
        background: rgba(var(--pd-rgb,255,255,255),0.1);
        border: 1px solid rgba(var(--pd-rgb,255,255,255),0.2);
        padding: 2px 8px; border-radius: 6px;
        white-space: nowrap;
      }
      .tpg-ingr-or {
        font-size: 10px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase;
        color: rgba(255,255,255,0.2); text-align: center; padding: 2px 0;
        position: relative;
      }
      .tpg-ingr-or::before, .tpg-ingr-or::after {
        content: ''; position: absolute; top: 50%; width: 42%;
        height: 1px; background: rgba(255,255,255,0.08);
      }
      .tpg-ingr-or::before { left: 0; }
      .tpg-ingr-or::after { right: 0; }

      /* Botão ir para pacotes */
      .tpg-goto-btn {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 11px 20px; border-radius: 10px;
        font-family: var(--font-title); font-size: 12px; font-weight: 700;
        letter-spacing: 1px; text-transform: uppercase;
        background: rgba(var(--pd-rgb,255,255,255),0.12);
        border: 1px solid rgba(var(--pd-rgb,255,255,255),0.35);
        color: rgb(var(--pd-rgb,255,255,255));
        cursor: pointer; transition: background 0.15s, transform 0.1s;
        align-self: flex-start; margin-top: 6px;
        text-shadow: 0 0 10px rgba(var(--pd-rgb,255,255,255),0.3);
        box-shadow: 0 0 20px rgba(var(--pd-rgb,255,255,255),0.08);
      }
      .tpg-goto-btn:hover {
        background: rgba(var(--pd-rgb,255,255,255),0.22);
        transform: scale(1.03);
      }
      .tpg-goto-btn svg { flex-shrink: 0; }

      /* Separador de slots — "OU" entre opções alternativas */
      .tpg-slot-sep {
        font-size: 10px; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase;
        color: rgba(255,255,255,0.18); text-align: center;
        padding: 6px 0; border-top: 1px solid rgba(255,255,255,0.05);
        margin-top: 4px;
      }

      /* Responsive */
      @media(max-width:640px) {
        .tpg-body { flex-direction: column; }
        .tpg-list { width: 100%; flex-direction: row; flex-wrap: wrap; border-right: none; border-bottom: 1px solid rgba(255,255,255,0.06); padding: 10px 8px; gap: 6px; }
        .tpg-type-btn, .tpg-special-btn { width: auto; }
        .tpg-type-btn-arrow, .tpg-type-btn-label { display: none; }
        .tpg-type-btn-icon, .tpg-special-btn-icon { width: 38px; height: 38px; }
        .tpg-panel { padding: 16px; }
        .tpg-section-label { display: none; }
      }
    `;
    document.head.appendChild(s);
  }

  // ── Build HTML ──────────────────────────────────────────────────────────────
  var html = '<div class="tpg">';

  // ── Estilos da seção explicativa ──────────────────────────────────────────
  if (!document.getElementById('talent-explain-styles')) {
    var se = document.createElement('style');
    se.id = 'talent-explain-styles';
    se.textContent = `
      /* Hero */
      .tpg-hero { border-bottom: none !important; margin-bottom: 0 !important; }

      /* Explain section */
      .tpg-explain {
        padding: 0 20px 28px;
        max-width: 860px; margin: 0 auto;
        display: flex; flex-direction: column; gap: 14px;
      }

      /* Intro text */
      .tpg-intro {
        font-family: var(--font-body); font-size: 13.5px; color: rgba(255,255,255,0.5);
        line-height: 1.8; text-align: center;
        max-width: 680px; margin: 0 auto; padding: 18px 0 4px;
      }
      .tpg-intro strong { color: rgba(255,255,255,0.82); }

      /* Divider */
      .tpg-explain-divider {
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(255,224,102,0.18), transparent);
        margin: 4px 0;
      }

      /* Cards de info */
      .tpg-ex-card {
        border-radius: 16px; padding: 20px 22px;
        display: flex; gap: 18px; align-items: flex-start;
        background: rgba(255,255,255,0.025);
        border: 1px solid rgba(255,255,255,0.07);
        transition: border-color .2s, background .2s;
      }
      .tpg-ex-card:hover {
        border-color: rgba(255,224,102,0.18);
        background: rgba(255,224,102,0.025);
      }
      .tpg-ex-card-icon { font-size: 28px; flex-shrink: 0; margin-top: 2px; line-height: 1; }
      .tpg-ex-card-body { flex: 1; min-width: 0; }
      .tpg-ex-card-title {
        font-family: var(--font-title); font-size: 11.5px; font-weight: 700;
        letter-spacing: 1.8px; text-transform: uppercase; color: #ffe066;
        margin-bottom: 8px;
      }
      .tpg-ex-card-text {
        font-family: var(--font-body); font-size: 13px; color: rgba(255,255,255,0.5);
        line-height: 1.75;
      }
      .tpg-ex-card-text strong { color: rgba(255,255,255,0.82); }

      /* Bullet list dentro dos cards */
      .tpg-ex-bullets { display: flex; flex-direction: column; gap: 8px; margin-top: 10px; }
      .tpg-ex-bullet {
        display: flex; align-items: flex-start; gap: 10px;
        background: rgba(255,255,255,0.03); border-radius: 10px;
        padding: 10px 14px; border: 1px solid rgba(255,255,255,0.05);
      }
      .tpg-ex-bullet-dot {
        width: 6px; height: 6px; border-radius: 50%;
        background: #ffe066; flex-shrink: 0; margin-top: 5px;
        box-shadow: 0 0 6px rgba(255,224,102,0.5);
      }
      .tpg-ex-bullet-text {
        font-family: var(--font-body); font-size: 12.5px;
        color: rgba(255,255,255,0.48); line-height: 1.65; flex: 1;
      }
      .tpg-ex-bullet-text strong { color: rgba(255,255,255,0.8); }

      /* Dois cards lado a lado (especiais) */
      .tpg-ex-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
      @media(max-width:600px) { .tpg-ex-row { grid-template-columns: 1fr; } }

      /* Card especial de talento */
      .tpg-ex-special {
        border-radius: 16px; padding: 20px 18px;
        background: rgba(255,255,255,0.025);
        border: 1px solid rgba(var(--tse-rgb,255,255,255),0.15);
        transition: border-color .2s, background .2s, box-shadow .2s;
      }
      .tpg-ex-special:hover {
        border-color: rgba(var(--tse-rgb,255,255,255),0.3);
        background: rgba(var(--tse-rgb,255,255,255),0.04);
        box-shadow: 0 0 24px rgba(var(--tse-rgb,255,255,255),0.06);
      }
      .tpg-ex-special-head {
        display: flex; align-items: center; gap: 12px; margin-bottom: 14px;
      }
      .tpg-ex-special-icon {
        width: 42px; height: 42px; border-radius: 50%;
        background: rgba(var(--tse-rgb,255,255,255),0.1);
        border: 1.5px solid rgba(var(--tse-rgb,255,255,255),0.25);
        display: flex; align-items: center; justify-content: center;
        font-size: 20px; flex-shrink: 0;
      }
      .tpg-ex-special-name {
        font-family: var(--font-title); font-size: 14px; font-weight: 900;
        letter-spacing: 1.5px; text-transform: uppercase;
        color: rgba(var(--tse-rgb,255,255,255),1);
      }
      .tpg-ex-special-sub {
        font-family: var(--font-body); font-size: 11px;
        color: rgba(255,255,255,0.3); margin-top: 2px;
      }
      .tpg-ex-special-stats { display: flex; flex-direction: column; gap: 7px; }
      .tpg-ex-stat {
        display: flex; align-items: center; gap: 10px;
        background: rgba(var(--tse-rgb,255,255,255),0.05);
        border-radius: 9px; padding: 8px 12px;
        border: 1px solid rgba(var(--tse-rgb,255,255,255),0.08);
      }
      .tpg-ex-stat-val {
        font-family: var(--font-mono, monospace); font-size: 13px; font-weight: 900;
        color: rgba(var(--tse-rgb,255,255,255),1); min-width: 52px;
      }
      .tpg-ex-stat-label {
        font-family: var(--font-body); font-size: 12px;
        color: rgba(255,255,255,0.42); flex: 1;
      }

      /* Callout "Como jogar" */
      .tpg-callout {
        border-radius: 14px; padding: 16px 20px;
        background: rgba(255,224,102,0.05);
        border: 1px solid rgba(255,224,102,0.15);
        font-family: var(--font-body); font-size: 12.5px;
        color: rgba(255,255,255,0.48); line-height: 1.7;
        text-align: center;
      }
      .tpg-callout strong { color: #ffe066; }

      /* Divider com título antes do painel */
      .tpg-section-divider {
        display: flex; align-items: center; gap: 14px;
        padding: 8px 20px 0; max-width: 860px; margin: 0 auto;
      }
      .tpg-section-divider-line { flex: 1; height: 1px; background: rgba(255,255,255,0.06); }
      .tpg-section-divider-label {
        font-family: var(--font-title); font-size: 10px; font-weight: 700;
        letter-spacing: 2px; text-transform: uppercase; color: rgba(255,255,255,0.2);
        white-space: nowrap;
      }
    `;
    document.head.appendChild(se);
  }

  // Hero
  html += '<div class="tpg-hero">';
  html += '  <div class="tpg-hero-icon">✨</div>';
  html += '  <div class="tpg-hero-title">PokéTalents</div>';
  html += '  <div class="tpg-hero-desc">Buffs especiais que potencializam seus Pokémon e personagem em batalha, exploração e muito mais.</div>';
  html += '</div>';

  // ── Seção explicativa ──────────────────────────────────────────────────────
  html += '<div class="tpg-explain">';

  // Intro
  html += '<div class="tpg-intro">';
  html += 'PokéTalents são <strong>buffs especiais</strong> que seus Pokémon e personagem podem adquirir, oferecendo vantagens exclusivas em batalhas e exploração. ';
  html += 'O sistema foca nas <strong>tipagens dos Pokémon</strong> disponíveis no jogo — diferente dos Clans tradicionais — ';
  html += 'permitindo que você melhore seu desempenho habilitando talentos específicos de cada tipo.';
  html += '</div>';

  html += '<div class="tpg-explain-divider"></div>';

  // Card: Como funciona
  html += '<div class="tpg-ex-card">';
  html += '<div class="tpg-ex-card-icon">⚙️</div>';
  html += '<div class="tpg-ex-card-body">';
  html += '<div class="tpg-ex-card-title">Como Funciona o Sistema?</div>';
  html += '<div class="tpg-ex-card-text">O sistema de Talentos é dividido em <strong>tipagens</strong> (Fire, Water, Electric, etc.) e <strong>talentos especiais</strong> (Character e Pokémon). Cada um funciona de forma independente e oferece bônus diferentes.</div>';
  html += '<div class="tpg-ex-bullets">';
  html += '<div class="tpg-ex-bullet"><div class="tpg-ex-bullet-dot"></div><div class="tpg-ex-bullet-text"><strong>Talentos por Tipagem:</strong> Cada elemento tem um talento associado. Ao habilitar, você recebe bônus de ataque e defesa para todos os Pokémon daquela tipagem.</div></div>';
  html += '<div class="tpg-ex-bullet"><div class="tpg-ex-bullet-dot"></div><div class="tpg-ex-bullet-text"><strong>Ingredientes para Habilitar:</strong> Cada tipagem exige uma receita própria, composta por itens raros ou específicos do jogo. Clique em um tipo ao lado para ver os ingredientes necessários.</div></div>';
  html += '<div class="tpg-ex-bullet"><div class="tpg-ex-bullet-dot"></div><div class="tpg-ex-bullet-text"><strong>Full Buff de Tipagem:</strong> Ao completar todos os slots de uma tipagem, você ativa o <strong>Full Buff</strong> — garantindo <strong>+13% de Ataque e +13% de Defesa</strong> para todos os Pokémon daquela tipagem.</div></div>';
  html += '</div>';
  html += '</div>';
  html += '</div>';

  // Card: Talentos especiais — Character & Pokemon lado a lado
  html += '<div class="tpg-ex-card">';
  html += '<div class="tpg-ex-card-icon">⭐</div>';
  html += '<div class="tpg-ex-card-body">';
  html += '<div class="tpg-ex-card-title">Talentos Especiais</div>';
  html += '<div class="tpg-ex-card-text" style="margin-bottom:14px">Além das tipagens tradicionais, existem dois talentos especiais que oferecem bônus diretos ao <strong>personagem</strong> e aos <strong>Pokémon</strong>. Clique em cada um ao lado para ver a receita completa.</div>';
  html += '<div class="tpg-ex-row">';

  // Character
  html += '<div class="tpg-ex-special" style="--tse-rgb:255,224,102">';
  html += '<div class="tpg-ex-special-head">';
  html += '<div class="tpg-ex-special-icon">🧍</div>';
  html += '<div><div class="tpg-ex-special-name">Character</div><div class="tpg-ex-special-sub">Bônus direto no personagem</div></div>';
  html += '</div>';
  html += '<div class="tpg-ex-special-stats">';
  html += '<div class="tpg-ex-stat"><span class="tpg-ex-stat-val">+80</span><span class="tpg-ex-stat-label">Speed do personagem</span></div>';
  html += '<div class="tpg-ex-stat"><span class="tpg-ex-stat-val">+1400</span><span class="tpg-ex-stat-label">HP do personagem</span></div>';
  html += '<div class="tpg-ex-stat"><span class="tpg-ex-stat-val">+11%</span><span class="tpg-ex-stat-label">Chance de Crítico</span></div>';
  html += '</div>';
  html += '</div>';

  // Pokemon
  html += '<div class="tpg-ex-special" style="--tse-rgb:96,192,255">';
  html += '<div class="tpg-ex-special-head">';
  html += '<div class="tpg-ex-special-icon">🐾</div>';
  html += '<div><div class="tpg-ex-special-name">Pokémon</div><div class="tpg-ex-special-sub">Bônus de Speed por terreno</div></div>';
  html += '</div>';
  html += '<div class="tpg-ex-special-stats">';
  html += '<div class="tpg-ex-stat"><span class="tpg-ex-stat-val">+10%</span><span class="tpg-ex-stat-label">Speed em terreno de Água 💧</span></div>';
  html += '<div class="tpg-ex-stat"><span class="tpg-ex-stat-val">+10%</span><span class="tpg-ex-stat-label">Speed em terreno de Areia 🏜️</span></div>';
  html += '<div class="tpg-ex-stat"><span class="tpg-ex-stat-val">+10%</span><span class="tpg-ex-stat-label">Speed em terreno de Gelo ❄️</span></div>';
  html += '</div>';
  html += '</div>';

  html += '</div>'; // tpg-ex-row
  html += '</div>'; // card-body
  html += '</div>'; // card

  // Callout final
  html += '<div class="tpg-callout">';
  html += '💡 <strong>Selecione uma tipagem ou talento especial na lista abaixo</strong> para ver os ingredientes necessários, os slots disponíveis e como habilitar cada bônus.';
  html += '</div>';

  html += '</div>'; // .tpg-explain

  // Estilos do grid de blocos
  if (!document.getElementById('talent-grid-styles')) {
    var sg = document.createElement('style');
    sg.id = 'talent-grid-styles';
    sg.textContent = `
      /* ── Seção explorar ── */
      .tpg-explore-section {
        padding: 0 20px 48px;
        max-width: 860px; margin: 0 auto;
      }

      /* Divider com label */
      .tpg-section-divider {
        display: flex; align-items: center; gap: 14px;
        padding: 8px 20px 20px; max-width: 860px; margin: 0 auto;
      }
      .tpg-section-divider-line { flex: 1; height: 1px; background: rgba(255,255,255,0.06); }
      .tpg-section-divider-label {
        font-family: var(--font-title); font-size: 10px; font-weight: 700;
        letter-spacing: 2px; text-transform: uppercase; color: rgba(255,255,255,0.2);
        white-space: nowrap;
      }

      /* Sub-label de categoria */
      .tpg-grid-cat-label {
        font-family: var(--font-title); font-size: 10px; font-weight: 700;
        letter-spacing: 2px; text-transform: uppercase;
        color: rgba(255,255,255,0.25); margin-bottom: 12px; margin-top: 22px;
      }
      .tpg-grid-cat-label:first-child { margin-top: 0; }

      /* Grid de blocos */
      .tpg-blocks-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
        gap: 10px;
      }
      @media(max-width:480px) { .tpg-blocks-grid { grid-template-columns: repeat(3, 1fr); } }

      /* Bloco individual */
      .tpg-block {
        border-radius: 16px; padding: 18px 12px 14px;
        background: rgba(255,255,255,0.025);
        border: 1px solid rgba(255,255,255,0.08);
        cursor: pointer; text-align: center;
        transition: background .2s, border-color .2s, transform .15s, box-shadow .2s;
        position: relative; overflow: hidden;
      }
      .tpg-block::before {
        content: '';
        position: absolute; top: 0; left: 0; right: 0; height: 2px;
        background: rgba(var(--tb-rgb), 0.6);
        opacity: 0; transition: opacity .2s;
        border-radius: 16px 16px 0 0;
      }
      .tpg-block:hover::before { opacity: 1; }
      .tpg-block:hover {
        background: rgba(var(--tb-rgb), 0.07);
        border-color: rgba(var(--tb-rgb), 0.35);
        transform: translateY(-3px);
        box-shadow: 0 8px 24px rgba(0,0,0,0.35);
      }
      .tpg-block-img {
        width: 44px; height: 44px; border-radius: 50%;
        overflow: hidden; margin: 0 auto 10px;
        border: 2px solid rgba(var(--tb-rgb), 0.35);
        box-shadow: 0 0 14px rgba(var(--tb-rgb), 0.25);
      }
      .tpg-block-img img { width: 100%; height: 100%; object-fit: cover; display: block; }
      .tpg-block-emoji-icon {
        width: 44px; height: 44px; border-radius: 50%;
        margin: 0 auto 10px;
        background: rgba(var(--tb-rgb), 0.12);
        border: 2px solid rgba(var(--tb-rgb), 0.3);
        display: flex; align-items: center; justify-content: center;
        font-size: 22px;
      }
      .tpg-block-name {
        font-family: var(--font-title); font-size: 9.5px; font-weight: 700;
        letter-spacing: 0.8px; text-transform: uppercase;
        color: rgba(var(--tb-rgb), 1); line-height: 1.3;
        margin-bottom: 6px;
      }
      .tpg-block-tag {
        display: inline-block;
        background: rgba(var(--tb-rgb), 0.1);
        border: 1px solid rgba(var(--tb-rgb), 0.22);
        border-radius: 20px; padding: 2px 8px;
        font-family: var(--font-mono, monospace); font-size: 9px; font-weight: 700;
        color: rgba(var(--tb-rgb), 0.85);
      }

      /* ── Modal de talento ── */
      .tpg-modal-overlay {
        position: fixed; inset: 0; z-index: 10001;
        background: rgba(0,0,0,0.78); backdrop-filter: blur(7px);
        display: flex; align-items: center; justify-content: center;
        padding: 16px;
        animation: tpg-fade .15s ease;
      }
      @keyframes tpg-fade { from { opacity: 0 } to { opacity: 1 } }

      .tpg-modal {
        background: #0a1220;
        border-radius: 22px;
        border: 1px solid rgba(var(--tm-rgb,255,255,255), 0.2);
        box-shadow: 0 0 60px rgba(var(--tm-rgb,255,255,255), 0.08), 0 24px 60px rgba(0,0,0,0.65);
        max-width: 480px; width: 100%;
        max-height: 85vh; overflow-y: auto;
        animation: tpg-slideup .22s cubic-bezier(.4,0,.2,1);
      }
      @keyframes tpg-slideup { from { transform: translateY(18px); opacity: 0 } to { transform: translateY(0); opacity: 1 } }

      .tpg-modal-header {
        padding: 22px 22px 18px;
        background: linear-gradient(135deg, rgba(var(--tm-rgb,255,255,255),0.06), transparent);
        border-bottom: 1px solid rgba(var(--tm-rgb,255,255,255), 0.1);
        display: flex; align-items: center; gap: 14px;
        position: sticky; top: 0; z-index: 2;
        background-color: #0a1220;
      }
      .tpg-modal-banner {
        width: 48px; height: 48px; border-radius: 50%; overflow: hidden; flex-shrink: 0;
        border: 2px solid rgba(var(--tm-rgb,255,255,255), 0.4);
        box-shadow: 0 0 18px rgba(var(--tm-rgb,255,255,255), 0.2);
      }
      .tpg-modal-banner img { width: 100%; height: 100%; object-fit: cover; }
      .tpg-modal-banner-emoji {
        width: 48px; height: 48px; border-radius: 50%; flex-shrink: 0;
        background: rgba(var(--tm-rgb,255,255,255), 0.1);
        border: 2px solid rgba(var(--tm-rgb,255,255,255), 0.35);
        display: flex; align-items: center; justify-content: center; font-size: 22px;
      }
      .tpg-modal-header-info { flex: 1; }
      .tpg-modal-title {
        font-family: var(--font-title); font-size: 16px; font-weight: 900;
        letter-spacing: 1.5px; text-transform: uppercase;
        color: rgba(var(--tm-rgb,255,255,255), 1); margin-bottom: 3px;
      }
      .tpg-modal-sub { font-family: var(--font-body); font-size: 11.5px; color: rgba(255,255,255,0.32); }
      .tpg-modal-close {
        background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12);
        color: rgba(255,255,255,0.45); border-radius: 50%; width: 30px; height: 30px;
        display: flex; align-items: center; justify-content: center;
        cursor: pointer; font-size: 14px; transition: background .15s, color .15s; flex-shrink: 0;
      }
      .tpg-modal-close:hover { background: rgba(255,255,255,0.14); color: #fff; }

      .tpg-modal-body {
        padding: 20px 22px 24px;
        display: flex; flex-direction: column; gap: 20px;
      }
      .tpg-modal-section-label {
        font-family: var(--font-title); font-size: 9.5px; font-weight: 700;
        letter-spacing: 2px; text-transform: uppercase; color: rgba(255,255,255,0.22);
        margin-bottom: 10px;
      }

      /* Buffs no modal */
      .tpg-modal-buffs { display: flex; flex-wrap: wrap; gap: 8px; }
      .tpg-modal-buff {
        display: flex; align-items: center; gap: 8px;
        background: rgba(var(--tm-rgb,255,255,255), 0.06);
        border: 1px solid rgba(var(--tm-rgb,255,255,255), 0.12);
        border-radius: 10px; padding: 9px 14px;
        flex: 1; min-width: 120px;
      }
      .tpg-modal-buff-icon { font-size: 16px; flex-shrink: 0; }
      .tpg-modal-buff-val {
        font-family: var(--font-mono, monospace); font-size: 14px; font-weight: 900;
        color: rgba(var(--tm-rgb,255,255,255), 1);
      }
      .tpg-modal-buff-label {
        font-family: var(--font-body); font-size: 11px;
        color: rgba(255,255,255,0.38); margin-top: 1px;
      }

      /* Slots no modal */
      .tpg-modal-slots { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 12px; }
      .tpg-modal-slot-btn {
        background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);
        border-radius: 8px; padding: 6px 14px; cursor: pointer;
        font-family: var(--font-mono, monospace); font-size: 11px; font-weight: 700;
        color: rgba(255,255,255,0.4);
        transition: background .15s, border-color .15s, color .15s;
      }
      .tpg-modal-slot-btn:hover {
        background: rgba(var(--tm-rgb,255,255,255), 0.08);
        border-color: rgba(var(--tm-rgb,255,255,255), 0.25);
        color: rgba(var(--tm-rgb,255,255,255), 0.8);
      }
      .tpg-modal-slot-btn.active {
        background: rgba(var(--tm-rgb,255,255,255), 0.14);
        border-color: rgba(var(--tm-rgb,255,255,255), 0.4);
        color: rgba(var(--tm-rgb,255,255,255), 1);
      }

      /* Ingredientes no modal */
      .tpg-modal-ingr-list { display: flex; flex-direction: column; gap: 6px; }
      .tpg-modal-ingr-row {
        display: flex; align-items: center; gap: 12px;
        background: rgba(255,255,255,0.03); border-radius: 10px;
        padding: 10px 14px; border: 1px solid rgba(255,255,255,0.05);
      }
      .tpg-modal-ingr-img { width: 32px; height: 32px; object-fit: contain; border-radius: 6px; flex-shrink: 0; }
      .tpg-modal-ingr-placeholder {
        width: 32px; height: 32px; border-radius: 6px;
        background: rgba(255,255,255,0.05); display: flex; align-items: center;
        justify-content: center; font-size: 14px; flex-shrink: 0;
      }
      .tpg-modal-ingr-name { flex: 1; font-family: var(--font-body); font-size: 12.5px; color: rgba(255,255,255,0.7); }
      .tpg-modal-ingr-qty {
        font-family: var(--font-mono, monospace); font-size: 13px; font-weight: 700;
        color: rgba(var(--tm-rgb,255,255,255), 0.9);
      }
      .tpg-modal-ingr-or {
        text-align: center; font-size: 10px; font-weight: 700;
        letter-spacing: 1px; text-transform: uppercase; color: rgba(255,255,255,0.2);
        padding: 2px 0;
      }

      /* Botão pacote no modal */
      .tpg-modal-goto {
        display: inline-flex; align-items: center; gap: 8px;
        background: rgba(var(--tm-rgb,255,255,255), 0.08);
        border: 1px solid rgba(var(--tm-rgb,255,255,255), 0.2);
        border-radius: 12px; padding: 11px 18px; cursor: pointer;
        font-family: var(--font-title); font-size: 11px; font-weight: 700;
        letter-spacing: 1px; text-transform: uppercase;
        color: rgba(var(--tm-rgb,255,255,255), 0.9);
        transition: background .15s, border-color .15s, transform .15s;
        width: 100%; justify-content: center;
      }
      .tpg-modal-goto:hover {
        background: rgba(var(--tm-rgb,255,255,255), 0.15);
        border-color: rgba(var(--tm-rgb,255,255,255), 0.35);
        transform: scale(1.02);
      }
    `;
    document.head.appendChild(sg);
  }

  // Divider antes do grid
  html += '<div class="tpg-section-divider">';
  html += '<div class="tpg-section-divider-line"></div>';
  html += '<div class="tpg-section-divider-label">✨ Explorar Talentos</div>';
  html += '<div class="tpg-section-divider-line"></div>';
  html += '</div>';

  html += '<div class="tpg-explore-section">';

  // Label tipagens
  html += '<div class="tpg-grid-cat-label">⚔️ Tipagens — +13% ATK &amp; DEF</div>';
  html += '<div class="tpg-blocks-grid">';

  var TYPE_ORDER = ['fire','water','electric','grass','ice','psychic','ghost','dragon','dark','fairy','poison','ground','rock','bug','flying','steel','normal','fighting'];
  TYPE_ORDER.forEach(function(type) {
    var m = TALENT_TYPE_META[type];
    if (!m) return;
    var label = type.charAt(0).toUpperCase() + type.slice(1);
    html += '<div class="tpg-block" style="--tb-rgb:' + m.rgb + '" onclick="openTalentModal(\'' + type + '\')">';
    html += '<div class="tpg-block-img"><img src="' + m.banner + '" alt="' + label + '" loading="lazy" /></div>';
    html += '<div class="tpg-block-name">' + m.emoji + ' ' + label + '</div>';
    html += '<div class="tpg-block-tag">+13% ATK&DEF</div>';
    html += '</div>';
  });

  html += '</div>'; // .tpg-blocks-grid

  // Label especiais
  html += '<div class="tpg-grid-cat-label">⭐ Talentos Especiais</div>';
  html += '<div class="tpg-blocks-grid">';

  // Character
  html += '<div class="tpg-block" style="--tb-rgb:255,224,102" onclick="openTalentModal(\'character\')">';
  html += '<div class="tpg-block-emoji-icon">🧍</div>';
  html += '<div class="tpg-block-name">Character</div>';
  html += '<div class="tpg-block-tag">Speed · HP · Crit</div>';
  html += '</div>';

  // Pokemon
  html += '<div class="tpg-block" style="--tb-rgb:96,192,255" onclick="openTalentModal(\'pokemon\')">';
  html += '<div class="tpg-block-emoji-icon">🐾</div>';
  html += '<div class="tpg-block-name">Pokémon</div>';
  html += '<div class="tpg-block-tag">Speed Terreno</div>';
  html += '</div>';

  html += '</div>'; // .tpg-blocks-grid

  html += '</div>'; // .tpg-explore-section

  // Raiz do modal
  html += '<div id="tpg-modal-root"></div>';

  html += '</div>'; // .tpg

  el.innerHTML = html;
  _talentPanelOpen = null;
}

// Slot ativo por tipo (mantido para compatibilidade)
var _talentActiveSlot = {};

// Slot ativo por tipo
var _talentActiveSlot = {};

function openTalentModal(type) {
  if (_talentActiveSlot[type] === undefined) _talentActiveSlot[type] = 0;

  var isType = TALENT_TYPE_META[type];
  var isCharacter = (type === 'character');
  var rgb, bannerHtml, name, sub;

  if (isType) {
    var m = TALENT_TYPE_META[type];
    rgb = m.rgb;
    bannerHtml = '<div class="tpg-modal-banner" style="--tm-rgb:' + rgb + '"><img src="' + m.banner + '" alt="' + type + '" /></div>';
    name = m.emoji + ' ' + (type.charAt(0).toUpperCase() + type.slice(1));
    sub = 'Talento de Tipagem — Full Buff';
  } else if (isCharacter) {
    rgb = '255,224,102';
    bannerHtml = '<div class="tpg-modal-banner-emoji" style="--tm-rgb:' + rgb + '">🧍</div>';
    name = 'Character'; sub = 'Talento Especial — Bônus direto no personagem';
  } else {
    rgb = '96,192,255';
    bannerHtml = '<div class="tpg-modal-banner-emoji" style="--tm-rgb:' + rgb + '">🐾</div>';
    name = 'Pokémon'; sub = 'Talento Especial — Bônus de Speed por terreno';
  }

  var html = '<div class="tpg-modal-overlay" id="tpg-modal-overlay" onclick="closeTalentModalOverlay(event)">';
  html += '<div class="tpg-modal" style="--tm-rgb:' + rgb + '">';

  // Header
  html += '<div class="tpg-modal-header">';
  html += bannerHtml;
  html += '<div class="tpg-modal-header-info">';
  html += '<div class="tpg-modal-title">' + name + '</div>';
  html += '<div class="tpg-modal-sub">' + sub + '</div>';
  html += '</div>';
  html += '<button class="tpg-modal-close" onclick="closeTalentModal()">✕</button>';
  html += '</div>';

  // Body
  html += '<div class="tpg-modal-body">';

  // Buffs
  html += '<div>';
  html += '<div class="tpg-modal-section-label">🎯 Buffs Concedidos</div>';
  html += '<div class="tpg-modal-buffs">';
  if (isType) {
    html += '<div class="tpg-modal-buff"><div class="tpg-modal-buff-icon">⚔️</div><div><div class="tpg-modal-buff-val">+13%</div><div class="tpg-modal-buff-label">Ataque</div></div></div>';
    html += '<div class="tpg-modal-buff"><div class="tpg-modal-buff-icon">🛡️</div><div><div class="tpg-modal-buff-val">+13%</div><div class="tpg-modal-buff-label">Defesa</div></div></div>';
    html += '</div>';
    html += '<div style="margin-top:8px;font-size:11.5px;color:rgba(255,255,255,0.3);font-family:var(--font-body)">Bônus aplicado apenas aos Pokémon desta tipagem.</div>';
  } else if (isCharacter) {
    html += '<div class="tpg-modal-buff"><div class="tpg-modal-buff-icon">💨</div><div><div class="tpg-modal-buff-val">+80</div><div class="tpg-modal-buff-label">Speed</div></div></div>';
    html += '<div class="tpg-modal-buff"><div class="tpg-modal-buff-icon">❤️</div><div><div class="tpg-modal-buff-val">+1400</div><div class="tpg-modal-buff-label">HP</div></div></div>';
    html += '<div class="tpg-modal-buff"><div class="tpg-modal-buff-icon">🎯</div><div><div class="tpg-modal-buff-val">+11%</div><div class="tpg-modal-buff-label">Crítico</div></div></div>';
    html += '</div>';
  } else {
    html += '<div class="tpg-modal-buff"><div class="tpg-modal-buff-icon">💧</div><div><div class="tpg-modal-buff-val">+10%</div><div class="tpg-modal-buff-label">Speed Água</div></div></div>';
    html += '<div class="tpg-modal-buff"><div class="tpg-modal-buff-icon">🏜️</div><div><div class="tpg-modal-buff-val">+10%</div><div class="tpg-modal-buff-label">Speed Areia</div></div></div>';
    html += '<div class="tpg-modal-buff"><div class="tpg-modal-buff-icon">❄️</div><div><div class="tpg-modal-buff-val">+10%</div><div class="tpg-modal-buff-label">Speed Gelo</div></div></div>';
    html += '</div>';
  }
  html += '</div>';

  // Ingredientes para tipagens
  if (isType) {
    var pkg = null, pkgIdx = -1;
    for (var pi = 0; pi < PACKAGES.length; pi++) {
      var pName = PACKAGES[pi].name.toLowerCase();
      if (pName.startsWith('talent') && (pName.includes(type) || (type === 'fighting' && (pName.includes('figthing') || pName.includes('fighting'))))) {
        pkg = PACKAGES[pi]; pkgIdx = pi; break;
      }
    }

    html += '<div>';
    html += '<div class="tpg-modal-section-label">🧪 Ingredientes Necessários</div>';

    if (pkg && pkg.slots) {
      var slots = pkg.slots;
      var si = Math.min(_talentActiveSlot[type] || 0, slots.length - 1);

      html += '<div class="tpg-modal-slots">';
      for (var idx = 0; idx < slots.length; idx++) {
        html += '<button class="tpg-modal-slot-btn' + (idx === si ? ' active' : '') + '" onclick="selectTalentSlot(\'' + type + '\',' + idx + ')">Slot ' + (idx + 1) + '</button>';
      }
      html += '</div>';

      var currentSlot = slots[si];
      html += '<div class="tpg-modal-ingr-list">';
      for (var ii = 0; ii < currentSlot.length; ii++) {
        var iName = currentSlot[ii][0];
        var iQty  = currentSlot[ii][1];
        var itemData = typeof getPkgItemData === 'function' ? getPkgItemData(iName) : null;
        var imgHtml = itemData && itemData.image
          ? '<img class="tpg-modal-ingr-img" src="' + itemData.image + '" alt="' + iName + '" loading="lazy" onerror="this.style.display=\'none\'" />'
          : '<div class="tpg-modal-ingr-placeholder">🔹</div>';
        if (ii > 0) html += '<div class="tpg-modal-ingr-or">ou</div>';
        html += '<div class="tpg-modal-ingr-row">' + imgHtml + '<span class="tpg-modal-ingr-name">' + iName + '</span><span class="tpg-modal-ingr-qty">×' + iQty.toLocaleString() + '</span></div>';
      }
      html += '</div>';
    } else {
      html += '<div style="color:rgba(255,255,255,0.25);font-size:13px;padding:8px 0">Pacote não encontrado.</div>';
    }
    html += '</div>';

    if (pkgIdx >= 0) {
      html += '<button class="tpg-modal-goto" onclick="closeTalentModal();goToTalentPackage(' + pkgIdx + ')">';
      html += '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>';
      html += 'Ver no Pacotes / Adicionar ao Carrinho';
      html += '</button>';
    }

  } else if (isCharacter) {
    html += '<div>';
    html += '<div class="tpg-modal-section-label">📦 Pacotes Relacionados</div>';
    html += '<div style="font-size:12.5px;color:rgba(255,255,255,0.4);line-height:1.7;margin-bottom:12px">Habilitado pelos pacotes <strong style="color:rgba(255,224,102,0.85)">Full Speed</strong> e <strong style="color:rgba(255,224,102,0.85)">Full HP</strong>.</div>';
    html += '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
    PACKAGES.forEach(function(p, pi) {
      var pn = p.name.toLowerCase();
      if (pn === 'full speed' || pn === 'full hp') {
        html += '<button class="tpg-modal-goto" style="flex:1;min-width:140px" onclick="closeTalentModal();goToTalentPackage(' + pi + ')">📦 ' + p.name + '</button>';
      }
    });
    html += '</div>';
    html += '</div>';
  } else {
    // Pokémon especial — habilitado pelos pacotes Reduces
    html += '<div>';
    html += '<div class="tpg-modal-section-label">📦 Pacotes Relacionados</div>';
    html += '<div style="font-size:12.5px;color:rgba(255,255,255,0.4);line-height:1.75;margin-bottom:14px">';
    html += 'Os bônus de Speed por terreno são habilitados pelos pacotes <strong style="color:rgba(96,192,255,0.85)">Reduces Speed</strong>. ';
    html += 'Cada pacote corresponde a um terreno específico — clique para ver os ingredientes e adicionar ao carrinho.';
    html += '</div>';

    // Monta os 3 sub-blocos de terreno com botão para o pacote correspondente
    var terrainos = [
      { label: 'Water', icon: '💧', rgb: '96,192,255', keyword: 'water' },
      { label: 'Sand',  icon: '🏜️', rgb: '204,136,0',  keyword: 'sand'  },
      { label: 'Ice',   icon: '❄️', rgb: '128,232,255', keyword: 'ice'   },
    ];

    html += '<div style="display:flex;flex-direction:column;gap:8px;">';
    terrainos.forEach(function(t) {
      // Encontra o pacote Reduces correspondente
      var rPkgIdx = -1;
      for (var ri = 0; ri < PACKAGES.length; ri++) {
        var rn = PACKAGES[ri].name.toLowerCase();
        if (rn.startsWith('reduces') && rn.includes(t.keyword)) { rPkgIdx = ri; break; }
      }
      var pkgName = rPkgIdx >= 0 ? PACKAGES[rPkgIdx].name : ('Reduces Speed ' + t.label);
      var onclick = rPkgIdx >= 0
        ? 'onclick="closeTalentModal();goToTalentPackageReduces(' + rPkgIdx + ')"'
        : '';
      html += '<div style="display:flex;align-items:center;gap:12px;background:rgba(' + t.rgb + ',0.06);border:1px solid rgba(' + t.rgb + ',0.18);border-radius:12px;padding:12px 14px;">';
      html += '<div style="font-size:22px;flex-shrink:0">' + t.icon + '</div>';
      html += '<div style="flex:1;min-width:0">';
      html += '<div style="font-family:var(--font-title);font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:rgba(' + t.rgb + ',0.95);margin-bottom:2px">' + pkgName + '</div>';
      html += '<div style="font-size:11px;color:rgba(255,255,255,0.3);font-family:var(--font-body)">+10% Speed em terreno de ' + t.label + '</div>';
      html += '</div>';
      if (rPkgIdx >= 0) {
        html += '<button style="background:rgba(' + t.rgb + ',0.1);border:1px solid rgba(' + t.rgb + ',0.25);border-radius:8px;padding:7px 14px;cursor:pointer;font-family:var(--font-title);font-size:10px;font-weight:700;letter-spacing:0.8px;text-transform:uppercase;color:rgba(' + t.rgb + ',0.9);white-space:nowrap;transition:background .15s" ' + onclick + '>Ver Pacote →</button>';
      }
      html += '</div>';
    });
    html += '</div>';
    html += '</div>';
  }

  html += '</div>'; // .tpg-modal-body
  html += '</div>'; // .tpg-modal
  html += '</div>'; // .tpg-modal-overlay

  var root = document.getElementById('tpg-modal-root');
  if (root) { root.innerHTML = html; document.body.style.overflow = 'hidden'; }
}

function closeTalentModal() {
  var root = document.getElementById('tpg-modal-root');
  if (root) root.innerHTML = '';
  document.body.style.overflow = '';
}

function closeTalentModalOverlay(e) {
  if (e.target.id === 'tpg-modal-overlay') closeTalentModal();
}

function selectTalentSlot(type, idx) {
  _talentActiveSlot[type] = idx;
  openTalentModal(type);
}

// Alias de compatibilidade
function openTalentPanel(type) { openTalentModal(type); }

function goToTalentPackage(pkgIdx) {
  // Navega para a aba de Pacotes e seleciona o pacote
  var tabBtn = document.querySelector('.tab-btn[onclick*="pacotes"]');
  if (tabBtn) { switchTab('pacotes', tabBtn); }
  // Dá um pequeno delay para o render acontecer
  setTimeout(function() {
    if (typeof selectPkg === 'function') selectPkg(pkgIdx);
    // Garante que a categoria Talent está ativa
    if (typeof activePkgCat !== 'undefined') {
      var pkgName = (PACKAGES[pkgIdx] && PACKAGES[pkgIdx].name) || '';
      var cat = pkgName.toLowerCase().startsWith('full') ? 'full' : 'talent';
      activePkgCat = cat;
      if (typeof renderPackages === 'function') renderPackages();
      if (typeof renderPkgDetail === 'function') renderPkgDetail(pkgIdx);
    }
  }, 80);
}

function goToTalentPackageReduces(pkgIdx) {
  var tabBtn = document.querySelector('.tab-btn[onclick*="pacotes"]');
  if (tabBtn) { switchTab('pacotes', tabBtn); }
  setTimeout(function() {
    if (typeof activePkgCat !== 'undefined') {
      activePkgCat = 'reduces';
      if (typeof renderPackages === 'function') renderPackages();
    }
    if (typeof selectPkg === 'function') selectPkg(pkgIdx);
    if (typeof renderPkgDetail === 'function') renderPkgDetail(pkgIdx);
  }, 80);
}
// ===================== WIKI: TOKENS =====================
var _tokensRendered = false;

var TOKENS_HELDS = [
  {
    id: 'choice-band',
    icon: '🔴',
    name: 'Choice Band',
    categoria: 'Ataque',
    cor: '#ff6b6b',
    rgb: '255,107,107',
    custo: '5 Tokens',
    efeito: 'Aumenta o Ataque do Pokémon em 50%, mas o prende em apenas um movimento.',
    dica: 'Ótimo para sweepers físicos. Use com movimentos de alta potência base.',
  },
  {
    id: 'choice-specs',
    icon: '🔵',
    name: 'Choice Specs',
    categoria: 'Ataque Especial',
    cor: '#60aaff',
    rgb: '96,170,255',
    custo: '5 Tokens',
    efeito: 'Aumenta o Ataque Especial em 50%, mas o prende em apenas um movimento.',
    dica: 'Ideal para attackers especiais. Combine com movimentos cobertura.',
  },
  {
    id: 'choice-scarf',
    icon: '🟡',
    name: 'Choice Scarf',
    categoria: 'Velocidade',
    cor: '#ffe066',
    rgb: '255,224,102',
    custo: '5 Tokens',
    efeito: 'Aumenta a Velocidade em 50%, mas o prende em apenas um movimento.',
    dica: 'Perfeito para revés de velocidade. Transforma Pokémon lentos em ameaças.',
  },
  {
    id: 'life-orb',
    icon: '🟠',
    name: 'Life Orb',
    categoria: 'Dano Universal',
    cor: '#ff9060',
    rgb: '255,144,96',
    custo: '8 Tokens',
    efeito: 'Aumenta o dano de todos os ataques em 30%, mas consome 10% do HP a cada golpe.',
    dica: 'Mais versátil que os Choice. Permite trocar de movimento livremente.',
  },
  {
    id: 'focus-sash',
    icon: '⚪',
    name: 'Focus Sash',
    categoria: 'Sobrevivência',
    cor: '#c0c0c0',
    rgb: '192,192,192',
    custo: '4 Tokens',
    efeito: 'Se o Pokémon estiver com HP cheio e levar um golpe fatal, sobrevive com 1 HP.',
    dica: 'Excelente para leads e Pokémon frágeis. Não funciona se o HP já estiver reduzido.',
  },
  {
    id: 'leftovers',
    icon: '🍃',
    name: 'Leftovers',
    categoria: 'Recuperação',
    cor: '#4caf8a',
    rgb: '76,175,138',
    custo: '4 Tokens',
    efeito: 'Restaura 1/16 do HP máximo no final de cada turno.',
    dica: 'Fundamental em estratégias defensivas. Prolonga a durabilidade do Pokémon.',
  },
  {
    id: 'assault-vest',
    icon: '🟣',
    name: 'Assault Vest',
    categoria: 'Defesa Especial',
    cor: '#b06aff',
    rgb: '176,106,255',
    custo: '6 Tokens',
    efeito: 'Aumenta a Defesa Especial em 50%, mas impede o uso de movimentos de status.',
    dica: 'Transforma Pokémon em tanques especiais. Ótimo para Pokémon com bulk decente.',
  },
  {
    id: 'rocky-helmet',
    icon: '🪨',
    name: 'Rocky Helmet',
    categoria: 'Punição de Contato',
    cor: '#a08060',
    rgb: '160,128,96',
    custo: '5 Tokens',
    efeito: 'O atacante perde 1/6 do HP ao usar movimentos de contato.',
    dica: 'Ideal contra times físicos. Penaliza U-turn, golpes corpo-a-corpo etc.',
  },
  {
    id: 'black-sludge',
    icon: '🖤',
    name: 'Black Sludge',
    categoria: 'Recuperação (Venenosos)',
    cor: '#7a7a7a',
    rgb: '122,122,122',
    custo: '3 Tokens',
    efeito: 'Recupera 1/16 do HP a cada turno se for Venenoso; caso contrário, perde HP.',
    dica: 'Leftovers exclusivo para tipos Venenosos. Nunca use em não-Venenosos.',
  },
  {
    id: 'heavy-duty-boots',
    icon: '👢',
    name: 'Heavy-Duty Boots',
    categoria: 'Proteção de Entrada',
    cor: '#8aaa60',
    rgb: '138,170,96',
    custo: '6 Tokens',
    efeito: 'Impede que o Pokémon sofra dano de armadilhas ao entrar em campo (Stealth Rock, Spikes etc.).',
    dica: 'Essencial para Pokémon com fraqueza a Rocha ou que entram e saem muito.',
  },
];

function renderTokens() {
  var el = document.getElementById('wiki-tokens-content');
  if (!el) return;
  if (_tokensRendered) return;
  _tokensRendered = true;

  el.innerHTML = `
<style>
/* ── TOKENS PAGE ── */
.tk-page { padding: 0 0 60px; }

/* Hero */
.tk-hero {
  text-align: center; padding: 32px 20px 28px;
  background: linear-gradient(180deg, rgba(255,200,50,0.08) 0%, transparent 100%);
  border-bottom: 1px solid rgba(255,255,255,0.06);
}
.tk-hero-icon { font-size: 44px; margin-bottom: 10px; line-height: 1; }
.tk-hero-title {
  font-family: var(--font-title); font-size: 22px; font-weight: 900;
  letter-spacing: 3px; text-transform: uppercase; color: #ffd166;
  text-shadow: 0 0 24px rgba(255,209,102,0.4); margin-bottom: 10px;
}
.tk-hero-desc {
  font-family: var(--font-body); font-size: 13.5px; color: rgba(255,255,255,0.45);
  line-height: 1.7; max-width: 580px; margin: 0 auto;
}

/* Seções de explicação */
.tk-explain-section {
  padding: 28px 24px 0;
  max-width: 820px; margin: 0 auto;
  display: flex; flex-direction: column; gap: 16px;
}

.tk-info-card {
  border-radius: 16px; padding: 20px 22px;
  display: flex; gap: 18px; align-items: flex-start;
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.07);
  transition: border-color .2s, background .2s;
}
.tk-info-card:hover {
  border-color: rgba(255,209,102,0.2);
  background: rgba(255,209,102,0.03);
}
.tk-info-card-icon {
  font-size: 30px; flex-shrink: 0; margin-top: 2px; line-height: 1;
}
.tk-info-card-body { flex: 1; min-width: 0; }
.tk-info-card-title {
  font-family: var(--font-title); font-size: 13px; font-weight: 700;
  letter-spacing: 1.5px; text-transform: uppercase; color: #ffd166;
  margin-bottom: 8px;
}
.tk-info-card-text {
  font-family: var(--font-body); font-size: 13px; color: rgba(255,255,255,0.55);
  line-height: 1.75;
}
.tk-info-card-text strong { color: rgba(255,255,255,0.85); }
.tk-info-card-text a {
  color: #60aaff; text-decoration: none; border-bottom: 1px solid rgba(96,170,255,0.3);
  transition: color .15s, border-color .15s;
}
.tk-info-card-text a:hover { color: #90c8ff; border-color: rgba(96,170,255,0.6); }

/* Formas de obter — steps */
.tk-steps {
  display: flex; flex-direction: column; gap: 10px; margin-top: 10px;
}
.tk-step {
  display: flex; align-items: flex-start; gap: 14px;
  background: rgba(255,255,255,0.03); border-radius: 12px;
  padding: 14px 16px; border: 1px solid rgba(255,255,255,0.05);
}
.tk-step-num {
  width: 28px; height: 28px; border-radius: 50%; flex-shrink: 0;
  background: rgba(255,209,102,0.12); border: 1px solid rgba(255,209,102,0.3);
  display: flex; align-items: center; justify-content: center;
  font-family: var(--font-mono, monospace); font-size: 12px;
  font-weight: 700; color: #ffd166; margin-top: 1px;
}
.tk-step-text {
  font-family: var(--font-body); font-size: 12.5px; color: rgba(255,255,255,0.5);
  line-height: 1.7; flex: 1;
}
.tk-step-text strong { color: rgba(255,255,255,0.82); }
.tk-step-text a {
  color: #60aaff; text-decoration: none; border-bottom: 1px solid rgba(96,170,255,0.3);
}
.tk-step-text a:hover { color: #90c8ff; }
.tk-step-bonus {
  font-size: 11px; color: rgba(255,209,102,0.6); margin-top: 4px;
  font-style: italic;
}

/* Divider */
.tk-divider {
  margin: 28px 24px 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(255,209,102,0.2), transparent);
  max-width: 820px;
}

/* Helds Section */
.tk-helds-section {
  padding: 28px 24px 0;
  max-width: 820px; margin: 0 auto;
}
.tk-helds-title {
  font-family: var(--font-title); font-size: 11px; font-weight: 700;
  letter-spacing: 2.5px; text-transform: uppercase; color: rgba(255,255,255,0.3);
  margin-bottom: 16px;
}
.tk-helds-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 10px;
}
@media(max-width: 500px) {
  .tk-helds-grid { grid-template-columns: repeat(2, 1fr); }
}
.tk-held-block {
  border-radius: 14px; padding: 18px 14px 14px;
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.08);
  cursor: pointer; text-align: center;
  transition: background .2s, border-color .2s, transform .15s, box-shadow .2s;
  position: relative; overflow: hidden;
}
.tk-held-block::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(circle at 50% 0%, rgba(var(--hb-rgb),0.1), transparent 70%);
  opacity: 0; transition: opacity .2s;
}
.tk-held-block:hover::before { opacity: 1; }
.tk-held-block:hover {
  background: rgba(var(--hb-rgb), 0.06);
  border-color: rgba(var(--hb-rgb), 0.35);
  transform: translateY(-3px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.3);
}
.tk-held-block-icon { font-size: 28px; margin-bottom: 8px; line-height: 1; }
.tk-held-block-name {
  font-family: var(--font-title); font-size: 10px; font-weight: 700;
  letter-spacing: 0.8px; text-transform: uppercase;
  color: rgba(var(--hb-rgb), 0.9);
  margin-bottom: 6px; line-height: 1.3;
}
.tk-held-block-cat {
  font-family: var(--font-body); font-size: 10px;
  color: rgba(255,255,255,0.3); margin-bottom: 6px;
}
.tk-held-block-cost {
  display: inline-flex; align-items: center; gap: 4px;
  background: rgba(var(--hb-rgb), 0.1);
  border: 1px solid rgba(var(--hb-rgb), 0.25);
  border-radius: 20px; padding: 3px 9px;
  font-family: var(--font-mono, monospace); font-size: 10px; font-weight: 700;
  color: rgba(var(--hb-rgb), 0.9);
}

/* Modal do held */
.tk-held-modal-overlay {
  position: fixed; inset: 0; z-index: 10000;
  background: rgba(0,0,0,0.75); backdrop-filter: blur(6px);
  display: flex; align-items: center; justify-content: center;
  padding: 20px;
  animation: tk-fade-in .15s ease;
}
@keyframes tk-fade-in { from { opacity: 0 } to { opacity: 1 } }
.tk-held-modal {
  background: #0d1624; border-radius: 20px;
  border: 1px solid rgba(var(--hm-rgb,255,255,255), 0.2);
  box-shadow: 0 0 60px rgba(var(--hm-rgb,255,255,255), 0.1), 0 20px 60px rgba(0,0,0,0.6);
  max-width: 420px; width: 100%; overflow: hidden;
  animation: tk-slide-up .2s cubic-bezier(.4,0,.2,1);
}
@keyframes tk-slide-up { from { transform: translateY(16px); opacity: 0 } to { transform: translateY(0); opacity: 1 } }
.tk-held-modal-header {
  padding: 24px 24px 20px;
  background: linear-gradient(135deg, rgba(var(--hm-rgb,255,255,255),0.06), transparent);
  border-bottom: 1px solid rgba(var(--hm-rgb,255,255,255), 0.1);
  display: flex; align-items: center; gap: 16px;
}
.tk-held-modal-icon { font-size: 40px; line-height: 1; }
.tk-held-modal-info { flex: 1; }
.tk-held-modal-name {
  font-family: var(--font-title); font-size: 16px; font-weight: 900;
  letter-spacing: 1.5px; text-transform: uppercase;
  color: rgba(var(--hm-rgb,255,255,255), 1);
  margin-bottom: 4px;
}
.tk-held-modal-cat {
  font-family: var(--font-body); font-size: 12px; color: rgba(255,255,255,0.35);
}
.tk-held-modal-close {
  background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.12);
  color: rgba(255,255,255,0.5); border-radius: 50%; width: 30px; height: 30px;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; font-size: 14px; transition: background .15s, color .15s;
  flex-shrink: 0;
}
.tk-held-modal-close:hover { background: rgba(255,255,255,0.14); color: #fff; }
.tk-held-modal-body { padding: 22px 24px 24px; display: flex; flex-direction: column; gap: 18px; }
.tk-held-modal-section-label {
  font-family: var(--font-title); font-size: 9px; font-weight: 700;
  letter-spacing: 2px; text-transform: uppercase; color: rgba(255,255,255,0.25);
  margin-bottom: 8px;
}
.tk-held-modal-efeito {
  font-family: var(--font-body); font-size: 13.5px; color: rgba(255,255,255,0.75);
  line-height: 1.7;
}
.tk-held-modal-dica {
  background: rgba(var(--hm-rgb,255,255,255), 0.05);
  border: 1px solid rgba(var(--hm-rgb,255,255,255), 0.12);
  border-radius: 12px; padding: 14px 16px;
  font-family: var(--font-body); font-size: 12.5px; color: rgba(255,255,255,0.5);
  line-height: 1.65; font-style: italic;
}
.tk-held-modal-custo {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(var(--hm-rgb,255,255,255), 0.08);
  border: 1px solid rgba(var(--hm-rgb,255,255,255), 0.2);
  border-radius: 40px; padding: 8px 18px;
  font-family: var(--font-mono, monospace); font-size: 14px; font-weight: 700;
  color: rgba(var(--hm-rgb,255,255,255), 1);
  align-self: flex-start;
}
</style>

<div class="tk-page">

  <!-- Hero -->
  <div class="tk-hero">
    <div class="tk-hero-icon">🪙</div>
    <div class="tk-hero-title">Sistema de Tokens</div>
    <div class="tk-hero-desc">
      Tokens são a moeda especial usada para adquirir Helds — os itens equipáveis nos seus Pokémon que potencializam seu desempenho em batalha. Entenda como tudo funciona abaixo.
    </div>
  </div>

  <!-- Explicações -->
  <div class="tk-explain-section">

    <!-- O que são tokens -->
    <div class="tk-info-card">
      <div class="tk-info-card-icon">🪙</div>
      <div class="tk-info-card-body">
        <div class="tk-info-card-title">O Que São Tokens?</div>
        <div class="tk-info-card-text">
          Tokens são uma <strong>moeda especial do servidor</strong> usada exclusivamente para trocar por <strong>Helds</strong>.
          Helds são os itens que você equipa nos seus Pokémon para aumentar seu poder em batalha — funcionam como acessórios estratégicos
          que podem ampliar ataque, defesa, velocidade e outros atributos essenciais.
          <br><br>
          Diferente do dinheiro comum (KK), os Tokens são conquistados por meio de atividades específicas e têm um propósito focado:
          <strong>fortalecer o seu time</strong>.
        </div>
      </div>
    </div>

    <!-- Máquina de troca -->
    <div class="tk-info-card">
      <div class="tk-info-card-icon">🏪</div>
      <div class="tk-info-card-body">
        <div class="tk-info-card-title">Como Utilizar Tokens?</div>
        <div class="tk-info-card-text">
          Para trocar seus Tokens por Helds, você precisa ir até a
          <strong><a href="https://prnt.sc/DYsS5fNrU0Ob" target="_blank" rel="noopener">Máquina de Troca</a></strong>
          localizada no <strong>Trade Center (TC), no segundo andar</strong>.
          <br><br>
          Cada Held tem um custo diferente em Tokens. Ao interagir com a máquina, você verá a lista de Helds disponíveis com seus
          respectivos preços. Basta ter a quantidade necessária de Tokens e confirmar a troca para receber o item.
          <br><br>
          Cada Held possui um <strong>efeito único</strong> — alguns aumentam dano, outros melhoram sobrevivência ou velocidade.
          Escolha de acordo com a estratégia do seu time!
        </div>
      </div>
    </div>

    <!-- Como obter -->
    <div class="tk-info-card">
      <div class="tk-info-card-icon">⚡</div>
      <div class="tk-info-card-body">
        <div class="tk-info-card-title">Como Obter Tokens?</div>
        <div class="tk-info-card-text">Existem <strong>três formas principais</strong> de acumular Tokens:</div>
        <div class="tk-steps">

          <div class="tk-step">
            <div class="tk-step-num">1</div>
            <div class="tk-step-text">
              <strong>Lutando Contra Rockets</strong> —
              Os Rockets são inimigos localizados ao sul de Pewter.
              Você pode encontrá-los <a href="https://prnt.sc/LNR7YvrKhaBF" target="_blank" rel="noopener">aqui</a>.
              Derrotá-los pode render Tokens como recompensa de drop.
              <div class="tk-step-bonus">🎁 Bônus: chance de dropar a <strong>Rocket Outfit</strong> exclusiva!</div>
            </div>
          </div>

          <div class="tk-step">
            <div class="tk-step-num">2</div>
            <div class="tk-step-text">
              <strong>NPCs da Duelist Brotherhood</strong> —
              A Duelist Brotherhood é um grupo de NPCs espalhados pelo servidor que te desafiam para batalhas.
              Ao vencê-los, você recebe Tokens como parte da recompensa.
              É uma atividade recorrente e também garante <strong>EXP</strong> para seus Pokémon.
            </div>
          </div>

          <div class="tk-step">
            <div class="tk-step-num">3</div>
            <div class="tk-step-text">
              <strong>Missões Diárias (Guild Daily's Mission)</strong> —
              As Missões Diárias são renovadas periodicamente e podem envolver batalhas específicas ou objetivos variados.
              Ao completá-las com sucesso, você garante <strong>Tokens como recompensa</strong>.
              Vale checar todo dia para não perder nenhuma!
            </div>
          </div>

        </div>
      </div>
    </div>

    <!-- Guia de helds -->
    <div class="tk-info-card">
      <div class="tk-info-card-icon">📖</div>
      <div class="tk-info-card-body">
        <div class="tk-info-card-title">Saiba Mais Sobre Helds</div>
        <div class="tk-info-card-text">
          Quer entender mais profundamente como cada Held funciona, como equipá-los e qual é o ideal para sua estratégia?
          Confira o <strong>Guia Completo de Helds</strong> — lá você encontra tudo sobre os tipos de Helds, combinações recomendadas
          e dicas para montar o time perfeito.
          <br><br>
          Os Helds disponíveis na Máquina de Troca estão listados abaixo — clique em qualquer um para ver seus detalhes!
        </div>
      </div>
    </div>

  </div><!-- /tk-explain-section -->

  <div class="tk-divider" style="margin:28px auto 0; max-width:820px;"></div>

  <!-- Grid de Helds -->
  <div class="tk-helds-section">
    <div class="tk-helds-title">🎒 Helds Disponíveis na Máquina de Troca</div>
    <div class="tk-helds-grid" id="tk-helds-grid"></div>
  </div>

</div>

<!-- Modal do Held -->
<div id="tk-held-modal-root"></div>
`;

  // Renderiza os blocos de helds
  var grid = document.getElementById('tk-helds-grid');
  if (!grid) return;
  grid.innerHTML = TOKENS_HELDS.map(function(h) {
    return '<div class="tk-held-block" style="--hb-rgb:' + h.rgb + '" onclick="openHeldModal(\'' + h.id + '\')">' +
      '<div class="tk-held-block-icon">' + h.icon + '</div>' +
      '<div class="tk-held-block-name">' + h.name + '</div>' +
      '<div class="tk-held-block-cat">' + h.categoria + '</div>' +
      '<div class="tk-held-block-cost">🪙 ' + h.custo + '</div>' +
    '</div>';
  }).join('');
}

function openHeldModal(id) {
  var h = TOKENS_HELDS.find(function(x) { return x.id === id; });
  if (!h) return;
  // Remove modal existente
  var existing = document.getElementById('tk-held-modal-root');
  if (existing) existing.innerHTML = '';
  var root = existing || document.body;

  var html = '<div class="tk-held-modal-overlay" onclick="closeHeldModal(event)" id="tk-held-modal-overlay">' +
    '<div class="tk-held-modal" style="--hm-rgb:' + h.rgb + '">' +
      '<div class="tk-held-modal-header">' +
        '<div class="tk-held-modal-icon">' + h.icon + '</div>' +
        '<div class="tk-held-modal-info">' +
          '<div class="tk-held-modal-name">' + h.name + '</div>' +
          '<div class="tk-held-modal-cat">' + h.categoria + '</div>' +
        '</div>' +
        '<button class="tk-held-modal-close" onclick="closeHeldModalBtn()">✕</button>' +
      '</div>' +
      '<div class="tk-held-modal-body">' +
        '<div>' +
          '<div class="tk-held-modal-section-label">Efeito</div>' +
          '<div class="tk-held-modal-efeito">' + h.efeito + '</div>' +
        '</div>' +
        '<div>' +
          '<div class="tk-held-modal-section-label">Dica de Uso</div>' +
          '<div class="tk-held-modal-dica">' + h.dica + '</div>' +
        '</div>' +
        '<div class="tk-held-modal-custo">🪙 ' + h.custo + '</div>' +
      '</div>' +
    '</div>' +
  '</div>';

  root.innerHTML = html;
  document.body.style.overflow = 'hidden';
}

function closeHeldModal(e) {
  if (e.target.id === 'tk-held-modal-overlay') closeHeldModalBtn();
}
function closeHeldModalBtn() {
  var root = document.getElementById('tk-held-modal-root');
  if (root) root.innerHTML = '';
  document.body.style.overflow = '';
}

